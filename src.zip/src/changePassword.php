<?php $page ='login'; include 'inc/head.php'; ?>



<div class="zee-content-wrapper no-banner zee-myaccount-body">
    <div class="my-account-welcome">
        <div class="container">
            <div class="row">
                <h3><small>welcome</small>Pushkar Adsule</h3>
            </div>
        </div>
    </div>
    <div class="container zee-myaccounter-container">



        <div class="zee-myaccount-nav-wrapper">
            <div class="visible-xs-inline-block myaccount-mobile-menu-trigger">
                <a href="#" id="zee_myaccount_mobile_menu_trigger">Menu</a>
            </div>
            <div id="zee_myaccount_mobile_menu">
                <?php $active_menu = 'changepass'; include('inc/myaccount-menu.php'); ?>
                <?php
                /*
                 * <h4 class="zee-myaccount-linktv-header">Link your TV</h4>
                <ul class="zee-myaccount-linktv">
                <li>
                <a href="Samsung">
                <img src="/images/samsung-smart-tv.png">
                </a>
                </li>
                </ul>
                 */?>
            </div>
        </div>

        <div class="zee-myaccount-wrapper">
            <h3 class="zee-myaccount-section-heading my-profile-heading">Change Password</h3>
            <div class="clearfix" style="height: 20px;"></div>
            
            <form action="/ChangePassword" autocomplete="off" method="post">
                <div class="row">

                    <div class="col-sm-12">
                        <div class="form-group">
                            <input class="form-control floating-label" placeholder="Old Password" data-val="true" data-val-required="The Current password field is required." id="OldPassword" name="OldPassword" type="password" />
                        </div>
                    </div>
                    <div class="col-sm-12">
                        <div class="form-group">
                            <input class="form-control floating-label" placeholder="New Password" data-val="true" data-val-length="The password must be at least 6 characters long." data-val-length-max="100" data-val-length-min="6" data-val-required="The New password field is required." id="NewPassword" name="NewPassword" type="password" />
                        </div>
                    </div>

                    <div class="col-sm-12">
                        <div class="form-group">
                            <input class="form-control floating-label" placeholder="Confirm New Password" data-val="true" data-val-equalto="The new password and confirmation password do not match." data-val-equalto-other="*.NewPassword" id="ConfirmPassword" name="ConfirmPassword" type="password" />
                        </div>
                    </div>
                    <div class="clearfix" style="height: 30px;"></div>
                    <div class="row">

                        <div class="col-sm-12">
                            <div class="form-group" style="float: right">
                                <button class="btn btn-material-grey" type="reset">CLEAR</button>
                                <button class="btn btn-primary">Change Password</button>
                            </div>
                        </div>
                    </div>
                </div>
            </form>

        </div>

    </div>
</div>

<?php include 'inc/footer.php'; ?>