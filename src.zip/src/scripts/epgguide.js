﻿/*Spin JS*/
//fgnass.github.com/spin.js#v2.0.1

if (!Array.prototype.last) {
    Array.prototype.last = function () {
        return this[this.length - 1];
    };
};


!function (a, b) { "object" == typeof exports ? module.exports = b() : "function" == typeof define && define.amd ? define(b) : a.Spinner = b() }(this, function () { "use strict"; function a(a, b) { var c, d = document.createElement(a || "div"); for (c in b) d[c] = b[c]; return d } function b(a) { for (var b = 1, c = arguments.length; c > b; b++) a.appendChild(arguments[b]); return a } function c(a, b, c, d) { var e = ["opacity", b, ~~(100 * a), c, d].join("-"), f = .01 + c / d * 100, g = Math.max(1 - (1 - a) / b * (100 - f), a), h = j.substring(0, j.indexOf("Animation")).toLowerCase(), i = h && "-" + h + "-" || ""; return l[e] || (m.insertRule("@" + i + "keyframes " + e + "{0%{opacity:" + g + "}" + f + "%{opacity:" + a + "}" + (f + .01) + "%{opacity:1}" + (f + b) % 100 + "%{opacity:" + a + "}100%{opacity:" + g + "}}", m.cssRules.length), l[e] = 1), e } function d(a, b) { var c, d, e = a.style; for (b = b.charAt(0).toUpperCase() + b.slice(1), d = 0; d < k.length; d++) if (c = k[d] + b, void 0 !== e[c]) return c; return void 0 !== e[b] ? b : void 0 } function e(a, b) { for (var c in b) a.style[d(a, c) || c] = b[c]; return a } function f(a) { for (var b = 1; b < arguments.length; b++) { var c = arguments[b]; for (var d in c) void 0 === a[d] && (a[d] = c[d]) } return a } function g(a, b) { return "string" == typeof a ? a : a[b % a.length] } function h(a) { this.opts = f(a || {}, h.defaults, n) } function i() { function c(b, c) { return a("<" + b + ' xmlns="urn:schemas-microsoft.com:vml" class="spin-vml">', c) } m.addRule(".spin-vml", "behavior:url(#default#VML)"), h.prototype.lines = function (a, d) { function f() { return e(c("group", { coordsize: k + " " + k, coordorigin: -j + " " + -j }), { width: k, height: k }) } function h(a, h, i) { b(m, b(e(f(), { rotation: 360 / d.lines * a + "deg", left: ~~h }), b(e(c("roundrect", { arcsize: d.corners }), { width: j, height: d.width, left: d.radius, top: -d.width >> 1, filter: i }), c("fill", { color: g(d.color, a), opacity: d.opacity }), c("stroke", { opacity: 0 })))) } var i, j = d.length + d.width, k = 2 * j, l = 2 * -(d.width + d.length) + "px", m = e(f(), { position: "absolute", top: l, left: l }); if (d.shadow) for (i = 1; i <= d.lines; i++) h(i, -2, "progid:DXImageTransform.Microsoft.Blur(pixelradius=2,makeshadow=1,shadowopacity=.3)"); for (i = 1; i <= d.lines; i++) h(i); return b(a, m) }, h.prototype.opacity = function (a, b, c, d) { var e = a.firstChild; d = d.shadow && d.lines || 0, e && b + d < e.childNodes.length && (e = e.childNodes[b + d], e = e && e.firstChild, e = e && e.firstChild, e && (e.opacity = c)) } } var j, k = ["webkit", "Moz", "ms", "O"], l = {}, m = function () { var c = a("style", { type: "text/css" }); return b(document.getElementsByTagName("head")[0], c), c.sheet || c.styleSheet }(), n = { lines: 12, length: 7, width: 5, radius: 10, rotate: 0, corners: 1, color: "#000", direction: 1, speed: 1, trail: 100, opacity: .25, fps: 20, zIndex: 2e9, className: "spinner", top: "50%", left: "50%", position: "absolute" }; h.defaults = {}, f(h.prototype, { spin: function (b) { this.stop(); { var c = this, d = c.opts, f = c.el = e(a(0, { className: d.className }), { position: d.position, width: 0, zIndex: d.zIndex }); d.radius + d.length + d.width } if (e(f, { left: d.left, top: d.top }), b && b.insertBefore(f, b.firstChild || null), f.setAttribute("role", "progressbar"), c.lines(f, c.opts), !j) { var g, h = 0, i = (d.lines - 1) * (1 - d.direction) / 2, k = d.fps, l = k / d.speed, m = (1 - d.opacity) / (l * d.trail / 100), n = l / d.lines; !function o() { h++; for (var a = 0; a < d.lines; a++) g = Math.max(1 - (h + (d.lines - a) * n) % l * m, d.opacity), c.opacity(f, a * d.direction + i, g, d); c.timeout = c.el && setTimeout(o, ~~(1e3 / k)) }() } return c }, stop: function () { var a = this.el; return a && (clearTimeout(this.timeout), a.parentNode && a.parentNode.removeChild(a), this.el = void 0), this }, lines: function (d, f) { function h(b, c) { return e(a(), { position: "absolute", width: f.length + f.width + "px", height: f.width + "px", background: b, boxShadow: c, transformOrigin: "left", transform: "rotate(" + ~~(360 / f.lines * k + f.rotate) + "deg) translate(" + f.radius + "px,0)", borderRadius: (f.corners * f.width >> 1) + "px" }) } for (var i, k = 0, l = (f.lines - 1) * (1 - f.direction) / 2; k < f.lines; k++) i = e(a(), { position: "absolute", top: 1 + ~(f.width / 2) + "px", transform: f.hwaccel ? "translate3d(0,0,0)" : "", opacity: f.opacity, animation: j && c(f.opacity, f.trail, l + k * f.direction, f.lines) + " " + 1 / f.speed + "s linear infinite" }), f.shadow && b(i, e(h("#000", "0 0 4px #000"), { top: "2px" })), b(d, b(i, h(g(f.color, k), "0 0 1px rgba(0,0,0,.1)"))); return d }, opacity: function (a, b, c) { b < a.childNodes.length && (a.childNodes[b].style.opacity = c) } }); var o = e(a("group"), { behavior: "url(#default#VML)" }); return !d(o, "transform") && o.adj ? i() : j = d(o, "animation"), h });


var app = angular.module('main', []);


app.service('zeeEpgService', function ($http, $q) {

    return {
        getEpgData: function (url, request, token) {

            var deferred = $q.defer();
            //$http(
            //    {
            //        method: 'POST',
            //        data: request, url:
            //        url, cache: false,
            //        headers: { 'RequestVerificationToken': token }
            //    }
            //    ).success(function (data) {
            //        deferred.resolve(data);
            //    }).error(function (error) {
            //        deferred.reject(error);
            //    });



            $http({
                method: 'GET',
                url: '/ZeeFamilyV2.UI/scripts/data.js',
                headers: { 'RequestVerificationToken': token }
            }).success(function (data) {
                deferred.resolve(data);
            }).error(function (error) {
                deferred.reject(error);
            });

            return deferred.promise;
        }

    };
});

/*Controller Code*/
app.controller('EpgGuide', function ($scope, $http, $timeout, zeeEpgService) {

    var opts = {
        lines: 13, // The number of lines to draw
        length: 20, // The length of each line
        width: 10, // The line thickness
        radius: 75, // The radius of the inner circle
        corners: 1, // Corner roundness (0..1)
        rotate: 0, // The rotation offset
        direction: 1, // 1: clockwise, -1: counterclockwise
        color: '#EF102E', // #rgb or #rrggbb or array of colors
        speed: 1, // Rounds per second
        trail: 60, // Afterglow percentage
        shadow: false, // Whether to render a shadow
        hwaccel: true, // Whether to use hardware acceleration
        className: 'spinner', // The CSS class to assign to the spinner
        zIndex: 2e9, // The z-index (defaults to 2000000000)
        top: '60%', // Top position relative to parent
        left: '50%' // Left position relative to parent
    };


    var target = document.getElementById('spinner-1');
    var spinner = new Spinner(opts).spin(target);
    var baseUrl = $("#guide-list-wrapper").data("baseUrl");

    $("#epg-grid").hide();
    $("#guide-list-wrapper").hide();



    $scope.ShowSpinner = function () {
        $("#guide-list-wrapper").hide();
        spinner.spin(target);
    }

    $scope.HideSpinner = function () {
        spinner.stop();
        $("#guide-list-wrapper").css('visibility', 'visible').show().fadeOut('slow', 1);
    }

    $scope.itemStyle = function (item) {
        return { width: item * 8 + 'px' };
    };

    $scope.msInDay = 86400000;

    $scope.dates = [];
    $scope.channels = [];
    $scope.todays = [];
    $scope.todaysDate = null;
    $scope.heightcount = 0;

    $scope.now = new Date();

    $scope.todayBoD = new Date($scope.now.getFullYear(), $scope.now.getMonth(), $scope.now.getDate());
    $scope.todayBoD.setTime($scope.todayBoD.getTime() + 1000);
    $scope.todayBoD = (new Date($scope.todayBoD));

    $scope.pageSize = 128;
    $scope.daysWithEpgItems = [];


    $scope.getEoD = function (date) {
        var result = new Date(date);
        result.setTime(result.getTime() + $scope.msInDay - 2000);
        return new Date(result);
    };


    function moveToCurrentTimeFrame() {

        var servertime = new Date();

        var serverDate = $scope.todayBoD;

        var date = new Date(servertime.year, servertime.month, servertime.day, 0, 0, 0, 0);

        function getTheDiffTime(dateone, datetwo, format) {

            var seconds;
            if (dateone > datetwo) {
                seconds = dateone.getTime() - datetwo.getTime();
            } else {
                seconds = datetwo.getTime() - dateone.getTime();
            }
            var second = 1000, minute = 60 * second, hour = 60 * minute, day = 24 * hour;
            if (format == "Days") {
                var rformat = Math.floor(seconds / day);
                seconds -= rformat * day;
                //alert("days: "+rformat);
            } else if (format == "Hours") {
                // find the hours
                rformat = translate(seconds / hour);
                //alert("hours: "+rformat);
            } else if (format == "Minutes") {
                //find the mintues
                rformat = seconds / minute;
                //alert("minutes: "+ rformat);
            } else if (format == "Seconds") {
                //find the seconds
                rformat = translate(seconds / second);
                //alert("seconds: "+rformat);
            }

            return rformat;
            //alert(rformat);

        }
        var diff = getTheDiffTime(date, serverDate, "Minutes") * 8;

        var margin = diff;

        var m = (diff % 240) * -1;
        if (m != 0) {
            margin = diff + m;
        }
        console.log(margin);
        $(window).scrollLeft(margin - 720);

    }

    function scrollGrid(distance) {
        if ($('html,body').queue().length > 0) return false;
        var left = $(window).scrollLeft();
        $('html,body').animate({ scrollLeft: left + distance }, 1000);
        return false;
    };

    $scope.scrollNext = function (e) {
        if (e === 0) scrollGrid(60);
        scrollGrid(480);
    }

    $scope.scrollPrev = function (e) {
        if (e === 0) scrollGrid(-60);
        scrollGrid(-480);
    }

    function calculateHeightWidth() {

        $(window).scrollTop(0);

        function calculate() {
            var height = parseInt($(window).height() + $(window).scrollTop() - $("#guide-channels").offset().top, 10);

            $("#guide-channels").css({
                'height': height + 'px'
            });

            $("#zee-next").css({
                'height': height + 'px'
            });

            $("#zee-previous").css({
                'height': height + 'px'
            });

            $timeout(calculate, 100);

            moveToCurrentTimeFrame();
        }

    };

    $(window).resize(function () {

        calculateHeightWidth();
    });


    $scope.onNow = function () {


        $scope.ShowSpinner();

        $scope.epgInfo.ChangeDay($scope.todaysDate);

        var guideDaysScroll = $("#guide-schedule-items");

        var owl = guideDaysScroll.data('owlCarousel');

        owl.jumpTo($scope.todaysDate.seq);


    }


    function getDates(data) {

        $scope.dates = data;

        $scope.channelHeight = 0;

        var countUp = function () {

            // guide schedule scroll
            var guideDaysScroll = $("#guide-schedule-items");

            var nid = $('#dt-scroll-prev');
            var pid = $('#dt-scroll-next');

            guideDaysScroll.owlCarousel({
                navigation: false,
                pagination: false,
                responsive: false,
                itemsScaleUp: false,
                items: 14,
                mouseDrag: false,
                scrollPerPage: false,
                rewindNav: false

            });


            $('#dt-scroll-prev').click(function () {
                guideDaysScroll.trigger('owl.prev');
            });

            $('#dt-scroll-next').click(function () {
                guideDaysScroll.trigger('owl.next');
            });


            var queryResult = Enumerable.from($scope.dates)
             .where(function (x) { return x.active === true; })
                        .toArray();
            var owl = guideDaysScroll.data('owlCarousel');

            owl.jumpTo(queryResult[0].seq);


        }

        $timeout(countUp, 10);
    };




    getDates(serverEpgDates);



    $scope.isEpgItemOnNow = function (epgItem) {
        var start = Date.parse(epgItem.StartDate);
        var end = Date.parse(epgItem.EndDate);
        var result = (start <= $scope.now) && ($scope.now <= end);
        epgItem.IsPlayingNow = result;
        epgItem.IsCatchUp = $scope.isPastEpgItem(epgItem);

        return result;
    }

    $scope.isPastEpgItem = function (epgItem) {
        var end = new Date(epgItem.EndDate);
        return (end <= $scope.now);
    }

    $scope.epgItemProgress = function (epgItem) {
        var result = 0;
        if ($scope.isEpgItemOnNow(epgItem)) {
            var start = Date.parse(epgItem.StartDate);
            var end = Date.parse(epgItem.EndDate);
            result = (($scope.now - start) / (end - start));
        }
        return result;
    }

    $scope.getEoD = function (date) {
        var result = new Date(date);
        result.setTime(result.getTime() + $scope.msInDay - 2000);
        return new Date(result);
    };


    $scope.epgInfo = {};

    $scope.epgInfo.ChangeDay = function (day, date) {



        if (date == null)
            date = $scope.todayBoD;
        else
            date = new Date(day.year, day.monthint - 1, day.day);

        var url = "/ZeeFamilyV2.UI/EpgItem";

        var request = {
            "TimeStart": date.toISOString(),
            "TimeEnd": $scope.getEoD(date).toISOString()
        };

        $scope.ShowSpinner();
                


        zeeEpgService.getEpgData(url, request, $('#antiForgeryToken').val()).then(function (data) {

            data.forEach(function (entry) {
                if (entry.EpgItems.length === 0) return;

                var k = entry.EpgItems[0];

                var sd = new Date(k.StartDate);
                var ed = new Date(k.EndDate);

                if (sd.getHours() === 0 && sd.getMinutes() === 0) {
                    entry.EpgItems = _.without(entry.EpgItems, _.findWhere(entry.EpgItems, { EpgItemId: k.EpgItemId }));
                } else if (ed.getHours() === 0 && ed.getMinutes() === 0) {
                    entry.EpgItems = _.without(entry.EpgItems, _.findWhere(entry.EpgItems, { EpgItemId: k.EpgItemId }));
                }
                else {
                    var endDateMinutes = date - new Date(k.StartDate);
                    k.DurationInMinutes = Math.round(((endDateMinutes % 86400000) % 3600000) / 60000);

                }

                console.log(entry.EpgItems);

                var last = entry.EpgItems.last();

                var ld = new Date(last.EndDate);


                var teena = 0;
                entry.EpgItems.forEach(function (cc) {
                    teena += cc.DurationInMinutes;
                });

                console.log(entry.Name + ' -' + teena);

                if ((ld.getHours() > 0 && ld.getMinutes() > 0) || teena > 1440) {
                    last.DurationInMinutes = 1440 - (teena - last.DurationInMinutes);

                }

                teena = 0;
                entry.EpgItems.forEach(function (cc) {
                    teena += cc.DurationInMinutes;
                });

                console.log(entry.Name + ' -' + teena);

            });

            $scope.channels = data;

            calculateHeightWidth();

      
            $scope.todaysDate = Enumerable.from($scope.dates).where(function (x) { return x.active === true; })
                                .toArray()[0];

            
            calculateHeightWidth();

            $(window).add('#guide-channels').scrollsync({ targetSelector: $(window), axis: 'y' });
            $(window).dragscrollable({ dragSelector: '#guide-schedule-outer', acceptPropagatedEvent: true, threshold: 3 });

            try {
                spinner.stop();
                $('#epg-grid').css('visibility', 'visible').show().fadeIn('slow');
                $("#guide-list-wrapper").css('visibility', 'visible').show().fadeOut('slow', 1);
            } catch (ex) {

            }


        });
    }

    $scope.epgInfo.ChangeDay();

});