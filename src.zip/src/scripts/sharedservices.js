﻿var SharedServices = function () {
    "use strict";
    var contactSubmitted = false;

    function initHeaderScripts() {

        // event on desktop
        $('.zee-toolbar-menu').on('mouseenter', function () {
            $(this).addClass('show');
        });
        $('.zee-toolbar-menu').on('mouseleave', function () {
            $(this).removeClass('show');
        });

        // event on desktop
        $('.zee-toolbar-user').on('mouseenter', function () {
            $(this).addClass('show');
        });
        $('.zee-toolbar-user').on('mouseleave', function () {
            $(this).removeClass('show');
        });

        $('.zee-writeus > a').magnificPopup({
            modal: true,
            items: {
                src: '#zee_contact_form',
                type: 'inline',
            },
            removalDelay: 300,
            mainClass: 'mfp-fade'
        });

        // close contact form
        $('#zee_close_contact_form').on('click', function () {
            $.magnificPopup.close();
        });


        // myaccounts menu
        $(document).on('click', '#zee_user_menu', function (e) {
            e.preventDefault();
        });

        $('#zee_user_menu').qtip({
            id: false,
            content: {
                text: $('#myaccount_menu').html(),
                title: {
                    text: false,
                    button: false
                }
            },
            position: {
                my: 'top right',
                at: 'bottom right'
            },
            style: {
                classes: 'user_myaccount_menu',
                width: 239,
                //height: 100,
                tip: {
                    corner: 'top center',
                    offset: -7,
                    width: 20,
                    height: 12,
                    border: 0
                }
            },
            show: {
                event: 'mouseenter',
                solo: true,
                delay: 100,
                effect: function () {
                    $(this).fadeIn(800, 'swing');
                }
            },
            hide: {
                delay: 100,
                event: 'unfocus mouseleave',
                fixed: true,
                effect: function () {
                    $(this).fadeOut(500, 'swing');
                }
            },
            events: {
                show: function () {
                    $('.zee-user-btn-wrapper').addClass('active-menu-wrapper');
                },
                hide: function () {
                    $('.zee-user-btn-wrapper').removeClass('active-menu-wrapper');
                }
            }
        });

        // mega menu
        $(document).on('click', '#zee_megamenu_btn', function (e) {
            e.preventDefault();
        });

        $('#zee_megamenu_btn').qtip({
            id: false,
            content: {
                text: $('#zee_mega_menu').html(),
                title: {
                    text: false,
                    button: false
                }
            },
            position: {
                my: 'top left',
                at: 'bottom left'
            },
            style: {
                classes: 'megamenu_content',
                width: 780,
                //height: 100,
                tip: {
                    corner: 'top center',
                    offset: -7,
                    width: 20,
                    height: 12,
                    border: 0
                }
            },
            show: {
                event: 'mouseenter',
                solo: true,
                delay: 100,
                effect: function () {
                    $(this).fadeIn(800, 'swing');
                }
            },
            hide: {
                delay: 100,
                event: 'unfocus mouseleave',
                fixed: true,
                effect: function () {
                    $(this).fadeOut(500, 'swing');
                }
            },
            events: {
                show: function () {
                    $('.zee-menu-btn-wrapper').addClass('active-menu-wrapper');
                },
                hide: function () {
                    $('.zee-menu-btn-wrapper').removeClass('active-menu-wrapper');
                }
            }
        });


    }

    function initContactForm() {

        $('#contact_form_new_msg').on('click', function (e) {
            e.preventDefault();
            $('#contact_form_result').fadeToggle(function () {
                $('#contact_form_wrapper').fadeToggle();
            });
        });


        $("#submitContactQuery").click(function () {

            var $this = $(this);
            var alreadyClicked = $this.data('clicked');
            if (alreadyClicked) {
                return false;
            }



            $this.data('clicked', true);

            var reasonCode = $("#reasonCode").val();

            var email = $("#contact-Email").val();

            var comments = $("#comments").val();


            $.ajax({
                url: '/contactInfo',
                type: 'post',
                data: { ReasonCode: reasonCode, Email: email, Comments: comments },
                dataType: 'json',
                success: function (data) {
                    ga('send', 'event', { eventCategory: 'Contact Us', eventAction: 'Click', eventLabel: 'Completion', eventValue: 2 });


                    $("#reasonCode").val("");
                    $("#contact-Email").val("");
                    $("#comments").val("");



                }
            });

        });
    }

    function onSelected($e, datum) {

        setTimeout(function () {
            if (datum.Url === null) {
                var form = document.getElementById("search-form");
                form.submit();
                // window.location.href = '/Search/' + encodeURIComponent(datum.Name);
            }
            else {
                window.location.href = datum.Url;
            }

        }, 500);
    }

    function initSearch(id) {

        initHeaderScripts();
        initContactForm();

        var engine = new Bloodhound({
            remote: '/search?q=%QUERY',
            datumTokenizer: function (d) {
                return d.Name;
            },

            queryTokenizer: Bloodhound.tokenizers.whitespace

        });

        var channels = new Bloodhound({
            remote: '/channels?q=%QUERY',
            datumTokenizer: function (d) {
                return d.Name;
            },
            queryTokenizer: Bloodhound.tokenizers.whitespace

        });

        var shows = new Bloodhound({
            remote: '/shows?q=%QUERY',
            datumTokenizer: function (d) {
                return d.Name;
            },
            queryTokenizer: Bloodhound.tokenizers.whitespace

        });

        engine.initialize();
        channels.initialize();
        shows.initialize();

        $(id).typeahead(null,
                {
                    highlight: true,
                    displayKey: 'Name',
                    source: engine.ttAdapter(),
                    templates: {
                        header: '<h5 class="movie-name">Movies & Actors</h5>'
                    },
                    minLength: 3
                },
                {
                    highlight: true,
                    displayKey: 'Name',
                    source: channels.ttAdapter(),
                    templates: {
                        header: '<div class"clearfix" </div><h5 class="channel-name">Channels</h5>',
                        empty: [
                          ''
                        ].join('\n'),
                        suggestion: Handlebars.compile('<p style="width:150px;float:left;margin-bottom:5px;padding-top:3px;">{{Name}}  </p> <a href="{{Url}}">Watch Now</a>')
                    },
                    minLength: 3
                },
                {
                    highlight: true,
                    displayKey: 'Name',
                    source: shows.ttAdapter(),
                    templates: {
                        header: '<h5 class="movie-name">TV Shows</h5>'
                    },
                    minLength: 3
                }).on('typeahead:selected', onSelected);
    }

    function showInactiveAccount(url) {
        var uniqueId = $.gritter.add({
            // (string | mandatory) the heading of the notification
            title: 'Inactive account!',
            // (string | mandatory) the text inside the notification
            text: 'You have not activated your account. Please click on the button below. You will receive an email with a new link to verify and activate your account.<a href=' + url + ' class="activatebutton">Activate</a>',
            // (string | optional) the image to display on the left

            // (bool | optional) if you want it to fade out on its own or just sit there
            sticky: true,
            // (int | optional) the time you want it to be alive for before fading out
            time: '',
            // (string | optional) the class name you want to apply to that specific message
            class_name: 'my-sticky-class'
        });
    }


    function validateEmail(sEmail) {
        var filter = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
        if (filter.test(sEmail)) {
            return true;
        }
        else {
            return false;
        }
    }

    function playLive(e, url) {


        var isAuthUser = $('#page_container').attr('data-isauth');

        if (isAuthUser === 'False') {
            window.location.href = url;
        } else {

            window.cpg = $(this).attr('data-title');

            $.fancybox.open({
                type: 'iframe',
                href: url,
                padding: 0,
                minWidth: 990,
                minHeight: 650,
                maxHeight: 700,
                closeBtn: false,
                modal: true,
                iframe: {
                    scrolling: 'auto'
                },
                helper: {
                    title: null,
                    overlay: {
                        css: {
                            'background': '#000000'
                        }
                    }
                }
            });
        }
    }

    function initChannelsPopUp() {
        $('.channels').live('click', function (e) {
            var epgItem = $(this).attr('data-channel-href');
            playLive(e, epgItem);
            e.preventDefault();
        });
    }
    return {
        initSearch: initSearch,
        showInactiveAccount: showInactiveAccount,
        initChannelsPopUp: initChannelsPopUp
    }
}();








