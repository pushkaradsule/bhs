﻿var zeeSlider = function () {
    //  var popUpTemplate = _.template("<div class='show-info-div'><h2><%= item.movieName %></h2><p class='show-channel'>Running time : <%= item.RunningTime %> min</p><p class='show-episode'>Actors Name : <%= item.Actors %></p><p class='show-details'><%= item.HtmlContent %></p><div class=show-details-btn><a href=javascript:void(0)><img src='images/show-info-moredetail.png' /></a></div>");
    var popUpTemplate = _.template("<div class='show-info-div'><p class='title'><%= item.movieName %></p><p class='desc'><%=item.Language %> <span>|</span> <%=item.Genre %> <span>|</span> <%= item.RunningTime %> min <span>|</span> <%= item.YearRelease %> </p> <p class='star'></p><p class='desc cast'><strong>Cast:  </strong><%= item.Actors %>..</p><p class='desc'><%= item.HtmlContent %>...</p><p class=mdetails><a href='<%= item.url %>'>Play</a></p></div>");

    var popUpTemplateShow = _.template("<div class='show-info-div'><p class='title'><%= item.movieName %></p><p class='desc'><%=item.Language %> <span> </p> <p class='star'></p><p class='desc cast'><strong>Cast:  </strong><%= item.Actors %>..</p><p class='desc'><%= item.HtmlContent %>...</p><p class=mdetails><a href='<%= item.url %>'>Episodes</a></p></div>");


    var popUpTemplateChannel = _.template("<div class='show-info-div'><p class='title'><%= item.channelName %></p><p class='desc cast'></p><p class='desc'><%= item.HtmlContent %></p><p class='mdetails'></div>");

    var localArray = [];

    function initAdvanced(dataArray, lazyLoad, showItems) {

        processScroll(dataArray, lazyLoad, showItems, true);


    }

    function init(dataArray) {
        processScroll(dataArray, true, 5);

    }

    function processScrollChannels(id) {

        id.forEach(function (entry) {

            var zeeScrollItem = $(entry);

            channelToolTip(entry);

            var nid = $("#" + zeeScrollItem.data("next-id"));
            var pid = $("#" + zeeScrollItem.data("prev-id"));


            zeeScrollItem.owlCarousel({
                itemsCustom: getSizeForMovieScroll(),
                lazyLoad: true,
                autoheight: true,
                navigation: false,
                touchDrag: false,
                mouseDrag: false,
                pagination: false,
                rewindNav: false,
                addClassActive: true,
                responsive: true,
                scrollPerPage: false,
                afterInit: function () {
                    zeeScrollItem.parents('.content-scroll').fadeIn('slow');
                },
                afterAction: function () {
                    if (this.owl.currentItem == 0) {
                        pid.addClass('disabled');
                    }
                    else {
                        pid.removeClass('disabled');
                    }
                    if (this.owl.currentItem + 6 == this.owl.owlItems.length - 1) {
                        nid.addClass('disabled');
                    }
                    else {
                        nid.removeClass('disabled');
                    }
                }

            });

            var owl = $(entry).data('owlCarousel');

            pid.click(function () {
                owl.prev();
            });

            nid.click(function () {
                owl.next();
            });

        });


    }



    function getSizeForMovieScroll() {
        return [
                 [380, 2],
                 [570, 3],
                 [760, 4],
                 [950, 5],
                 [1140, 6],
                 [1330, 7],
                 [1520, 8],
                 [1710, 9],
                 [1900, 10],
                 [2090, 11],
                 [2280, 12],
                 [2470, 13],
                 [2660, 14],
                 [2850, 15],
                 [3040, 16],
                 [3230, 17],
                 [3420, 18],
                 [3610, 19],
                 [3800, 20],
                 [3990, 21]

        ];
    }

    function processScroll(id, lazyLoad, showItems, hideToolTip) {
        id.forEach(function (entry) {

            if ($.inArray(entry, localArray) === -1) {
                if (lazyLoad == undefined) {
                    lazyLoad = true;
                    showItems = 5;
                }
                hideToolTip = typeof hideToolTip !== 'undefined' ? hideToolTip : false;

                var zeeScrollItem = $(entry);

                if (!hideToolTip) {
                    initToolTip(entry);
                }

                var nid = $("#" + zeeScrollItem.data("next-id"));
                var pid = $("#" + zeeScrollItem.data("prev-id"));


                zeeScrollItem.owlCarousel({
                    itemsCustom: getSizeForMovieScroll(),
                    lazyLoad: lazyLoad,
                    navigation: false,
                    touchDrag: false,
                    mouseDrag: false,
                    pagination: false,
                    rewindNav: false,
                    addClassActive: true,
                    responsive: true,
                    scrollPerPage: false,
                    afterInit: function () {
                        zeeScrollItem.parents('.content-scroll').fadeIn('slow');
                    },
                    afterAction: function () {
                        if (this.owl.currentItem == 0) {
                            pid.addClass('disabled');
                        } else {
                            pid.removeClass('disabled');
                        }
                        if (this.owl.currentItem + 4 == this.owl.owlItems.length - 1) {
                            nid.addClass('disabled');
                        } else {
                            nid.removeClass('disabled');
                        }
                    }

                });

                var owl = $(entry).data('owlCarousel');

                pid.click(function () {
                    owl.prev();
                });

                nid.click(function () {
                    owl.next();
                });

                localArray.push(entry);

            }
        });



    }

    function infiniteScroller(container, dataArray) {
        $(container).jscroll({
            loadingHtml: "<div align='center' class='loader-wrapper'><div id='spinningSquaresG'><div id='spinningSquaresG_1' class='spinningSquaresG'></div><div id='spinningSquaresG_2' class='spinningSquaresG'></div><div id='spinningSquaresG_3' class='spinningSquaresG'></div><div id='spinningSquaresG_4' class='spinningSquaresG'></div><div id='spinningSquaresG_5' class='spinningSquaresG'></div><div id='spinningSquaresG_6' class='spinningSquaresG'></div><div id='spinningSquaresG_7' class='spinningSquaresG'></div><div id='spinningSquaresG_8' class='spinningSquaresG'></div></div><div Id='loaderInfinite'></div></div>",
            padding: 20,
            nextSelector: '#nextlink',
            isList: dataArray == undefined ? true : false,
            debug: false,

            callback: function () {
                if (dataArray != undefined) {
                    processScroll(dataArray);
                }
                else {
                    initToolTip('.moviethumbnailli');
                }
            }
        });
    }

    function initToolTip(zeeScrollItem) {
        $(zeeScrollItem + ' div.item').each(function () {

            var tsQtip = $(this);

            var jsonobj = {
                movieName: tsQtip.data("assetname"),
                RunningTime: tsQtip.data("runningtime"),
                HtmlContent: tsQtip.data("desc"),
                Actors: tsQtip.data("actors"),
                YearRelease: tsQtip.data("year"),
                Language: tsQtip.data("language"),
                Genre: tsQtip.data("genre"),
                url: tsQtip.data("url"),
            };

            tsQtip.qtip({
                id: false,
                content: {
                    text: popUpTemplate({ item: jsonobj }),
                    title: {
                        text: false,
                        button: false
                    }
                },
                position: {
                    my: 'right center',
                    at: 'left center',
                    viewport: $(window),
                    adjust: {
                        method: 'flip none'
                    }
                },
                style: {
                    classes: 'qtip-wrapper qtip-show-info qtip-show-detail',
                    width: 342,
                    tip: {
                        width: 40,
                        height: 20,
                        border: 1

                    }
                },
                show: {
                    event: 'mouseenter',
                    solo: true,
                    delay: 800,
                    effect: function () {
                        $(this).fadeIn(800);
                    }
                },
                hide: {
                    delay: 100,
                    event: 'unfocus mouseleave',
                    fixed: true,
                    effect: function () {
                        $(this).fadeOut(500);
                    }
                },
                events: {

                    hide: function (event, api) {
                        var element = api.elements.tip;
                        // don't call destroy if not needed
                        if (element.data("qtip")) {
                            // the 'true' makes the difference
                            element.qtip("destroy", true);
                            // extra cleanup
                            element.removeData("hasqtip");
                            element.removeAttr("data-hasqtip");
                            jsonobj = null;
                        }
                    }
                }
            });
        });
    }


    function initToolTipShows(zeeScrollItem) {
        $(zeeScrollItem + ' div.item').each(function () {

            var tsQtip = $(this);

            var jsonobj = {
                movieName: tsQtip.data("assetname"),
                HtmlContent: tsQtip.data("desc"),
                Actors: tsQtip.data("actors"),
                YearRelease: tsQtip.data("year"),
                Language: tsQtip.data("language"),
                Genre: tsQtip.data("genre"),
                url: tsQtip.data("url"),
            };

            tsQtip.qtip({
                id: false,
                content: {
                    text: popUpTemplateShow({ item: jsonobj }),
                    title: {
                        text: false,
                        button: false
                    }
                },
                position: {
                    my: 'right center',
                    at: 'left center',
                    viewport: $(window),
                    adjust: {
                        method: 'flip none'
                    }
                },
                style: {
                    classes: 'qtip-wrapper qtip-show-info qtip-show-detail',
                    width: 342,
                    tip: {
                        width: 40,
                        height: 20,
                        border: 1

                    }
                },
                show: {
                    event: 'mouseenter',
                    solo: true,
                    delay: 800,
                    effect: function () {
                        $(this).fadeIn(800);
                    }
                },
                hide: {
                    delay: 100,
                    event: 'unfocus mouseleave',
                    fixed: true,
                    effect: function () {
                        $(this).fadeOut(500);
                    }
                },
                events: {

                    hide: function (event, api) {
                        var element = api.elements.tip;
                        // don't call destroy if not needed
                        if (element.data("qtip")) {
                            // the 'true' makes the difference
                            element.qtip("destroy", true);
                            // extra cleanup
                            element.removeData("hasqtip");
                            element.removeAttr("data-hasqtip");
                            jsonobj = null;
                        }
                    }
                }
            });
        });
    }

    function channelToolTip(zeeScrollItem) {

        $(zeeScrollItem + ' div.item').each(function () {

            var tsQtip = $(this);

            var jsonobj = {
                channelName: tsQtip.data("cn"),
                HtmlContent: tsQtip.data("desc"),
                url: tsQtip.data("url"),
            };

            tsQtip.qtip({
                id: false,
                content: {
                    text: popUpTemplateChannel({ item: jsonobj }),
                    title: {
                        text: false,
                        button: false
                    }
                },
                position: {
                    my: 'right center',
                    at: 'left center',
                    viewport: $(window),
                    adjust: {
                        method: 'flip none'
                    }
                },
                style: {
                    classes: 'qtip-wrapper qtip-show-info qtip-show-detail',
                    width: 342,
                    tip: {
                        width: 40,
                        height: 20,
                        border: 1

                    }
                },
                show: {
                    event: 'mouseenter',
                    solo: true,
                    delay: 800,
                    effect: function () {
                        $(this).fadeIn(800);
                    }
                },
                hide: {
                    delay: 100,
                    event: 'unfocus mouseleave',
                    fixed: true,
                    effect: function () {
                        $(this).fadeOut(500);
                    }
                },
                events: {

                    hide: function (event, api) {
                        var element = api.elements.tip;
                        // don't call destroy if not needed
                        if (element.data("qtip")) {
                            // the 'true' makes the difference
                            element.qtip("destroy", true);
                            // extra cleanup
                            element.removeData("hasqtip");
                            element.removeAttr("data-hasqtip");
                            jsonobj = null;
                        }
                    }
                }
            });
        });
    }


    function initZeeHomeSlider(sliderContainer) {

        new fws2().init({
            unique: sliderContainer, // ID of the slider instance 

            duration: "1000",  /* Slides Fade Speed (miliseconds) */
            hoverpause: "1",     /* Pause autoslide on mousehover, 0 - OFF, 1 - ON */
            pause: "6000",  /* Autoslide pause between slides (miliseconds), 0 - OFF */
            arrows: "1",     /* Show navigation Arrows, 0 - OFF, 1 - ON */
            bullets: "1"      /* Show navigation Bullets, 0 - OFF, 1 - ON */
        });
    }

    function initZeeMovieSlider(sliderContainer) {

        new fws2().init({
            unique: sliderContainer, // ID of the slider instance 

            duration: "1000",  /* Slides Fade Speed (miliseconds) */
            hoverpause: "01",     /* Pause autoslide on mousehover, 0 - OFF, 1 - ON */
            pause: "0",  /* Autoslide pause between slides (miliseconds), 0 - OFF */
            arrows: "0",     /* Show navigation Arrows, 0 - OFF, 1 - ON */
            bullets: "0"      /* Show navigation Bullets, 0 - OFF, 1 - ON */
        });
    }

    return {
        init: init,
        initAdvanced: initAdvanced,
        InfiniteScroller: infiniteScroller,
        InitZeeHomeSlider: initZeeHomeSlider,
        InitZeeMovieSlider: initZeeMovieSlider,
        InitZeeShowSlider:initZeeMovieSlider,
        initToolTip: initToolTip,
        InitToolTipShows:initToolTipShows,
        processScrollChannels: processScrollChannels

    }
}();



