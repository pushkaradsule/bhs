﻿function checkObjectCreation(idName) {
    var obj = document.getElementById(idName);
    if (obj != undefined) {
        LimelightPlayerUtil.initEmbed(idName); //,"http://ps2.delvenetworks.com/r/PlaylistService");
    } else {
        setTimeout(checkObjectCreation, 100, idName);
    }
}

function createPlayer(url, divId) {
    var w = 480;
    var h = 411;
    var swf = "http://video.limelight.com/player/loader.swf";
    var fv = "";
    var qsIndex = url.indexOf('?');
    if (qsIndex != -1) {
        var qsList = url.substring(qsIndex + 1, url.length).split('&');
        for (var i = 0; i < qsList.length; i++) {
            var val = qsList[i];
            var eqIndex = val.indexOf('=');
            if (eqIndex != -1) {
                var key = unescape(val.substring(0, eqIndex));
                var value = unescape(val.substring(eqIndex + 1, val.length));
                if (key == 'width') {
                    w = value;
                } else if (key == 'height') {
                    h = value;
                } else {
                    fv += key + "=" + value + "&amp;";
                }
            }
        }
    }
    document.getElementById(divId).innerHTML =
      '<span class="LimelightEmbeddedPlayer">' +
        '<object type="application/x-shockwave-flash"' +
            'id="limelight_player" name="limelight_player"' +
            'class="LimelightEmbeddedPlayerFlash"' +
            'width="' + w + '" height="' + h + '"' +
            'data="' + swf + '">' +
          '<param name="movie" value="' + swf + '"/>' +
          '<param name="wmode" value="window"/>' +
          '<param name="allowScriptAccess" value="always"/>' +
          '<param name="allowFullScreen" value="true"/>' +
          '<param name="flashVars" value="' + fv + '"/>' +
        '</object>' +
      '</span>';
    checkObjectCreation("limelight_player");
}cv  