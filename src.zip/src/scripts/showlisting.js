﻿/*Controller Code*/

var app = angular.module('show', ['smart-table']);
app.controller('ShowList', ['$scope', '$timeout', function ($scope, $timeout) {

    $scope.itemsPerPage = 12;
    $scope.currentPage = 0;
    $scope.rowCollection = window.showListing;
    $scope.itemsByPage = 12;
    $scope.ShowId = $('#show-detail-container').data('showid');
    $scope.ShowName = $('#show-detail-container').data('showname');

    $timeout(function () {
        $(".elt_1 a").click(function () { $scope.playEpisode(); });
    }, 1000);



    $scope.playEpisode = function (episode) {
        if (episode) {
            window.location.href = "/watch-episodes/" + $scope.ShowId + "/" + episode.EpisodeId + "/" + $scope.ShowName;
        } else {
            //get firstEpisode
            var episodeFirst = $scope.rowCollection[0];

            window.location.href = "/watch-episodes/" + $scope.ShowId + "/" + episodeFirst.EpisodeId + "/" + $scope.ShowName;
        }
    }


}]);

app.filter('truncate', function () {
    return function (text, length, end) {
        if (isNaN(length))
            length = 10;

        if (end === undefined)
            end = "...";

        if (text.length <= length || text.length - end.length <= length) {
            return text;
        }
        else {
            return String(text).substring(0, length - end.length) + end;
        }

    };
});

app.directive('showplay', function () {
    return {
        restrict: 'A',
        link: function (scope, element, attrs) {
            elem.bind('click', function () {
                $scope.playEpisode();
            });

        }
    };
});