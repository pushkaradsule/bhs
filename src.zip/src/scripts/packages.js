﻿var PackageService = function () {
    "use strict";


    function initialise() {
        var packageScroll = $("#package_items_div");

        packageScroll.owlCarousel({
            navigation: false,
            pagination: false,
            responsive: false,
            itemsScaleUp: false,
            items: 2,
            mouseDrag: false
        });


        $('#package-left-arrow').click(function () {
            packageScroll.trigger('owl.prev');
        });
        $('#package-right-arrow').click(function () {
            packageScroll.trigger('owl.next');
        });




        packageInteraction();
    }


    function addSubmitInfo() {
        $('#Checkout').click(function () {
            $("#selected_packaged_id").val($(".package-item-active").data("package-id"));
            $("#selected_packaged_duration").val($(".plan-selected").children().data("internal"));
            $('#addpackageform').submit();
        });
    }

    function packageInteraction() {

        var yearly = $("#yearly");
        var monthly = $("#monthly");
        var halfyearly = $("#halfyear");
        var quaterly = $("#quaterly");


        var template = _.template($('#packageDetailtmpl').html());

        var summaryTemplate = _.template($('#packageSummarytmpl').html());

        var summaryTemplateInit = _.template($('#packageSummarytmplInt').html());

        var packageName, packageprice,packageprice1, desc = null;
        var initWizard = false;
        $(".package-item").click(function () {
           
            $(".package-item").removeClass("package-item-active");
            $(this).addClass("package-item-active");

            if ($("#package-summary-box").hasClass("package-summary-active")) {
                $("#package-summary-box").removeClass("package-summary-active");
                $("#wizardnext").removeClass("active-wizard");
                $("#packageSummary").html(summaryTemplateInit());
            }


            packageName = $(this).data("name");
            packageprice = $(this).data("value");
            packageprice1 = $(this).data("value1");
            desc = $(this).data("desc");

            var channels = $(this).data("channels");


            yearly.show();
            monthly.show();
            halfyearly.show();
            quaterly.show();

            yearly.html(packageprice * 12);
            monthly.html(packageprice * 1);
            halfyearly.html(packageprice * 6);
            quaterly.html(packageprice * 3);


            if (!$("#wizardstart").hasClass("active-wizard")) {
                $("#wizardstart").addClass("active-wizard");
            }

            if (!$("#package-budget-box").hasClass("package-budget-active")) {
                initWizard = true;
                 $("#package-budget-box").addClass("package-budget-active");
            }
            var te = template({ images: channels, desc: '', PackageName: packageName, PackageDesc: desc, PackagePrice: packageprice1 });

            $("#packageDetails").hide().html(te).fadeIn(1000);

            $('.channel-image').hover(function () {
                $(this).addClass('transition');

            }, function () {
                $(this).removeClass('transition');
            });


            $(".plans-name").parent().removeClass("plan-selected");
        });


        $(".plans-name").click(function () {
            if (!initWizard) return false;
            $(".plans-name").parent().removeClass("plan-selected");
            $(this).parent().addClass("plan-selected");
            $("#package-summary-box").addClass("package-summary-active");

            var price = $(this).data("plan") * packageprice;
            var planName = $(this).data("name");

            if (!$("#wizardnext").hasClass("active-wizard")) {
                $("#wizardnext").addClass("active-wizard");
            }

            var t2 = summaryTemplate({ PackageName: packageName, PackagePrice: price, PlanName: planName });

            $("#packageSummary").hide().html(t2).fadeIn(1000);

            addSubmitInfo();
            return true;
        });



        setTimeout(function () {
            var divItem = $("div[data-selected='True']");
            if (divItem.length > 0) {
                var seq = divItem.data("seq");
                divItem.click();
                $("#package_items_div").data('owlCarousel').goTo(seq);
            }
        }, 400);

    }

    return {
        Initialise: initialise
    }
}();








