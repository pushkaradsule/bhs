
var jwPlayerResumable = (function ($, jwp) {
    'use strict';

    var jwPlayerResumable = {
        _video_id: "mediaplayer",
        _content_type_id: "M",
        _show_div_after_secs: 10,
        _skip_beforeseek_event: false,
        _div_to_show: ".hide",
        _fp: function () {
            return jwplayer();
        },
        getCurrentPos: function () {
            return jwplayer().getPosition();
        },
        setCurrentPos: function (seconds) {
            this._skip_beforeseek_event = true;

            if (typeof (jwplayer().getDuration()) == "undefined") {
                setTimeout(function () {
                    jwPlayerResumable.setCurrentPos(jwPlayerResumable.getTimePosition());
                }, 1000);
                return;
            }

            if (jwplayer().getDuration() == -1 || jwplayer().getDuration() > Number(seconds + 5)) {
                jwplayer().seek(jwPlayerResumable.getTimePosition());
            }
            this._skip_beforeseek_event = false;
        },
        setTimePosition: function (time) {
            $.totalStorage(this._video_id, time);
        },
        getTimePosition: function () {
            return $.totalStorage(this._video_id);
        },
        resumePlayBack: function (moreSettings) {
            var time = this.getTimePosition();
            this.setCurrentPos(time);
            return this;
        },
        init: function (id, videotype, baseurl, options) {

            var currentTime = 0;
            if (typeof (id) != "undefined") {
                this._video_id = String(id);
            }
            if (typeof (videotype) != "undefined") {
                this._content_type_id = String(videotype);
            }
            var videoId = this._video_id;
            var token = $('#antiForgeryToken').val();
            var isinProgress = false;
            var vidTYpe = this._content_type_id;

            
            jwplayer().onTime(function (e) {

                if (vidTYpe === "L" || vidTYpe === "C") {
                    return;
                }

                try {
                    var time = Math.floor(e.position) % 60;

                    if (!isinProgress && time === 0) {
                        isinProgress = true;
                        $.ajax({
                            url: baseurl + 'vb/' + videoId + '/' + Math.floor(e.position) + '/' + vidTYpe,
                            type: "GET",
                            beforeSend: function (xhr) {
                                xhr.setRequestHeader('RequestVerificationToken', token);
                            }
                        }).done(function () {
                            isinProgress = false;
                        });;


                    }
                } catch (e) {
                    console.log(e);

                }

            });

          
            return this;
        }
    }

    return jwPlayerResumable;

}(jQuery, jwplayer));