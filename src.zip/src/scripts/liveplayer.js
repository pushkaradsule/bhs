﻿"use strict";
var app = angular.module('main', []);

app.service('zeeEpgService', ['$http', '$q', function ($http, $q) {
    return {
        getEpg: function (url, request, token) {

            var deferred = $q.defer();
            $http(
                { method: 'POST', data: request, url: url, cache: false, headers: { 'RequestVerificationToken': token } }
                ).success(function (data) {
                    deferred.resolve(data);
                }).error(function (error) {
                    deferred.reject(error);
                });
            return deferred.promise;
        },
        getChannels: function (url, token) {
            var deferred = $q.defer();
            $http(
                { method: 'GET', url: url, cache: false, headers: { 'RequestVerificationToken': token } }
                ).success(function (data) {
                    deferred.resolve(data);
                }).error(function (error) {
                    deferred.reject(error);
                });
            return deferred.promise;
        },
        getCatchUp: function (url, request, token) {
            var deferred = $q.defer();
            $http(
                { method: 'POST', url: url, data: request, cache: false, headers: { 'RequestVerificationToken': token } }
                ).success(function (data) {
                    deferred.resolve(data);
                }).error(function (error) {
                    deferred.reject(error);
                });
            return deferred.promise;
        }
    };
}
]);


app.controller('LivePlayer', function ($scope, $http, $timeout, zeeEpgService, $window) {

    $scope.msInDay = 86400000;
    $scope.allChannels = [];
    $scope.now = new Date();
    var baseUrl = $window.baseUrl;
    $scope.EpgItems = [];
    $scope.playerInfo = {};
    $scope.todayBoD = new Date($scope.now.getFullYear(), $scope.now.getMonth(), $scope.now.getDate());
    $scope.todayBoD.setTime($scope.todayBoD.getTime() + 1000);
    $scope.todayBoD = (new Date($scope.todayBoD));
    $scope.playerLoading = false;
    $scope.state = true;

    $scope.getEoD = function (date) {
        var result = new Date(date);
        result.setTime(result.getTime() + $scope.msInDay - 2000);
        return new Date(result);
    };

    var initPlayer = function () {
        $scope.playerInfo = $('#zee-player-wrapper').data('player-info');
        zeeplayer.Initialise($scope.playerInfo, "zeeplayer");

    }

    $scope.isEpgItemOnNow = function (epgItem) {
        var start = Date.parse(epgItem.StartDate);
        var end = Date.parse(epgItem.EndDate);
        var result = (start <= $scope.now) && ($scope.now <= end);
        epgItem.IsPlayingNow = result;
        epgItem.IsCatchUp = $scope.isPastEpgItem(epgItem);

        return result;
    }

    $scope.goBack = function () {
        $window.history.back();
    }

    $scope.isPastEpgItem = function (epgItem) {
        var end = new Date(epgItem.EndDate);
        return (end <= $scope.now);
    }

    $scope.epgItemProgress = function (epgItem) {
        var result = 0;
        if ($scope.isEpgItemOnNow(epgItem)) {
            var start = Date.parse(epgItem.StartDate);
            var end = Date.parse(epgItem.EndDate);
            result = (($scope.now - start) / (end - start));
        }
        return result;
    }

    $timeout(initPlayer, 100);

    //channel info
    $scope.ProgramInfo = $('#zee-player-wrapper').data('program');

    $scope.channels = [];

    function getChannelInfo(d) {

        var date = $scope.todayBoD;

        if (d) {
            date = new Date(d);
        }
        var urlChannel = baseUrl + "MyChannels";

        zeeEpgService.getChannels(urlChannel, $('#antiForgeryToken').val())
        .then(function (data) {
            $scope.allChannels = data;

            var loadChannelList = function () {
                var liveCarousel = $('#zee_live_carousel_channels');

                liveCarousel.owlCarousel({
                    margin: 10,
                    nav: true,
                    dots: false,
                    pullDrag: true,
                    loop: false,
                    autoWidth: true,
                    navText: ['&#x2190;', '&#x2192;'],
                    responsiveClass: true,
                    mouseDrag: true,
                    responsive: {
                        0: {
                            nav: false
                        },
                        768: {
                            nav: false
                        },
                        992: {
                            nav: true
                        }
                    }
                });
            };

            $timeout(loadChannelList, 1000);
        });

        var url = baseUrl + "EpgItemByChannel";
        var request = {
            "TimeStart": date.toISOString(),
            "TimeEnd": $scope.getEoD(date).toISOString(),
            "ChannelIDs": $scope.ProgramInfo.AssetId
        };

        zeeEpgService.getEpg(url, request, $('#antiForgeryToken').val())
        .then(function (data) {
            var loadEpgList = function () {

                var liveCarousel = $('#zee_live_carousel_programs');

                liveCarousel.owlCarousel({
                    margin: 10,
                    nav: true,
                    dots: false,
                    pullDrag: true,
                    loop: false,
                    autoWidth: true,
                    navText: ['&#x2190;', '&#x2192;'],
                    responsiveClass: true,
                    mouseDrag: true,
                    responsive: {
                        0: {
                            nav: false
                        },
                        768: {
                            nav: false
                        },
                        992: {
                            nav: true
                        }
                    }
                });


            }
            var countUp = function () {
                var queryResult = Enumerable.from(data)
                           .where(function (x) {
                               return Date.parse(x.StartDate) <= $scope.now && $scope.now <= Date.parse(x.EndDate);
                           })
                           .toArray();

                $scope.EpgItems = data;


                if (queryResult.length > 0) {
                    $scope.programmeTitle = queryResult[0].Title;
                    $scope.programmeTime = queryResult[0].StartDate;
                    $scope.programmeEndTime = queryResult[0].EndDate;
                }
            }

          
            $timeout(countUp, 100);
          
            $timeout(loadEpgList, 1000);




        });

        $scope.playFromBegining = function () {

            // $scope.watchContent();
        };

        $scope.pausePlayer = function () {
            $scope.state = $scope.state === true;
            zeeplayer.pause($scope.state);
        }

        $scope.watchContent = function (epgItem) {

            var url = baseUrl + "WatchCatchUp";

            $scope.playerLoading = true;

            var request = {
                "EpgItemId": epgItem.EpgItemId,
                "ChannelId": epgItem.ChannelId,
                "UniqueVisitorId": $scope.playerInfo.se
            };

            zeeEpgService.getCatchUp(url, request, $('#antiForgeryToken').val()).then(function (response) {
                var data = response.Player;
                var playerObj =
                  {
                      s: data.StreamName,
                      h: data.PlayerHeight,
                      w: data.PlayerWidth,
                      BaseUrl: baseUrl,
                      p: data.Position,
                      l: data.LiveStreaming,
                      k: data.SecurityKey,
                      i: data.Id,
                      t: data.ContentType,
                      c: data.ChannelName,
                      pr: data.ProgrammeName,
                      se: data.SessionGuid
                  };

                $scope.playerInfo = playerObj;
                $scope.playerLoading = false;
                zeeplayer.Initialise($scope.playerInfo, "zeeplayer");
            });

        }
    }

    $scope.openEpgGuide = function ($event) {

        $event.preventDefault();

        var ts = $("#zee_live_programs"),
            tsUl = ts.parents('ul'),
            tsLi = ts.parent(),
            tsCarousel = tsLi.find('.zee-live-carousel');

        $('.zee-live-helper > ul > li.zee-live-all-channels, .zee-live-helper > ul > li.zee-live-all-channels > div.zee-live-carousel').removeClass('open');
        tsUl.removeClass('channels-open');
        $('.zee-live-all-channels').find('.action-url').removeClass('channel-arrow');

        $timeout(function () {
            tsUl.toggleClass('program-open');
            tsLi.toggleClass('open');
            tsCarousel.toggleClass('open');
            setTimeout(function () {
                ts.toggleClass('program-arrow');
            }, 200);
        }, 300);
    }

    $scope.openChannels = function ($event) {

        $event.preventDefault();

        var ts = $("#zee_live_channels"),
            tsUl = ts.parents('ul'),
            tsLi = ts.parent(),
            tsCarousel = tsLi.find('.zee-live-carousel');

        $('.zee-live-helper > ul > li.zee-live-show-guide, .zee-live-helper > ul > li.zee-live-show-guide > div.zee-live-carousel').removeClass('open');
        tsUl.removeClass('program-open');
        $('.zee-live-show-guide').find('.action-url').removeClass('program-arrow');

        setTimeout(function () {
            tsUl.toggleClass('channels-open');
            tsLi.toggleClass('open');
            tsCarousel.toggleClass('open');
            setTimeout(function () {
                ts.toggleClass('channel-arrow');
            }, 200);
        }, 300);


    }

    $scope.playChannel = function (channel) {
        //$scope.ProgramInfo
        console.log(channel);
    }

    if ($scope.ProgramInfo.IsLive) {
        getChannelInfo();
    } else {
        console.log($scope.ProgramInfo);
        $scope.programmeTitle = $scope.ProgramInfo.ProgrammeName;
        $scope.programmeTime = $scope.ProgramInfo.StartTime;
        $scope.programmeEndTime = $scope.ProgramInfo.EndTime;

        getChannelInfo($scope.programmeTime);
    }
});