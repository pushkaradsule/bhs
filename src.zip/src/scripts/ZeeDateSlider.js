﻿app.directive('zeeDataslider', ['$timeout', function ($timeout) {
    return {
        restrict: 'EAC',
        templateUrl: 'scripts/templates/ZeeEpgDatesSlider.html',
        replace: false,
        link: function (scope, element, attrs) {
         
            $timeout(function () {
                var guideDaysScroll = angular.element(element);

                guideDaysScroll.owlCarousel({
                    navigation: false,
                    pagination: false,
                    responsive: false,
                    itemsScaleUp: false,
                    items: 14,
                    mouseDrag: false
                });

                $(attrs.nextImage).click(function () {

                    guideDaysScroll.trigger('owl.prev');

                });

                $(attrs.prevImage).click(function () {

                    guideDaysScroll.trigger('owl.next');
                });

                var queryResult = Enumerable.from(scope.dates).where(function (x) { return x.active === true; }).toArray();

                var owl = guideDaysScroll.data('owlCarousel');

                owl.jumpTo(queryResult[0].seq);

            }, 10);

        }
    }
}]);




app.service('zeeEpgService', function ($http, $q) {
    return {
        getTodaysEpgData: function () {
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: 'http://zeeservices.azurewebsites.net/ZeeEpg'
            }).success(function (data) {
                deferred.resolve(data);
            }).error(function (error) {
                deferred.reject(error);
            });

            return deferred.promise;
        },
        getEpgbyDate: function (day) {
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: 'http://zeeservices.azurewebsites.net/EpgForDate/' + day.displaydate
            }).success(function (data) {
                deferred.resolve(data);
            }).error(function (error) {
                deferred.reject(error);
            });

            return deferred.promise;
        }
    };
});