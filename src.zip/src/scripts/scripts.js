;
(function($) {

	"use strict";

	$(document).ready(function() {

		var zeeSVGsToInject = document
				.querySelectorAll('img.icon-svg');
	
		var injectorOptions = {
			evalScripts : 'once',
			pngFallback : zee_localize.site_path + 'icons/png',
			each : function(svg) {
				// callback
			}
		};
	
		// Trigger the injection
		SVGInjector(zeeSVGsToInject, injectorOptions, function(totalSVGsInjected) {
			// callback
		});
		
		
		window.jRes.addFunc({
		    breakpoint: ['tablet', 'laptop', 'desktop'],
		    enter: function() {
		    	$('.zee-mobile-search-form').removeClass('show');
		    	$('.zee-blur-overlay').removeClass('show');
				$('.zee-mobile-signup-buttons').fadeOut('fast');
				$('body').removeClass('overlay-blur');
		    },
		    exit: function() {
		    }
		});
		
		$('.zee-toolbar-search input[type="text"]').on('focus', function(){
			
			$(this).parents('.zee-toolbar-search').removeClass('blur').addClass('focus');
			
		});
		
		$('.zee-toolbar-search input[type="text"]').on('blur', function(){
			
			$(this).parents('.zee-toolbar-search').removeClass('focus').addClass('blur');
			
		});
		
		
		$('#zee_toolbar_menu').on('click', function(e){
			e.preventDefault();
		});
		
		// launch mobile search field
		$('#search_mobile_btn').on('click', function(e){
			e.preventDefault();
			$('.zee-mobile-search-form').addClass('show');
			$('.zee-mobile-search-form').find('input[type="search"]').focus();
		});
		
		// close mobile search field
		$('#zee_mobile_search_close').on('click', function(e){
			e.preventDefault();
			$('.zee-mobile-search-form').removeClass('show');
		});
		
		// launch signup action popup
		$('#zee_mobile_signiup_btn').on('click', function(e){
			e.preventDefault();
			$('.zee-blur-overlay').addClass('show');
			$('.zee-mobile-signup-buttons').fadeIn('slow');
			$('body').addClass('overlay-blur');
		});
		
		// signup popup close action
		$('#signup_close_btn').on('click', function(e){
			e.preventDefault();
			
			$('.zee-mobile-signup-buttons').fadeOut('slow', function(){
				$('.zee-blur-overlay').removeClass('show');
				$('body').removeClass('overlay-blur');
			});			
		});
		
		// change toolbar background
		$('.zee-header-wrapper').waypoint(function(direction) {
			if (direction == 'down'){
				$('.zee-toolbar').addClass('zee-toolbar-fill');
			}
			else {
				$('.zee-toolbar').removeClass('zee-toolbar-fill');
			}
		},{
			offset: -200
		});
		
		// change toolbar size
		$('.zee-content-wrapper').waypoint(function(direction) {
			if (direction == 'down'){
				$('.zee-toolbar').addClass('zee-toolbar-compact');
			}
			else {
				$('.zee-toolbar').removeClass('zee-toolbar-compact');
			}
		},{
			offset: 50
		});
		
		// browse menu
		$('.zee-toolbar-menu').on('mouseenter touchstart pointerdown', function(){
			$(this).addClass('show');
		});
		$('.zee-toolbar-menu').on('mouseleave', function(){
			$(this).removeClass('show');
		});
		
		$('body').on('touchstart pointerdown', function(){
			if($('body').hasClass('menu-open')){
				$('.zee-toolbar-menu').removeClass('show');
				$('body').removeClass('menu-open');
			}
			else {
				$('body').addClass('menu-open');
			}
		});
		
		// user menu
		$('.zee-toolbar-user').on('mouseenter', function(){
			$(this).addClass('show');
		});
		$('.zee-toolbar-user').on('mouseleave', function(){
			$(this).removeClass('show');
		});
		
		// mobile menu
		$('#zee_mobile_menu_trigger').on('click', function(e){
			
			e.preventDefault();
			
			$('.zee-mobile-menu').addClass('active');			
			$('.zee-mobile-menu-overlay').addClass('active');
			
			$('body, .zee-body-wrapper').addClass('mobile-menu-open');
			
		});
		
		$('#zee_mobile_menu_close').on('click', function(e){
			
			e.preventDefault();
			
			$('.zee-mobile-menu').removeClass('active');
			$('.zee-mobile-menu-overlay').removeClass('active');
			$('body, .zee-body-wrapper').removeClass('mobile-menu-open');
		});
		
		// home banner
		imagesLoaded( '#zee_main_banner > li:first-child', function(){
			$('#zee_main_banner').pgwSlider({
				adaptiveHeight : true,
				displayList : false,
				autoSlide : false,
				displayControls : true,
				intervalDuration : $('#zee_main_banner').data('duration'),
				beforeSlide : function(){
					$('.pgwSlider').removeClass('slide-active');
				},
				afterSlide : function(){
					$('.pgwSlider').addClass('slide-active');
					$.waypoints('refresh');
				}
			});
			setTimeout(function(){
				$('.zee-main-banner').removeClass('min-height');
			}, 400);
		});
		
		// zee carousel
		$('.zee-carousel-data').owlCarousel({
		    margin : 10,
		    nav : true,
		    dots : false,
		    lazyLoad : true,
		    loop : true,
		    baseClass : 'zee-carousel',
		    themeClass : 'zee-carousel-theme',
		    itemClass : 'zee-carousel-item',
		    navText : ['&nbsp;','&nbsp;'],
		    mouseDrag : false,
		    responsive :{
		    	0:{
		            items:2
		        },
		        479:{
		            items:3
		        },
		        760:{
		            items:4
		        },
		        950:{
		            items:5
		        },
		        1140:{
		            items:6
		        },
		        1520:{
		            items:7
		        },
		        1710:{
		            items:8
		        },
		        1900:{
		            items:9
		        },
		        2090:{
		            items:10
		        },
		        2280:{
		            items:11
		        },
		        2470:{
		            items:12
		        },
		        2660:{
		            items:13
		        },
		        2850:{
		            items:14
		        },
		        3040:{
		            items:15
		        },
		        3230:{
		            items:16
		        },
		        3420:{
		            items:17
		        },
		        3610:{
		            items:18
		        },
		        3800:{
		            items:19
		        },
		        3990:{
		            items:20
		        }
		    }
		});
		
		

	}); // document.ready

})(jQuery);