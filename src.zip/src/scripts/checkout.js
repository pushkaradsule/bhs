﻿var app = angular.module('checkout', []);

app.controller('CheckoutCtrl', function ($scope) {

    $scope.billingAddress = {};

    $scope.$watch('shippingIsSameAsBilling', function (value) {
        if (value) {
            $scope.shippingAddress = $scope.billingAddress;
        } else {
            $scope.shippingAddress = angular.copy($scope.shippingAddress);
        }
    });

});
