﻿var zeeplayer = function () {
    "use strict";
    var message = "<p><i class='banner-play-icon'></i><span>Resume</span></p>";
    var myStreamingTag = new ns_.StreamingTag({ customerC2: '20072668' });
    function setupPlayer(playerInfo, playerDiv) {
        var options = playerInfo;
        var f = $.rc4Decrypt(options.k, options.s);

        var playerOptions = {
            file: f,
            autostart: options.p === 0 ? true : false,
            primary: 'flash',
            base: options.BaseUrl + "js/",
            androidhls: true,
            analytics: {
                enabled: false
            },
            logo: {
                file: options.BaseUrl + 'images/zee-logo-50px-59-75percent.png',
                link: 'http://www.zeefamily.tv',
                position: 'top-left',
                out: 0.2
            },
            width: "100%",
            aspectratio: "16:9",
            abouttext: 'ZeeFamily TV',
            aboutlink: 'http://www.zeefamily.tv',
            events: {
                onComplete: function () {
                    myStreamingTag.stop();
                }
            }
        };


        if (options.p > 0) {
            playerOptions.plugins = {
                '/overlay.js': {
                    text: '<div id="overlayDiv" style="position: relative"><button class="resumeButton" onclick="resumePlayback()"></button> <span class="resumePlayback">Resume Playback</span></div>'
                }
            }



        }



        jwplayer(playerDiv).setup(playerOptions).onReady(function () {
            jwPlayerResumable.init(options.i, options.t, options.BaseUrl, options);
        }).onError(function (error) {
            console.log(error);
        });

        if (options.p > 0) {
            $("#resume-movie-wrapper").removeClass("live-de-active");
            $("#resume-movie").click(function () {
                jwplayer().seek(options.p);
                $("#resume-movie-wrapper").addClass("live-de-active");
            });

        } else {
            $("#resume-movie-wrapper").hide();
        }

        jwplayer().onError(function () {
            jwplayer().load({
                file: "http://content.jwplatform.com/videos/7RtXk3vl-52qL9xLP.mp4",
                image: "http://content.jwplatform.com/thumbs/7RtXk3vl-480.jpg"
            });
            jwplayer().play();
        });

        jwplayer().onPlay(function () {
            
               var metadata = {
                    ns_st_ci: "137849", // Content Asset ID
                    c4: playerInfo.c, // Dictionary Classification Value
                    c3: playerInfo.t === "S" ? "SHOWS" : "MOVIE", // Unused Dictionary Classification Value
                    c6: "*null" // Unused Dictionary Classification Value
                };

               myStreamingTag.playVideoContentPart(metadata);

            $("#pause").removeClass("live-de-active");
            $("#play").addClass("live-de-active");
        });

        jwplayer().onPause(function () {
            $("#pause").addClass("live-de-active");
            $("#play").removeClass("live-de-active");
            myStreamingTag.stop();
        });

     
        function resumePlayback() {
            $("#overlayDiv").hide();
            jwplayer().seek(options.p);
        }

        if (options.p > 0) {
            window.resumePlayback = null;
            window.resumePlayback = resumePlayback;
        }

        function stopPlayers() {

            jwplayer().stop();
            myStreamingTag.stop();
        }



        window.onbeforeunload = stopPlayers;

    }

    function initialise(playerInfo, playerDiv) {
        jwplayer.key = "DI3ZKPTDsRnwzA7agZWesoh22dGyArm4E3RX6w==";
        setupPlayer(playerInfo, playerDiv);
    }

    function pause() {
        jwplayer().pause();
    }

    function play() {
        jwplayer().play();
    }

    return {
        Initialise: initialise,
        pause: pause,
        play: play
    }
}();


