<?php $page='movies'; include 'inc/head.php'; ?>



<div class="zee-header-wrapper">
    <div class="zee-main-banner min-height">
        <ul class="pgwSlider zee-banner-slider" id="zee_main_banner" data-duration="10000">
            <li><a href="/movie_player.php">
                <img src="//az608750.vo.msecnd.net/thumb/0060776.jpeg?v=432">
            </a></li>
        </ul>
    </div>


</div>
<div class="zee-content-wrapper">

    <div class="container-fluid" ng-controller="MovieController" ng-app="movies">
        <input id="antiForgeryToken" type="hidden" value='xRViqVJ7DoRsPAsTRJ4fX_FnXp4RjXyuwaPDDdHtSHzi-yv9mebrvRdE-YgIwa9EUPdPesGwteZFe5PvC9OB1yHHzXNRbF9x2oqYVSHIMq01:MElP6MQEYsHQ0cRWIKDfhbp0C70P8kv-294uHwuSDXCPUGL3uXsTEEW4quHpfwrFcDNS5DbaZn14k7nL3Opfprpw2aNo0VdIBFM22oZb9eI1'/>
        <h3 class="section-title">Movies</h3>
        <form class="form-horizontal" role="form">
            <div class="form-group zee-movies-filters">
                <div class="col-lg-2 col-md-4 col-sm-6 zee-movies-filter-1">
                    <select class="form-control" id="categories">
                        <option value="">Categories</option>
                        <option value="">All Movies</option>
                        <option value="PL-LATEST">New Releases</option>
                        <option value="PL-ALL TIME FAVOURITES">All Time Favorites</option>
                        <option value="ACTION">Action</option>
                        <option value="ADVENTURE">Adventure</option>
                        <option value="ANIMATION">Animation</option>
                        <option value="BIOGRAPHY">Biography</option>
                        <option value="COMEDY">Comedy</option>
                        <option value="CRIME">Crime</option>
                        <option value="DOCUMENTARY">Documentary</option>
                        <option value="DRAMA">Drama</option>
                        <option value="FAMILY">Family</option>
                        <option value="FANTASY">Fantasy</option>
                        <option value="FILM-NOIR">Film-Noir</option>
                        <option value="HISTORY">History</option>
                        <option value="HORROW">Horror</option>
                        <option value="MUSIC">Music</option>
                        <option value="MYSTERY">Mystery</option>
                        <option value="ROMANCE">Romance</option>
                        <option value="SCI-F">Sci-FI</option>
                        <option value="SHORT">Short</option>
                        <option value="SPORT">Sport</option>
                        <option value="THRILLER">Thriller</option>
                        <option value="SUSPENSE">Suspense</option>
                        <option value="MYTHOLOGY">Mythology</option>
                        <option value="ENTERTAINMENT">Entertainment</option>
                        <option value="SPECIAL EVENTS">Special Events</option>
                    </select>
                </div>
                <div class="col-lg-2 col-md-4 col-sm-6 zee-movies-filter-2">
                    <select class="form-control" id="language">
                        <option value="">Language</option>
                        <option value="hin">Hindi</option>
                        <option value="mar">Marathi</option>
                        <option value="ben">Bangla</option>
                         <option value="tel">Telugu</option>
                        <option value="tam">Tamil</option>
                        <option value="kan">Kannada</option>
               
                    </select>
                </div>
                <div class="col-lg-2 col-md-4 col-sm-6 zee-movies-filter-3">
                    <input type="text" class="form-control" placeholder="search keywords" ng-model="movieList.searchText" />
                </div>
                <div class="col-lg-4 col-md-4 col-sm-6 zee-movies-filter-4">
                    <a href="javascript:void(0);" class="zee-button zee-primary-btn" ng-click="filterByAttribute()"><span class="text">Filter</span></a>
                </div>
            </div>

        </form>
        <div class="zee-movies-sorting">
            <span class="zee-movies-sorting-label">Sort</span>
            <div id="zee_movies_sorting" class="zee-movies-alpha-sorting">
                <ul>
                        <li><a href="javascript:void(0);"  ng-click="filterByAlphabet('A')">A</a></li>
                        <li><a href="javascript:void(0);"  ng-click="filterByAlphabet('B')">B</a></li>
                        <li><a href="javascript:void(0);"  ng-click="filterByAlphabet('C')">C</a></li>
                        <li><a href="javascript:void(0);"  ng-click="filterByAlphabet('D')">D</a></li>
                        <li><a href="javascript:void(0);"  ng-click="filterByAlphabet('E')">E</a></li>
                        <li><a href="javascript:void(0);"  ng-click="filterByAlphabet('F')">F</a></li>
                        <li><a href="javascript:void(0);"  ng-click="filterByAlphabet('G')">G</a></li>
                        <li><a href="javascript:void(0);"  ng-click="filterByAlphabet('H')">H</a></li>
                        <li><a href="javascript:void(0);"  ng-click="filterByAlphabet('I')">I</a></li>
                        <li><a href="javascript:void(0);"  ng-click="filterByAlphabet('J')">J</a></li>
                        <li><a href="javascript:void(0);"  ng-click="filterByAlphabet('K')">K</a></li>
                        <li><a href="javascript:void(0);"  ng-click="filterByAlphabet('L')">L</a></li>
                        <li><a href="javascript:void(0);"  ng-click="filterByAlphabet('M')">M</a></li>
                        <li><a href="javascript:void(0);"  ng-click="filterByAlphabet('N')">N</a></li>
                        <li><a href="javascript:void(0);"  ng-click="filterByAlphabet('O')">O</a></li>
                        <li><a href="javascript:void(0);"  ng-click="filterByAlphabet('P')">P</a></li>
                        <li><a href="javascript:void(0);"  ng-click="filterByAlphabet('Q')">Q</a></li>
                        <li><a href="javascript:void(0);"  ng-click="filterByAlphabet('R')">R</a></li>
                        <li><a href="javascript:void(0);"  ng-click="filterByAlphabet('S')">S</a></li>
                        <li><a href="javascript:void(0);"  ng-click="filterByAlphabet('T')">T</a></li>
                        <li><a href="javascript:void(0);"  ng-click="filterByAlphabet('U')">U</a></li>
                        <li><a href="javascript:void(0);"  ng-click="filterByAlphabet('V')">V</a></li>
                        <li><a href="javascript:void(0);"  ng-click="filterByAlphabet('W')">W</a></li>
                        <li><a href="javascript:void(0);"  ng-click="filterByAlphabet('X')">X</a></li>
                        <li><a href="javascript:void(0);"  ng-click="filterByAlphabet('Y')">Y</a></li>
                        <li><a href="javascript:void(0);"  ng-click="filterByAlphabet('Z')">Z</a></li>
                </ul>
            </div>
        </div>

        <div class="zee-movies-grid" infinite-scroll='movieList.nextPage()' infinite-scroll-disabled='movieList.busy || movieList.complete' infinite-scroll-distance='1'>
            <div class="movies-grid-items" ng-repeat="a in movieList.items">
                <div class="item">
                    <div class="carousel-helper-wrapper">
                        <a href="{{a.Url}}" class="carousel-thumb-action" qtip-assetname="{{a.AssetName}}" qtip-thumbnail="{{a.ImageUrl}}"
                            qtip-genre="{{a.Genre}}"
                            qtip-runningtime="{{a.ShowTime}}"
                            qtip-desc="{{a.HtmlContent}}"
                            qtip-actors="{{a.Actors}}"
                            qtip-year="{{a.YearRelease}}"
                            qtip-language="{{a.Language}}"
                            qtip-location="AsiaTv"
                            qtip-url="{{a.Url}}" qtip></a>
                        <span class="carousel-helper carousel-helper-play">
                            <a ng-href="{{a.Url}}"></a>
                        </span>
                        <span class="carousel-helper carousel-helper-info">
                            <a href="javascript:void(0);" ng-click="showMobileInfo(a)" class="carousel-mobile-info"></a>
                        </span>
                    </div>
                    <img ng-src="{{a.ImageUrl}}">
                </div>

            </div>

            <div ng-show='movieList.busy' style="clear: both; margin: 0 auto;">
                <div class='loading' style='margin-left: 45%;'>
                    <div class='loading-bar big'></div>
                    <div class='loading-bar big'></div>
                    <div class='loading-bar big'></div>
                    <div class='loading-bar big'></div>
                    <div class='loading-bar big'></div>
                    <div class='loading-bar big'></div>
                    <div class='loading-bar big'></div>
                    <div class='loading-bar big'></div>
                    <div class='loading-bar big'></div>
                    <div class='loading-bar big'></div>
                </div>
            </div>

            <div ng-show='movieList.noResult' style="clear: both; margin: 0 auto; width: 200px;">Sorry no results! </div>
        </div>



    </div>
</div>

<?php include 'inc/footer.php'; ?>