<?php $footer_auto = '0'; include 'inc/head.php'; $page='checkout'; ?>
<div class="zee-content-wrapper no-banner zee-myaccount-body">
    <div class="my-account-welcome">
        <div class="container">
            <div class="row">
                <h3>Order Summary</h3>
            </div>
        </div>
    </div>
    <div class="container zee-myaccounter-container zee-checkout-container">


        <div class="package-steps package-checkout-steps">
            <span class="package-steps-heading">Thank you</span>

            <div style="font-size: 16px; text-align: center; margin-top: 20px; margin-bottom: 29px;">
                You are now registered with ZEE Family. You will be charged after your free trial ends.<br>
                Please log in to start enjoying the best of South Asian entertainment!
            </div>
        </div>

        <table class="footable table toggle-circle-filled default footable-loaded" id="zee_package_checkout_summary">
            <thead>
                <tr>
                    <th class="footable-visible footable-first-column">Package</th>
                    <th data-hide="phone" class="footable-visible">Plan</th>
                    <th data-hide="phone" class="checkout-subtotal footable-visible footable-last-column">Price</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td class="footable-visible footable-first-column"><span class="footable-toggle"></span>ZEE Family Pack</td>
                    <td class="footable-visible">Year</td>
                    <td class="checkout-subtotal footable-visible footable-last-column">? 2,988.00</td>
                </tr>
                <tr>
                    <td class="footable-visible footable-first-column"><span class="footable-toggle"></span>ZEE Family Marathi Pack</td>
                    <td class="footable-visible">Year</td>
                    <td class="checkout-subtotal footable-visible footable-last-column">? 1,188.00</td>
                </tr>

            </tbody>
        </table>

        <div class="clearfix" style="height: 20px;"></div>




        <table class="footable table toggle-circle-filled default footable-loaded" id="zee_receipt_summary">
            <thead>
                <tr>
                    <th class="footable-visible footable-first-column">Receipt No.</th>
                    <th class="footable-visible">Date.</th>
                    <th data-hide="phone" class="footable-visible">Card Number</th>
                    <th data-hide="phone" class="footable-visible">Card Type</th>
                    <th data-hide="phone" class="checkout-subtotal footable-visible footable-last-column">Amount</th>

                </tr>
            </thead>
            <tbody>

                <tr>
                    <td class="footable-visible footable-first-column"><span class="footable-toggle"></span>ZF-APR-BD-001</td>
                    <td class="footable-visible">Sep 29, 2015 </td>
                    <td class="footable-visible">411111******1111</td>
                    <td class="footable-visible">VISA</td>
                    <td class="checkout-subtotal footable-visible footable-last-column">? 4,176.00</td>
                </tr>


            </tbody>
        </table>

        <div class="clearfix" style="height: 40px;"></div>
        <div class="row">
            <div class="col-md-12">
                <div class="col-md-6">
                    &nbsp;
                </div>
                <div class="col-md-6">
                    <div class="form-group" style="float: right">
                        <a class="zee-button zee-primary-btn" href="/Login">
                            <span class="icon">
                                <img src="/icons/png/key.png" style="float: left; height: 18px; margin: 3px 0 0; width: 18px;"></span>
                            <span class="text">Log In</span>
                        </a>
                    </div>


                </div>
            </div>
        </div>
    </div>
</div>
<?php include 'inc/footer.php'; ?>
