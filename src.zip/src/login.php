<?php
//$compact_topbar = '1';
$footer_static = '1';
include 'inc/head.php';
$page ='login'
?>


<div class="zee-content-wrapper zee-myaccount-body">
    <div class="my-account-welcome">
        <div class="container">
            <div class="row">
                <h3>Log in or create an account </h3>
            </div>
        </div>
    </div>
    <div class="container zee-myaccounter-container">


        <div class="zee-myaccount-error-message">
            <div class="zee-form-message success">
                <i class="icon icon-ok-1"></i>
                <!--<i class="icon icon-info"></i>-->
                <p>The email address or password you entered is incorrect. Passwords are case sensitive. Please try again.</p>
            </div>
            <div class="clearfix" style="height: 20px;"></div>
        </div>


        <div class="zee-members-login-outer">

            <div class="">
                <div class="col-md-6 login-section-seperator">
                    <div class="form-group">
                        <h3>Registered Customers</h3>
                    </div>
                    <div class="form-group">
                        <p class="">If you have an account with us, log in using your email address.</p>
                    </div>
                    <form action="/en-IN/Login" autocomplete="off" method="post" returnurl="">
                        <div class="form-group">
                            <label>Email Address</label>
                            <input class="form-control" data-val="true" data-val-email="Please enter a valid email." data-val-required="This field is required." id="UserName" name="UserName" type="text" value="" />
                        </div>
                        <div class="form-group">
                            <label>Password</label>
                            <input class="form-control" data-val="true" data-val-length="The password must be at least 6 characters long." data-val-length-max="100" data-val-length-min="6" data-val-required="This field is required." id="Password" name="Password" type="password" />
                        </div>
                        <div class="form-group">
                            <ul class="login-action-helpers">
                                <li>
                                    <button class="btn btn-primary">Log In</button>
                                </li>
                                <li><a href="/forget-password">Forgot password?</a></li>
                            </ul>
                        </div>
                    </form>
                </div>
                <div class="col-md-5 col-md-push-1 login-section-bottom">
                    <div class="form-group">
                        <h3>New Customers</h3>
                    </div>
                    <div class="form-group">
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed facilisis orci at quam consectetur, vel rutrum justo suscipit. Fusce eget tempor ipsum. Mauris volutpat gravida turpis, quis hendrerit orci fermentum non.</p>
                    </div>
                    <a href="register.php" class="btn btn-primary">Register Now</a>
                </div>
            </div>
        </div>

    </div>
</div>




<?php include 'inc/footer.php'; ?>