<?php include 'inc/head.php'; ?>



<div class="zee-content-wrapper no-banner zee-myaccount-body">
    <div class="my-account-welcome">
        <div class="container">
            <div class="row">
                <h3><small>welcome</small>Pushkar Adsule</h3>
            </div>
        </div>
    </div>
    <div class="container zee-myaccounter-container">



        <div class="zee-myaccount-nav-wrapper">
            <div class="visible-xs-inline-block myaccount-mobile-menu-trigger">
                <a href="#" id="zee_myaccount_mobile_menu_trigger">Menu</a>
            </div>
            <div id="zee_myaccount_mobile_menu">
                <?php $active_menu = 'cancelsubs'; include('inc/myaccount-menu.php'); ?>
                <?php
                /*
                 * <h4 class="zee-myaccount-linktv-header">Link your TV</h4>
                <ul class="zee-myaccount-linktv">
                <li>
                <a href="Samsung">
                <img src="/images/samsung-smart-tv.png">
                </a>
                </li>
                </ul>
                 */?>
            </div>
        </div>

        <div class="zee-myaccount-wrapper">
            <h3 class="zee-myaccount-section-heading my-profile-heading">Cancel Subscription</h3>
            <div class="clearfix" style="height: 20px;"></div>
            <div class="col-sm-12">
                <h4 class="zee-myaccount-subheading text-left">We are sad to see you go! Please select the reason you wish to unsubscribe.</h4>
            </div>

            <div class="col-sm-12">
                <form action="/cancel-sub-confirm" autocomplete="off" method="post" novalidate="novalidate">
                    <div class="form-group">
                        <select class="form-control col-md-8 col-sm-12" name="Reason" data-val="true" data-val-required="You must select a reason in order to unsubscribe.">
                            <option value="">Please select a reason..</option>
                            <optgroup label="Watch Zee channels through other means">
                                <option value="Cable">Cable</option>
                                <option value=">Dish/DirectTV">Dish/DirectTV</option>
                                <option value="Yupp">Yupp</option>
                                <option value="Watch it free online">Watch it free online</option>
                                <option value="Jadoo or similar boxe">Jadoo or similar boxes</option>
                            </optgroup>
                            <optgroup label="Not interested">
                                <option value="No time">No time</option>
                                <option value="Do not like the content">Do not like the content</option>
                            </optgroup>
                            <optgroup label="Do not want to pay">
                                <option value="Would use if free">Would use if free</option>
                                <option value="Would be willing to pay lower price">Would be willing to pay lower price</option>
                            </optgroup>
                            <optgroup label="Technical issues">
                                <option value="Not enough compatible devices">Not enough compatible devices</option>
                                <option value="Trouble streaming">Trouble streaming</option>
                                <option value="Difficult to navigate">Difficult to navigate</option>
                            </optgroup>
                            <optgroup label="None">
                                <option class="bold" value="None of the above">None of the above</option>
                            </optgroup>
                        </select>
                    </div>
                    <div class="form-group">
                        <textarea class="form-control floating-label" placeholder="Comments" cols="20" id="Comment" name="Comment" rows="8"></textarea>

                    </div>
                    <div class="col-sm-12">
                        <div class="form-group" style="float: right">
                            <button class="btn btn-material-grey" type="reset">CLEAR</button>
                            <button class="btn btn-primary">Confirm Cancellation</button>
                        </div>
                    </div>
                </form>
            </div>

        </div>
    </div>
</div>

<?php include 'inc/footer.php'; ?>