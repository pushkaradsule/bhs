<?php
$footer_auto = '0';
$no_banner = '1';
$compact_topbar = '1';
$bodyclass = 'zee-liveplayer-page';
include 'inc/head.php';
$page ='livepage'
?>

<div class="zee-liveplayer-app-wrapper" ng-app="main" ng-cloak=""  ui-view="">

    <div class="zee-content-wrapper" id="zee-player-wrapper">
        <input id="antiForgeryToken" type="hidden" value='9cyT6deabnn74-QLmTXhCzSFW3FMYLxSbfqFqws3AKRfXmLOIJt-KVgBQ3IYTEtryWeFCCLAkoLth4Is3ZgydCc3F7YD55Z_2Eb-28vnx3A1:ADrahzIdXcjzLjhbiSwrYH79QbXei1D6KQgRp0s1SX5PHs7J8Mff-ILZ4iC1kG5mWmUxxpnjdGgdjTGS7AsPZaMzWaj4ubHC7E6ZUkWZL5E1' />
        <div class="live-now-paying-label">
            <label>Now</label>
            <span>The Adventures Of Tintin</span>
        </div>
        <div class="zee-media-player-wrapper" ui-view="player"></div>
    </div>

    <div class="zee-player-options-bar">
        <div class="container">
            <div class="row">
                <ul class="zee-player-options-items">
                    <li><a href="javascript:void(0)" class="withripple" data-tab="player_options_tab_channelinfo">Channel Info</a></li>
                    <li><a href="javascript:void(0)" class="withripple" data-tab="player_options_tab_allchannels">All Channels</a></li>
                    <li><a href="javascript:void(0)" class="withripple" data-tab="player_options_tab_programguide">Program Guide</a></li>
                </ul>
            </div>
        </div>
    </div>

    <div class="zee-player-options-wrapper" id="zee_player_options_data">
        <div class="zee-player-options-utility">
            <ul>
                <li class="zee-player-options-utility-close"><a href="javascript:void(0)" class="withripple" id="zee_player_options_close"><i class="icon icon-cancel-3"></i></a></li>
            </ul>
        </div>

        <div class="zee-player-options-tab" id="player_options_tab_channelinfo">

            <div class="container">
                <div class="row">
                    <div ui-view="channelInfo"></div>
                </div>
            </div>

        </div>

        <div class="zee-player-options-tab" id="player_options_tab_allchannels">
            <div ui-view="channelControls"></div>
        </div>

        <div class="zee-player-options-tab" id="player_options_tab_programguide"></div>

    </div>
</div>




<?php $hide_footer = '1'; include 'inc/footer.php'; ?>


