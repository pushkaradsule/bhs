<?php $page ='login'; include 'inc/head.php'; ?>



<div class="zee-content-wrapper no-banner zee-myaccount-body">
    <div class="my-account-welcome">
        <div class="container">
            <div class="row">
                <h3><small>welcome</small>Pushkar Adsule</h3>
            </div>
        </div>
    </div>
    <div class="container zee-myaccounter-container">



        <div class="zee-myaccount-nav-wrapper">
            <div class="visible-xs-inline-block myaccount-mobile-menu-trigger">
                <a href="#" id="zee_myaccount_mobile_menu_trigger">Menu</a>
            </div>
            <div id="zee_myaccount_mobile_menu">
                <?php $active_menu = 'billing'; include('inc/myaccount-menu.php'); ?>
                <?php
                /*
                 * <h4 class="zee-myaccount-linktv-header">Link your TV</h4>
                <ul class="zee-myaccount-linktv">
                <li>
                <a href="Samsung">
                <img src="/images/samsung-smart-tv.png">
                </a>
                </li>
                </ul>
                 */?>
            </div>
        </div>

        <div class="zee-myaccount-wrapper">
            <h3 class="zee-myaccount-section-heading my-profile-heading">Billing Information</h3>
            <div class="clearfix" style="height: 20px;"></div>
            <div class="zee-myaccount-billing-options">
                    <ul>
                        <li><span>Current Subscription</span></li>
                        <li><a href="/billing-history">Billing History</a></li>
                      
                    </ul>
                </div>
            <div class="clearfix" style="height: 20px;"></div>
            <table class="table table-myaccounts tablesaw tablesaw-stack" data-tablesaw-mode="stack" id="zee_package_checkout_summary">
                    <thead>
                        <tr>
                            <th class="table-primary-cell">Package</th>
                            <th>Plan</th>
                            <th class="table-cell-right">Price</th>
                            <th class="table-cell-right">Activation Date</th>
                            <th class="table-cell-right">Renew Date</th>
                        </tr>
                    </thead>
                    <tbody>
                            <tr>
                                <td><span class="footable-toggle"></span>30 Day Trial</td>
                                <td>M2M</td>
                                <td class="table-cell-right">? 0.00</td>
                                <td class="table-cell-right">9/7/2015</td>
                                <td class="table-cell-right">Terminates 10/7/2015</td>
                            </tr>
                            <tr>
                                <td><span class="footable-toggle"></span>ZEE Family Pack</td>
                                <td>M2M</td>
                                <td class="table-cell-right">? 249.00</td>
                                <td class="table-cell-right">2015 Oct 07</td>
                                <td class="table-cell-right"></td>
                            </tr>

                    </tbody>
                </table>
            
        </div>

    </div>
</div>

<?php include 'inc/footer.php'; ?>