<?php $page ='login'; include 'inc/head.php'; ?>



<div class="zee-content-wrapper no-banner zee-myaccount-body">
    <div class="my-account-welcome">
        <div class="container">
            <div class="row">
                <h3><small>welcome</small>Pushkar Adsule</h3>
            </div>
        </div>
    </div>
    <div class="container zee-myaccounter-container">



        <div class="zee-myaccount-nav-wrapper">
            <div class="visible-xs-inline-block myaccount-mobile-menu-trigger">
                <a href="#" id="zee_myaccount_mobile_menu_trigger">Menu</a>
            </div>
            <div id="zee_myaccount_mobile_menu">
                <?php $active_menu = 'manage'; include('inc/myaccount-menu.php'); ?>
                <?php
                /*
                 * <h4 class="zee-myaccount-linktv-header">Link your TV</h4>
                <ul class="zee-myaccount-linktv">
                <li>
                <a href="Samsung">
                <img src="/images/samsung-smart-tv.png">
                </a>
                </li>
                </ul>
                 */?>
            </div>
        </div>

        <div class="zee-myaccount-wrapper">
            <h3 class="zee-myaccount-section-heading my-profile-heading">Manage Subscription</h3>
            <div class="clearfix" style="height: 20px;"></div>


            <div class="row">

                <div class="col-sm-12">

                    <div class="zee-myaccount-manage-subscription">
                        <table class="table table-myaccounts tablesaw tablesaw-stack" data-tablesaw-mode="stack">
                            <thead>
                                <tr>
                                    <th>Package</th>
                                    <th class="table-cell-right">Plan</th>
                                    <th class="table-cell-right">Price</th>
                                    <th class="table-cell-right">End of Billing Cycle</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tfoot>
                                <tr>
                                    <th class="tablesaw-cell-bold">Subtotal</th>
                                    <th class="tablesaw-cell-hide"></th>
                                    <th class="table-cell-right">$999.99</th>
                                    <th class="tablesaw-cell-hide"></th>
                                    <th class="tablesaw-cell-hide"></th>
                                </tr>
                            </tfoot>
                            <tbody>
                                <tr>
                                    <td>Zee Family Marathi Pack</td>
                                    <td class="table-cell-right">MONTHLY</td>
                                    <td class="table-cell-right">$999.99</td>
                                    <td class="table-cell-right">09/10/2015</td>
                                    <td class="table-cell-right">
                                        <ul class="manage-subs-action">
                                            <li>
                                                <a href="#" class="package-info-data"
                                                    data-package="Zee Family Marathi Pack"
                                                    data-price="999.99"
                                                    data-desc="Enjoy it ALL with this comprehensive Hindi package. Watch your favorite dramas, comedies, and reality shows. Stay on top of all things Bollywood, including new films and hit songs, fashion, celebrity interviews and gossip! You will be up-to-date with everything that is going on in the world, from politics to business and sports. Plus, you will have access to India's first 24-hour cooking channel.">INFO</a>
                                            </li>
                                            <li><a href="#">REMOVE</a></li>
                                        </ul>
                                    </td>
                                </tr>
                                <tr>
                                    <td>Zee Family News Pack</td>
                                    <td class="table-cell-right">MONTHLY</td>
                                    <td class="table-cell-right">$999.99</td>
                                    <td class="table-cell-right">09/10/2015</td>
                                    <td class="table-cell-right">
                                        <ul class="manage-subs-action">
                                            <li>
                                                <a href="#" class="package-info-data"
                                                    data-package="Zee Family News Pack"
                                                    data-price="999.99"
                                                    data-desc="Enjoy it ALL with this comprehensive Hindi package. Watch your favorite dramas, comedies, and reality shows. Stay on top of all things Bollywood, including new films and hit songs, fashion, celebrity interviews and gossip! You will be up-to-date with everything that is going on in the world, from politics to business and sports. Plus, you will have access to India's first 24-hour cooking channel.">INFO</a>
                                            </li>
                                            <li><a href="#">REMOVE</a></li>
                                        </ul>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>

                </div>


                <div class="col-sm-12 column-top-margin text-right">
                    <div class="form-group">
                        <a class="btn btn-primary" href="my_account_manage_subscription_add.php">Add Package</a>
                    </div>
                </div>

            </div>

        </div>

    </div>
</div>

<?php include 'inc/footer.php'; ?>