<?php
$footer_auto = '0';
$no_banner = '1';
$compact_topbar = '1';
$bodyclass = 'zee-liveplayer-page';
include 'inc/head.php';
?>

<div class="zee-content-wrapper" data-player-info="{&quot;s&quot;:&quot;?C$&#214;\u0013l&#197;&#170;\ro?H?n%\u001d\u0010&#233;??&#208;&#192;&#168;&#226;vM`&#228;\f/&#236;hX&#198;\u000e&#188;Cf&#172;s#\u0085\u0000)jb&#189;&#236;_&#181;\u001db?&#176;?&#206;U\u0013\u0015&#235;\u0018&#198;4b&#244;?X\u0012&#194;\u0011y&#174;.-\u001c&#161;N;&#170;&#180;1K&#216;&#160;&#249;\u0013&#177;+k&lt;&#186;$F&#223;&#214;mw&#188;?/&#202;&#219;;\u0018[&#250;?&#215;&#181;?&#248;\u0006?\u0007X&#230;&#162;&#210;?~4&#248;&#172;X&#188;&#183;\u0004&#245;yLB&#250;&#171;W?&#250;&#163;VcPIs&#219;\u000fIh&#183;?)&#163;S6�&#179;&#202;&#244;?\u0003&#171;&#184;?:\u001d\u0016Dt&gt;lV&#241;&#210;\n&#212;&#205;D=&amp;\u0010\u000f%=?~&#240;2VW&quot;,&quot;h&quot;:&quot;510&quot;,&quot;w&quot;:&quot;930&quot;,&quot;BaseUrl&quot;:&quot;/&quot;,&quot;p&quot;:0,&quot;l&quot;:false,&quot;k&quot;:&quot;FUDed4q7HWOIJLsRmy/MciFf3v4=&quot;,&quot;i&quot;:&quot;906&quot;,&quot;t&quot;:&quot;M&quot;,&quot;c&quot;:&quot;1 2 3 From  Amalapuram&quot;,&quot;pr&quot;:null,&quot;se&quot;:null}" id="movieContainer">
    <input id="antiForgeryToken" type="hidden" value='7a2DEWgzWqp38SV73g9piQbji7tx9D8dmIaKBn_etYOnrNxWw9VHQE5lIhHXqmzqcFYv5itjhP8yIDG_k0pZHbVcgBBxMW7z33_3HxvqpC81:xrO2yWMBflvSKtBWSPofkS-JaPxk7UGX462mMTOH9fCB__tKCqxI13QInNN5OC044K16VWa2e-23j1jUEalIEr81L7Ip2n-i5FuMMnYPj4E1' />
    <div class="live-now-paying-label">
        <label>Playing</label>
        <span>The Adventures Of Tintin</span>
    </div>
    <div class="zee-media-player-wrapper" style="background-image: url(http://res.cloudinary.com/idiso/image/upload/v1416706038/twozkebf46h6fsfogvhn.jpg)">
        <div class="zee-media-player" ng-hide="playerLoading">
            <!-- overlay -->
            <div class="zee-player-overlay">
                <div class="zee-player-overlay-content player-upnext-content">

                    <ul class="zee-player-overlay-items">
                        <?php /*
                        <li><a href="javascript:void(0)"><i class="icon icon-ccw"></i>Rewatch Episode 12</a></li>
                        <li><a href="javascript:void(0)" class="primary-action"><i class="icon icon-play-circled"></i>Watch Episode 13</a></li>
                         */ ?>
                        <li><a href="#"><i class="icon icon-clock"></i>Resume Play From <time>00:12:43</time> </a></li>
                        <li><a href="#" class="primary-action"><i class="icon icon-play-circled"></i>Play From Begining</a></li>
                        <?php /*
                        <li>
                        <div class="zee-player-error"><i class="icon icon-block"></i>You do now have access to this content, please login to your account and watch the show, have fun and enjoy your life.</div>
                        </li>
                         */ ?>
                    </ul>

                </div>
            </div>

            <?php /*
            <!-- place video player code here-->
            <script src="//zeefamily.azurewebsites.net/js/jwplayer.js"></script>
            <div id="zeeplayer"></div>
            <script>jwplayer.key = "udcJDrJH7pZfao0pgVPEyTqve+EFlQQdkggxCw==";
            jwplayer("zeeplayer").setup({
            file: "http://zeetv.vo.llnwd.net/v1/u/ZeeTV/DID_USA_NORTH_AMERICA_EDITION_ZUSA_HD.mp4",
            autostart: true,
            width: '100%',
            height: '100%',
            aspectration: '16:9',
            primary: 'flash'
            });
            </script>
             */ ?>

        </div>
    </div>



</div>

<div class="zee-player-options-bar">
    <div class="container">
        <div class="row">
            <ul class="zee-player-options-items">
                <li><a href="javascript:void(0)" class="withripple" data-tab="player_options_tab_movieabout"><i class="icon icon-article-alt"></i><span class="tab-label">About Movie</span></a></li>
                <li><a href="javascript:void(0)" class="withripple" data-tab="player_options_tab_movierelated"><i class="icon icon-filming14"></i><span class="tab-label">Similar Movies</span></a></li>
                <li><a href="javascript:void(0)" class="withripple" data-tab="player_options_tab_allchannels"><i class="icon icon-th"></i><span class="tab-label">All Channels</span></a></li>
                <li><a href="javascript:void(0)" class="withripple" data-tab="player_options_tab_epg"><i class="icon icon-book-open"></i><span class="tab-label">Program Guide</span></a></li>
                <!--<li><a href="javascript:void(0)" class="withripple no-tab-action"><i class="icon icon-to-start-alt"></i><span class="tab-label">Watch from Begining</span></a></li>-->
            </ul>
        </div>
    </div>
</div>

<div class="zee-player-options-wrapper" id="zee_player_options_data">

    <a href="javascript:void(0)" class="close-player-info-touch" style="display: none;"><i class="icon icon-cancel-1"></i></a>

    <div class="zee-player-options-tab" id="player_options_tab_movieabout">

        <div class="container">
            <div class="row">
                <div class="col-md-2 hidden-xs hidden-sm zee-player-options-thumbnail">
                    <img src="http://res.cloudinary.com/idiso/image/upload/v1426604472/kykhlbc38dvpnb6zuhlj.jpg" />
                </div>
                <div class="col-md-10 col-xs-12">
                    <div class="zee-movies-player-info zee-show-data">
                        <div class="zee-live-channel-data">
                            <h3>The Adventures Of Tintin</h3>
                            <ul class="channel-icons show-info-icons">
                                <li><span><i class="icon icon-calendar-1"></i>2011</span></li>
                                <li><span><i class="icon icon-tag-2"></i>Animation</span></li>
                                <li><span><i class="icon icon-globe-1"></i>Hindi</span></li>
                            </ul>
                            <p class="zee-movies-cast"><span>Cast</span>Jamie Bell, Andy Serkis, Daniel Craig</p>
                            <p class="zee-movies-synopsis">
                                <span>Synopsis</span> <span>The Adventures of Tintin is an animation film, based on the famous cartoon character, Tintin, who has entertained kids across the globe for decades. Directed by Steven Spielberg, it won the Golden Globe Award for Best Animated Feature Film. The adventure begins when in a supermarket Tintin purchases a model ship, "The Unicorn" for a pound. The innocent purchase leads to the kidnapping of Tintin and his wonder dog Snowy and they are later joined by Captain Haddock. Turns out The Unicorn contains an important piece of a significant clue hidden by Captain Haddock 's ancestor who was a great sailor. In a complex series of events Tintin, Snowy and Captain Haddock are united on tracing the clues and solving the puzzle.
                                </span>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <div class="zee-player-options-tab zee-player-carousel-container" id="player_options_tab_movierelated">
        <div class="player-episodes-carousel-outer">
            <?php $similar = '1'; include 'inc/carousel-similar-movies.php'; ?>
        </div>
    </div>

    <div class="zee-player-options-tab zee-player-carousel-container" id="player_options_tab_allchannels">
        <div class="player-episodes-carousel-outer">
            <?php $similar = '1'; include 'inc/carousel-allchannels.php'; ?>
        </div>
    </div>

    <div class="zee-player-options-tab zee-player-carousel-container" id="player_options_tab_epg">
        <div class="zee-player-options-utility">
            <ul>
                <li class="zee-player-options-utility-today">
                    <div class="liveplayer-epg-now"><span>Showing all programs on :</span> <time>October 6, 2015</time></div>
                </li>
                <?php /*
                <li class="zee-player-options-utility-datepicker">
                    <a href="javascript: void(0)" class="liveplayer-epg-calendar">
                        <i class="icon icon-calendar-1"><span class="sr-only">Calendar</span></i>  Change Date
                    </a>
                </li>
                */ ?>
            </ul>
        </div>
        <div class="player-episodes-carousel-outer">
            <?php include 'inc/carousel-epg-liveplayer.php'; ?>
        </div>
    </div>


</div>



<?php $hide_footer = '1'; include 'inc/footer.php'; ?>