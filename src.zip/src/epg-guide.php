<!doctype html>
<html class="no-js" lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="description" content="">
    <meta name="HandheldFriendly" content="True">
    <meta name="MobileOptimized" content="320">
    <meta name="viewport" content="width=device-width, initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no">
    <meta http-equiv="cleartype" content="on">
    <meta http-equiv="x-dns-prefetch-control" content="off">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta name="apple-mobile-web-app-title" content="ZeeFamily.tv">
    <title>Watch Live TV | Live TV Channel Guide</title>
    <meta name="description" content="Watch live channels online, watch TV shows online, serials, dramas, reality shows, Dance India Dance, DID ZEE TV, DID zee, Sa Re Ga Ma Pa" />
    <meta name="keywords" content="ZEE Family plays home to more than 25 of the best Indian channels- subscribe today for the best in Hindi, Marathi, Bengali, Punjabi, Tamil, Telugu and Kannada entertainment!" />
    <link rel="stylesheet" href="/styles/normalize.css?v=140420951121A2" />
    <link href='//fonts.googleapis.com/css?family=Roboto:100,400,400italic,300,300italic,500,700,900' rel='stylesheet' type='text/css'>
    <link href="/icons/icon-pack/fontello.css" rel="stylesheet" />
    <link rel="stylesheet" href="/styles/animate.css?v=140420951121A2" />
    <link href="/styles/ripples.min.css" rel="stylesheet" />
    <link href="/styles/material.css?v=1" rel="stylesheet" />
    <!--<link rel="stylesheet" href="/styles/owl.carousel-old.css?v=140420951121A2" />-->
    <link href="/styles/carousel.css" rel="stylesheet" />

    
    <link rel="stylesheet" href="/styles/layout.css?v=140420951121A2" />
    <link rel="stylesheet" href="/styles/toolbar.css?v=pushkarad11sule" />
    <link rel="stylesheet" href="/styles/zeeicon.css?v=asi1gts-ashiwka" />
    

    

    <link href="/styles/epg.css?v=1.3.1" rel="stylesheet" />

    <!-- skin -->
    <?php
	$skin = 'blue';			
	if(isset($_GET['skin']) && $_GET['skin'] != ''){
		setcookie('zee_prototype_skin', $_GET['skin'], time() + (86400 * 30), "/");
		$skin = $_GET['skin'];
	}			
	else if(isset($_COOKIE['zee_prototype_skin']) && $_COOKIE['zee_prototype_skin'] != ''){
		$skin = $_COOKIE['zee_prototype_skin'];
	}

    ?>
    <link rel="stylesheet" href="skins/theme-<?php echo $skin ?>.css" />


    <script src="/js/modernizr.custom.min.js?v=14042095" type="text/javascript"></script>
    <script src="/js/jrespond.min.js?v=14042095" type="text/javascript"></script>
    
   
    <!--<script src='/js/jquery-1.11.0.min.js'></script>-->
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.0/jquery.min.js"></script>
    <script src='/js/jquery-migrate-1.2.1.min.js'></script>
    



    <script src='/js/responsiveslides.min.js'></script>
    <script src='/js/ripples.min.js'></script>
    <script src='/js/material.min.js'></script>

    <script src="/js/moment.js?v=14042095" type="text/javascript"></script>
    <script src="/js/handlebars-v1.3.0.js?v=14042095" type="text/javascript"></script>
    <script src="/js/jquery.jscroll.js?v=14042095" type="text/javascript"></script>
    <script src="/js/jquery.waypoints.js"></script>
    <script src="/js/jquery.draggable.js?v=14042095" type="text/javascript"></script>
    <script src="/js/linqjs.js?v=14042095" type="text/javascript"></script>
    <script src="/js/mobile-detect.min.js?v=14042095" type="text/javascript"></script>
    <script src="/js/mobile-detect-modernizr.js?v=14042095" type="text/javascript"></script>
    <script src="/js/imagesloaded.js?v=14042095" type="text/javascript"></script>
    <script src="/js/throttle.deboiunce.min.js?v=14042095" type="text/javascript"></script>
    <script src="/js/underscore-min.js?v=14042095" type="text/javascript"></script>
    <!--<script src="/js/owl.carouselold.min.js?v=14042095" type="text/javascript"></script>-->
    <script src='/js/owl.carousel.js'></script>
    <script src="//ajax.googleapis.com/ajax/libs/angularjs/1.3.4/angular.min.js"></script>
    
    <script src="/js/pguide.js"></script>

</head>
<body ng-app="main" ng-controller="EpgGuide" ng-cloak="" class="zee-toolbar-compact ">

    <?php include('inc/mobile-utility.php'); ?>



    <input id="antiForgeryToken" type="hidden" value='DjjtUhaWbx6IJvgkjy_UxCUn8gH010L8_sTZIHZ_tfaSlpJ_VMD3QQc4V25IZzoYjTDY-6Y5UjPCu7azA-LcvaD-r7k8BXeD1-FRsdumJSg1:Mo4YmhPJOgPP6KzijNZe6QM-A2fPVcPav6FQt1JQ8-lASEEiAu0CSC8qERx8Q2azTxNjtv9DY13CApFJ8o8jtyQiFBioK86AX1aiPx7Mg5Q1' />
    <span id="spinner-1" style="top: 60%; position: fixed; left: 50%;"></span>

    <div class="zee-body-wrapper">

        <?php include('inc/top-bar.php'); ?>

    </div>

    <div class="guide-tools-wrapper global-header-epg">
        <div id="tv-guide-title">
            <p id="tv-guide-title-p">TV Channel Guide</p>
            <p id="tv-guide-title-p-onnow">
                <a class="guide-schedule-now visible-md-inline-block visible-lg-inline-block visible-sm-inline-block" data-ng-click="onNow()" href="#"><span>On Now</span></a>
            </p>
        </div>
        <div class="guide-schedule-scroll" id="epg-grid">

            <div id="guide-schedule-items">
           
                <div class="epg-schedule-item withripple" ng-repeat="day in dates" ng-click="epgInfo.ChangeDay(day)" ng-class="{'selected-schedule' : day.active }">
                         {{day.weekday}} {{day.month}} {{day.day}}
                </div>
              
            </div>

            <?php
            /*
             * selected-schedule
            <div class="guide-schedule-left" id="dt-scroll-prev"></div>
            <div class="guide-schedule-items carsouel_nav" id="guide-schedule-items">
                <div class="guide-schedule-item" ng-class="{'guide-schedule-item-active' : day.active, 'white-color': day.isData, 'grey-color': !day.isData }" ng-repeat="day in dates" ng-click="epgInfo.ChangeDay(day)">
                    <div>
                        {{day.weekday}}<span>{{day.day}}</span>{{day.month}}
                    </div>
                </div>
            </div>
            <div class="guide-schedule-right carsouel_nav" id="dt-scroll-next"></div>
            <div class="epg-scroll-date-msg">Go back up to 30 days for missed programs!</div>
            */
            ?>
        </div>

        <div id="epg-time">
            <ul>
                <li id="time-0-am">12am
                    <div></div>
                </li>
                <li id="time-1-am">1am
                    <div></div>
                </li>
                <li id="time-2-am">2am
                    <div></div>
                </li>
                <li id="time-3-am">3am
                    <div></div>
                </li>
                <li id="time-4-am">4am
                    <div></div>
                </li>



                <li id="time-5-am">5am
                    <div></div>
                </li>



                <li id="time-6-am">6am
                    <div></div>
                </li>



                <li id="time-7-am">7am
                    <div></div>
                </li>



                <li id="time-8-am">8am
                    <div></div>
                </li>



                <li id="time-9-am">9am
                    <div></div>
                </li>



                <li id="time-10-am">10am
                    <div></div>
                </li>



                <li id="time-11-am">11am
                    <div></div>
                </li>



                <li id="time-12-pm">12pm
                    <div></div>
                </li>



                <li id="time-13-pm">1pm
                    <div></div>
                </li>



                <li id="time-14-pm">2pm
                    <div></div>
                </li>



                <li id="time-15-pm">3pm
                    <div></div>
                </li>



                <li id="time-16-pm">4pm
                    <div></div>
                </li>



                <li id="time-17-pm">5pm
                    <div></div>
                </li>



                <li id="time-18-pm">6pm
                    <div></div>
                </li>



                <li id="time-19-pm">7pm
                    <div></div>
                </li>



                <li id="time-20-pm">8pm
                    <div></div>
                </li>



                <li id="time-21-pm">9pm
                    <div></div>
                </li>



                <li id="time-22-pm">10pm
                    <div></div>
                </li>



                <li id="time-23-pm">11pm
                    <div></div>
                </li>


            </ul>
        </div>
    </div>

    <div id="guide-list-wrapper" data-baseurl="/">
        <!--Channel List Start-->
        <ul class="guide-channels-list" id="guide-channels">
            <li ng-repeat="channel in channels" title="{{channel.Name}}">
                <a href="#" title="{{channel.Name}}" class="zee-channels">
                    <img class="channel-name" alt="{{channel.Name}}" ng-src="{{channel.LogoUrl}}" />
                </a>
                <a class="play-movie" ng-click="playChannel(channel)" href="javascript:void(0);"><i class="icon icon-play"></i></a>
                <!--<span>{{channel.number}}</span>-->
            </li>
        </ul>
        <!--Channel List End-->


        <div class="guide-schedule-outer" id="guide-schedule-outer">

            <div class="guide-program-list" id="guide-epg" ng-class="{'no-data-bg': channel.IsLoading }">

                <div class="guide-list-row {{channel.CssName}}" id="{{channel.Id}}" ng-repeat="channel in channels">
                    <div ng-repeat="epg in channel.EpgItems"
                        class="guide-list-item" ng-style="itemStyle(epg.DurationInMinutes)" ng-class="{'guide-pro-play-now': epg.IsPlayingNow }">

                        <div class="guide-pro-item-div" ng-class="{'paddingcenter': epg.DurationInMinutes > 60 }">
                            <span class="guide-pro-title" ng-style="itemStyle(epg.DurationInMinutes)">{{epg.Title}}</span>
                            <span class="guide-pro-time">{{epg.StartDate |  date:'HH:mm' }}</span>
                            <span class="guide-pro-on" ng-if="isEpgItemOnNow(epg)"><i>ON NOW</i></span>
                            <span class="guide-pro-play icon-play-circled2" 
                                ng-show="(epg.IsCatchUp && channel.CatchUpEnabled) || epg.IsPlayingNow" 
                                ng-click="catchUpPlay(epg,channel)"></span>
                        </div>

                    </div>
                </div>
            </div>

            <a id="zee-next" class="epg-navigation-arrow next-arrow" title="Next" data-ng-click="scrollNext()"><i class="icon icon-right-open-big"></i></a>
            <a id="zee-previous" class="epg-navigation-arrow prev-arrow" title="Previous" data-ng-click="scrollPrev()"><i class="icon icon-left-open-big"></i></a>

        </div>
    </div>



    <script>

        window.serverChannel = [{ "Name": "ZeeTV HD India", "number": "01", "Id": 76, "Desc": "ZEE TV is a Hindi entertainment  channel which offers the best in programming ranging from gripping dramas to engaging reality shows, news, movies, special events and more!  ", "Url": "/Live/ZEEHDIND/76", "LogoUrl": "http://res.cloudinary.com/idiso/image/upload/h_250/v1429565816/xbxxzff5rs8kugrtebjy.png", "ChannelTypeId": null, "EpgItems": [{ "isCatchUp": true, "StartTime": null, "Title": null, "DurationInMinutes": 1440, "IsEmpty": false, "ShowTitle": true, "UnixStartTime": 0, "UnixEndTime": 0, "ProgrammeId": 0, "ProgrammeUrl": null, "ProgrammeDesc": null, "EpisodeNo": null, "Season": null, "Cast": null, "IsPlayingNow": false, "IsCatchUp": true, "EpgItemId": 0, "StartDate": "0001-01-01T00:00:00", "EndDate": "0001-01-01T00:00:00", "ChannelId": 0 }], "CssName": null, "CatchUpUrl": "/CatchUp/ZEEHDIND/{0}", "CatchUpEnabled": true, "Enabled": false, "OnNow": null, "ComingUp": null, "IsLoading": true, "Category": "Family", "ShortName": "ZEEHDIND", "Language": "Hindi", "MetaDescription": "Products Description", "MetaKeywords": "Products, Stuff, Monies", "PageTitle": "ZeeTV HD India", "CustomerCanWatch": true }, { "Name": "ANDTV HD", "number": "02", "Id": 57, "Desc": "&TV is the flagship Hindi GEC amongst the �&� bouquet of channels. Staying true to the personification of the Ampersand, &TV signifies a conjunction of aspirations and rootedness which is synonymous with the spirit of New Age India. Through our content offering, we will bring together people and ideologies thus fostering cohesive viewing within Indian households. We will showcase a diverse and dynamic mix of relatable fiction, high voltage non-fiction, marquee events and blockbuster movies. \r\n", "Url": "/Live/ANDTVAPAC/57", "LogoUrl": "http://res.cloudinary.com/idiso/image/upload/h_250/v1425403195/brfr7r7wblj225978df9.png", "ChannelTypeId": null, "EpgItems": [{ "isCatchUp": true, "StartTime": null, "Title": null, "DurationInMinutes": 1440, "IsEmpty": false, "ShowTitle": true, "UnixStartTime": 0, "UnixEndTime": 0, "ProgrammeId": 0, "ProgrammeUrl": null, "ProgrammeDesc": null, "EpisodeNo": null, "Season": null, "Cast": null, "IsPlayingNow": false, "IsCatchUp": true, "EpgItemId": 0, "StartDate": "0001-01-01T00:00:00", "EndDate": "0001-01-01T00:00:00", "ChannelId": 0 }], "CssName": null, "CatchUpUrl": "/CatchUp/ANDTVAPAC/{0}", "CatchUpEnabled": true, "Enabled": false, "OnNow": null, "ComingUp": null, "IsLoading": true, "Category": "Entertainment", "ShortName": "ANDTVAPAC", "Language": "Hindi", "MetaDescription": "Products Description", "MetaKeywords": "Products, Stuff, Monies", "PageTitle": "ANDTV HD", "CustomerCanWatch": true }, { "Name": "Living Foodz", "number": "03", "Id": 45, "Desc": "Living Foodz is an international, premium food & lifestyle channel for the new age viewer. Now relish food, entertainment, lifestyle, adventure and a whole lot of fun all at once on Living Foodz.", "Url": "/Live/ZEEKKAPAC/45", "LogoUrl": "http://res.cloudinary.com/idiso/image/upload/h_250/v1441985758/ziu16jotuguconptg4zr.png", "ChannelTypeId": null, "EpgItems": [{ "isCatchUp": true, "StartTime": null, "Title": null, "DurationInMinutes": 1440, "IsEmpty": false, "ShowTitle": true, "UnixStartTime": 0, "UnixEndTime": 0, "ProgrammeId": 0, "ProgrammeUrl": null, "ProgrammeDesc": null, "EpisodeNo": null, "Season": null, "Cast": null, "IsPlayingNow": false, "IsCatchUp": true, "EpgItemId": 0, "StartDate": "0001-01-01T00:00:00", "EndDate": "0001-01-01T00:00:00", "ChannelId": 0 }], "CssName": null, "CatchUpUrl": "/CatchUp/ZEEKKAPAC/{0}", "CatchUpEnabled": false, "Enabled": false, "OnNow": null, "ComingUp": null, "IsLoading": true, "Category": "Family", "ShortName": "ZEEKKAPAC", "Language": "Hindi", "MetaDescription": "Products Description", "MetaKeywords": "Products, Stuff, Monies", "PageTitle": "Living Foodz", "CustomerCanWatch": true }, { "Name": "ZEE Cinema HD", "number": "03", "Id": 77, "Desc": "India�s first Bollywood movie channel, ZEE Cinema has more than 5,000 hours of movies, making it one of the largest libraries of Indian movie titles. Watch movies of all genres, from recent blockbuster hits to evergreen classics, 24-hours a day!", "Url": "/Live/ZEECININD/77", "LogoUrl": "http://res.cloudinary.com/idiso/image/upload/h_250/v1429630434/a09wfnlodfus0thfzrjn.png", "ChannelTypeId": null, "EpgItems": [{ "isCatchUp": true, "StartTime": null, "Title": null, "DurationInMinutes": 1440, "IsEmpty": false, "ShowTitle": true, "UnixStartTime": 0, "UnixEndTime": 0, "ProgrammeId": 0, "ProgrammeUrl": null, "ProgrammeDesc": null, "EpisodeNo": null, "Season": null, "Cast": null, "IsPlayingNow": false, "IsCatchUp": true, "EpgItemId": 0, "StartDate": "0001-01-01T00:00:00", "EndDate": "0001-01-01T00:00:00", "ChannelId": 0 }], "CssName": null, "CatchUpUrl": "/CatchUp/ZEECININD/{0}", "CatchUpEnabled": true, "Enabled": false, "OnNow": null, "ComingUp": null, "IsLoading": true, "Category": "Movies", "ShortName": "ZEECININD", "Language": "Hindi", "MetaDescription": "Products Description", "MetaKeywords": "Products, Stuff, Monies", "PageTitle": "ZEE Cinema HD", "CustomerCanWatch": true }, { "Name": "ZEE News", "number": "04", "Id": 18, "Desc": "Get the latest headlines and breaking news from India and around the globe with ZEE News. With local, regional and international coverage of politics, business, sports and entertainment, ZEE News will help you stay informed.", "Url": "/Live/ZEEN/18", "LogoUrl": "http://res.cloudinary.com/idiso/image/upload/h_250/v1411274620/ev84roo9ucfuv5tbj3ms.png", "ChannelTypeId": null, "EpgItems": [{ "isCatchUp": true, "StartTime": null, "Title": null, "DurationInMinutes": 1440, "IsEmpty": false, "ShowTitle": true, "UnixStartTime": 0, "UnixEndTime": 0, "ProgrammeId": 0, "ProgrammeUrl": null, "ProgrammeDesc": null, "EpisodeNo": null, "Season": null, "Cast": null, "IsPlayingNow": false, "IsCatchUp": true, "EpgItemId": 0, "StartDate": "0001-01-01T00:00:00", "EndDate": "0001-01-01T00:00:00", "ChannelId": 0 }], "CssName": null, "CatchUpUrl": "/CatchUp/ZEEN/{0}", "CatchUpEnabled": false, "Enabled": false, "OnNow": null, "ComingUp": null, "IsLoading": true, "Category": "News", "ShortName": "ZEEN", "Language": "Hindi", "MetaDescription": "Products Description", "MetaKeywords": "Products, Stuff, Monies", "PageTitle": "ZEE News", "CustomerCanWatch": true }, { "Name": "Z Living", "number": "05", "Id": 35, "Desc": "Nirvana has a new channel! With over 50 series on healthy cooking, fitness, yoga and travel, getting wellness is now as easy as turning on the TV. Let Z Living take you to your happy place.\r\n", "Url": "/Live/ZLIVUS/35", "LogoUrl": "http://res.cloudinary.com/idiso/image/upload/h_250/v1414188089/rnz115plgr35fjtyyfpw.png", "ChannelTypeId": null, "EpgItems": [{ "isCatchUp": true, "StartTime": null, "Title": null, "DurationInMinutes": 1440, "IsEmpty": false, "ShowTitle": true, "UnixStartTime": 0, "UnixEndTime": 0, "ProgrammeId": 0, "ProgrammeUrl": null, "ProgrammeDesc": null, "EpisodeNo": null, "Season": null, "Cast": null, "IsPlayingNow": false, "IsCatchUp": true, "EpgItemId": 0, "StartDate": "0001-01-01T00:00:00", "EndDate": "0001-01-01T00:00:00", "ChannelId": 0 }], "CssName": null, "CatchUpUrl": "/CatchUp/ZLIVUS/{0}", "CatchUpEnabled": true, "Enabled": false, "OnNow": null, "ComingUp": null, "IsLoading": true, "Category": "Entertainment", "ShortName": "ZLIVUS", "Language": "English", "MetaDescription": "Products Description", "MetaKeywords": "Products, Stuff, Monies", "PageTitle": "Z Living", "CustomerCanWatch": true }, { "Name": "ZEE Marathi India", "number": "06", "Id": 49, "Desc": "ZEE Marathi is an entertainment channel that features dramas, non-fiction shows, reality shows, news bulletins, devotional programs, movies and music-based shows. ", "Url": "/Live/ZMARINDA/49", "LogoUrl": "http://res.cloudinary.com/idiso/image/upload/h_250/v1422033997/bnew2kl8uh4chei6pm9b.png", "ChannelTypeId": null, "EpgItems": [{ "isCatchUp": true, "StartTime": null, "Title": null, "DurationInMinutes": 1440, "IsEmpty": false, "ShowTitle": true, "UnixStartTime": 0, "UnixEndTime": 0, "ProgrammeId": 0, "ProgrammeUrl": null, "ProgrammeDesc": null, "EpisodeNo": null, "Season": null, "Cast": null, "IsPlayingNow": false, "IsCatchUp": true, "EpgItemId": 0, "StartDate": "0001-01-01T00:00:00", "EndDate": "0001-01-01T00:00:00", "ChannelId": 0 }], "CssName": null, "CatchUpUrl": "/CatchUp/ZMARINDA/{0}", "CatchUpEnabled": true, "Enabled": false, "OnNow": null, "ComingUp": null, "IsLoading": true, "Category": "Family", "ShortName": "ZMARINDA", "Language": "Marathi", "MetaDescription": "Products Description", "MetaKeywords": "Products, Stuff, Monies", "PageTitle": "ZEE Marathi India", "CustomerCanWatch": true }, { "Name": "ZEE Bangla", "number": "07", "Id": 38, "Desc": "ZEE Bangla is an entertainment channel that features dramas, non-fiction shows, reality shows, news bulletins, devotional programs, movies and music based shows. ", "Url": "/Live/ZEEBAAPAC/38", "LogoUrl": "http://res.cloudinary.com/idiso/image/upload/h_250/v1422033186/yqzaic50wozz0ahw4umu.png", "ChannelTypeId": null, "EpgItems": [{ "isCatchUp": true, "StartTime": null, "Title": null, "DurationInMinutes": 1440, "IsEmpty": false, "ShowTitle": true, "UnixStartTime": 0, "UnixEndTime": 0, "ProgrammeId": 0, "ProgrammeUrl": null, "ProgrammeDesc": null, "EpisodeNo": null, "Season": null, "Cast": null, "IsPlayingNow": false, "IsCatchUp": true, "EpgItemId": 0, "StartDate": "0001-01-01T00:00:00", "EndDate": "0001-01-01T00:00:00", "ChannelId": 0 }], "CssName": null, "CatchUpUrl": "/CatchUp/ZEEBAAPAC/{0}", "CatchUpEnabled": true, "Enabled": false, "OnNow": null, "ComingUp": null, "IsLoading": true, "Category": "Family", "ShortName": "ZEEBAAPAC", "Language": "Bangla", "MetaDescription": "Products Description", "MetaKeywords": "Products, Stuff, Monies", "PageTitle": "ZEE Bangla", "CustomerCanWatch": true }, { "Name": "ZEE Salaam", "number": "08", "Id": 55, "Desc": "ZEE Salaam is an Urdu language religious and spiritual channel. It aims to entertain the viewers with mythological movies, serials, religious discourses and spiritual programs. Audiences will learn about alternative and holistic approaches to health and wellness in addition to spiritual wellbeing. ", "Url": "/Live/ZEESALAPAC/55", "LogoUrl": "http://res.cloudinary.com/idiso/image/upload/h_250/v1422032950/r6zd651v3wvf6zauzt0f.png", "ChannelTypeId": null, "EpgItems": [{ "isCatchUp": true, "StartTime": null, "Title": null, "DurationInMinutes": 1440, "IsEmpty": false, "ShowTitle": true, "UnixStartTime": 0, "UnixEndTime": 0, "ProgrammeId": 0, "ProgrammeUrl": null, "ProgrammeDesc": null, "EpisodeNo": null, "Season": null, "Cast": null, "IsPlayingNow": false, "IsCatchUp": true, "EpgItemId": 0, "StartDate": "0001-01-01T00:00:00", "EndDate": "0001-01-01T00:00:00", "ChannelId": 0 }], "CssName": null, "CatchUpUrl": "/CatchUp/ZEESALAPAC/{0}", "CatchUpEnabled": true, "Enabled": false, "OnNow": null, "ComingUp": null, "IsLoading": true, "Category": "Family", "ShortName": "ZEESALAPAC", "Language": "Urdu", "MetaDescription": "Products Description", "MetaKeywords": "Products, Stuff, Monies", "PageTitle": "ZEE Salaam", "CustomerCanWatch": true }, { "Name": "ZEE Business", "number": "09", "Id": 39, "Desc": "ZEE Business is a 24-hour news and infotainment channel that keeps viewers updated on happenings in the business world, from the stock market to investment trends to real estate and tech news!", "Url": "/Live/ZEEBUSAPAC/39", "LogoUrl": "http://res.cloudinary.com/idiso/image/upload/h_250/v1422033286/hn9lyexfcxv7hai5nojm.png", "ChannelTypeId": null, "EpgItems": [{ "isCatchUp": true, "StartTime": null, "Title": null, "DurationInMinutes": 1440, "IsEmpty": false, "ShowTitle": true, "UnixStartTime": 0, "UnixEndTime": 0, "ProgrammeId": 0, "ProgrammeUrl": null, "ProgrammeDesc": null, "EpisodeNo": null, "Season": null, "Cast": null, "IsPlayingNow": false, "IsCatchUp": true, "EpgItemId": 0, "StartDate": "0001-01-01T00:00:00", "EndDate": "0001-01-01T00:00:00", "ChannelId": 0 }], "CssName": null, "CatchUpUrl": "/CatchUp/ZEEBUSAPAC/{0}", "CatchUpEnabled": true, "Enabled": false, "OnNow": null, "ComingUp": null, "IsLoading": true, "Category": "News", "ShortName": "ZEEBUSAPAC", "Language": "English", "MetaDescription": "Products Description", "MetaKeywords": "Products, Stuff, Monies", "PageTitle": "ZEE Business", "CustomerCanWatch": true }, { "Name": "ZEE Punjabi", "number": "11", "Id": 44, "Desc": "ZEE Punjabi is a channel that offers a variety of programs such as dramas, talk shows, game shows, comedies, cooking shows, and films. With this family entertainment channel, viewers will enjoy top-rated Punjabi programming all day long!", "Url": "/Live/ZEEPUNAPAC/44", "LogoUrl": "http://res.cloudinary.com/idiso/image/upload/h_250/v1422033564/nzdub4zif1fjirlft6fu.png", "ChannelTypeId": null, "EpgItems": [{ "isCatchUp": true, "StartTime": null, "Title": null, "DurationInMinutes": 1440, "IsEmpty": false, "ShowTitle": true, "UnixStartTime": 0, "UnixEndTime": 0, "ProgrammeId": 0, "ProgrammeUrl": null, "ProgrammeDesc": null, "EpisodeNo": null, "Season": null, "Cast": null, "IsPlayingNow": false, "IsCatchUp": true, "EpgItemId": 0, "StartDate": "0001-01-01T00:00:00", "EndDate": "0001-01-01T00:00:00", "ChannelId": 0 }], "CssName": null, "CatchUpUrl": "/CatchUp/ZEEPUNAPAC/{0}", "CatchUpEnabled": true, "Enabled": false, "OnNow": null, "ComingUp": null, "IsLoading": true, "Category": "Family", "ShortName": "ZEEPUNAPAC", "Language": "Punjabi", "MetaDescription": "Products Description", "MetaKeywords": "Products, Stuff, Monies", "PageTitle": "ZEE Punjabi", "CustomerCanWatch": true }, { "Name": "ZEE Talkies", "number": "11", "Id": 40, "Desc": "ZEE Talkies is a Marathi language movie channel. Tune in for your favorite action, comedy, romantic and classic movies from the entire repertoire of Marathi Cinema, 24-hours a day!", "Url": "/Live/ZEETALAPAC/40", "LogoUrl": "http://res.cloudinary.com/idiso/image/upload/h_250/v1422033374/vxfggc2wlv5fbcxrfiqr.png", "ChannelTypeId": null, "EpgItems": [{ "isCatchUp": true, "StartTime": null, "Title": null, "DurationInMinutes": 1440, "IsEmpty": false, "ShowTitle": true, "UnixStartTime": 0, "UnixEndTime": 0, "ProgrammeId": 0, "ProgrammeUrl": null, "ProgrammeDesc": null, "EpisodeNo": null, "Season": null, "Cast": null, "IsPlayingNow": false, "IsCatchUp": true, "EpgItemId": 0, "StartDate": "0001-01-01T00:00:00", "EndDate": "0001-01-01T00:00:00", "ChannelId": 0 }], "CssName": null, "CatchUpUrl": "/CatchUp/ZEETALAPAC/{0}", "CatchUpEnabled": true, "Enabled": false, "OnNow": null, "ComingUp": null, "IsLoading": true, "Category": "Family", "ShortName": "ZEETALAPAC", "Language": "Marathi", "MetaDescription": "Products Description", "MetaKeywords": "Products, Stuff, Monies", "PageTitle": "ZEE Talkies", "CustomerCanWatch": true }, { "Name": "24 Taas", "number": "12", "Id": 13, "Desc": "The first and leading 24-hour Marathi news channel of its kind, 24 Taas dedicated to local, regional and national news coverage. It also offers sports programming and entertainment news, all in Marathi!", "Url": "/Live/24TA/13", "LogoUrl": "http://res.cloudinary.com/idiso/image/upload/h_250/v1411274824/jg6m4f2ys0ibfnhahxor.png", "ChannelTypeId": null, "EpgItems": [{ "isCatchUp": true, "StartTime": null, "Title": null, "DurationInMinutes": 1440, "IsEmpty": false, "ShowTitle": true, "UnixStartTime": 0, "UnixEndTime": 0, "ProgrammeId": 0, "ProgrammeUrl": null, "ProgrammeDesc": null, "EpisodeNo": null, "Season": null, "Cast": null, "IsPlayingNow": false, "IsCatchUp": true, "EpgItemId": 0, "StartDate": "0001-01-01T00:00:00", "EndDate": "0001-01-01T00:00:00", "ChannelId": 0 }], "CssName": null, "CatchUpUrl": "/CatchUp/24TA/{0}", "CatchUpEnabled": false, "Enabled": false, "OnNow": null, "ComingUp": null, "IsLoading": true, "Category": "News", "ShortName": "24TA", "Language": "Marathi", "MetaDescription": "Products Description", "MetaKeywords": "Products, Stuff, Monies", "PageTitle": "24 Taas", "CustomerCanWatch": true }, { "Name": "ZEE Bangla Cinema", "number": "14", "Id": 41, "Desc": "ZEE Bangla Cinema is a Bangla language movie channel. Tune in for your favorite action, comedy, romantic and classic movies from the entire repertoire of Bengali Cinema, 24-hours a day!", "Url": "/Live/ZEEBCAPAC/41", "LogoUrl": "http://res.cloudinary.com/idiso/image/upload/h_250/v1422033435/z0jrff5jlcktgu4qfx7v.png", "ChannelTypeId": null, "EpgItems": [{ "isCatchUp": true, "StartTime": null, "Title": null, "DurationInMinutes": 1440, "IsEmpty": false, "ShowTitle": true, "UnixStartTime": 0, "UnixEndTime": 0, "ProgrammeId": 0, "ProgrammeUrl": null, "ProgrammeDesc": null, "EpisodeNo": null, "Season": null, "Cast": null, "IsPlayingNow": false, "IsCatchUp": true, "EpgItemId": 0, "StartDate": "0001-01-01T00:00:00", "EndDate": "0001-01-01T00:00:00", "ChannelId": 0 }], "CssName": null, "CatchUpUrl": "/CatchUp/ZEEBCAPAC/{0}", "CatchUpEnabled": true, "Enabled": false, "OnNow": null, "ComingUp": null, "IsLoading": true, "Category": "Family", "ShortName": "ZEEBCAPAC", "Language": "Bangla", "MetaDescription": "Products Description", "MetaKeywords": "Products, Stuff, Monies", "PageTitle": "ZEE Bangla Cinema", "CustomerCanWatch": true }, { "Name": "24 Ghanta", "number": "15", "Id": 14, "Desc": "The first and leading 24-hour Bengali news channel of its kind, 24 Ghanta is dedicated to local, regional and national news coverage. It also offers sports programming and entertainment news, all in Bengali!", "Url": "/Live/24G/14", "LogoUrl": "http://res.cloudinary.com/idiso/image/upload/h_250/v1411274881/aioxxbysulmx1fdcn493.png", "ChannelTypeId": null, "EpgItems": [{ "isCatchUp": true, "StartTime": null, "Title": null, "DurationInMinutes": 1440, "IsEmpty": false, "ShowTitle": true, "UnixStartTime": 0, "UnixEndTime": 0, "ProgrammeId": 0, "ProgrammeUrl": null, "ProgrammeDesc": null, "EpisodeNo": null, "Season": null, "Cast": null, "IsPlayingNow": false, "IsCatchUp": true, "EpgItemId": 0, "StartDate": "0001-01-01T00:00:00", "EndDate": "0001-01-01T00:00:00", "ChannelId": 0 }], "CssName": null, "CatchUpUrl": "/CatchUp/24G/{0}", "CatchUpEnabled": false, "Enabled": false, "OnNow": null, "ComingUp": null, "IsLoading": true, "Category": "Regional", "ShortName": "24G", "Language": "Bangla", "MetaDescription": "Products Description", "MetaKeywords": "Products, Stuff, Monies", "PageTitle": "24 Ghanta", "CustomerCanWatch": true }, { "Name": "Alpha ETC Punjabi", "number": "20", "Id": 26, "Desc": "Alpha ETC Punjabi offers a full range of programming including Live cultural and religious discourses, top-rated drama series, news, music and much more!", "Url": "/Live/AETCPUS/26", "LogoUrl": "http://res.cloudinary.com/idiso/image/upload/h_250/v1411274989/vsahtmg4ktx8beuhj6jm.png", "ChannelTypeId": null, "EpgItems": [{ "isCatchUp": true, "StartTime": null, "Title": null, "DurationInMinutes": 1440, "IsEmpty": false, "ShowTitle": true, "UnixStartTime": 0, "UnixEndTime": 0, "ProgrammeId": 0, "ProgrammeUrl": null, "ProgrammeDesc": null, "EpisodeNo": null, "Season": null, "Cast": null, "IsPlayingNow": false, "IsCatchUp": true, "EpgItemId": 0, "StartDate": "0001-01-01T00:00:00", "EndDate": "0001-01-01T00:00:00", "ChannelId": 0 }], "CssName": null, "CatchUpUrl": "/CatchUp/AETCPUS/{0}", "CatchUpEnabled": true, "Enabled": false, "OnNow": null, "ComingUp": null, "IsLoading": true, "Category": "Family", "ShortName": "AETCPUS", "Language": "Punjabi", "MetaDescription": "Products Description", "MetaKeywords": "Products, Stuff, Monies", "PageTitle": "Alpha ETC Punjabi", "CustomerCanWatch": true }, { "Name": "ZEE Classic", "number": "24", "Id": 46, "Desc": "ZEE Classic is dedicated to Hindi cinema from 1940 to 1970. Enjoy hundreds of classic films from the era that shaped Indian cinema, starring timeless actors, including Raj Kapoor, Dev Anand, Dilip Kumar, Nargis, Vyjayanthimala, and many more!", "Url": "/Live/ZEECAPAC/46", "LogoUrl": "http://res.cloudinary.com/idiso/image/upload/h_250/v1422033877/bnikq20udkhsdcjndawn.png", "ChannelTypeId": null, "EpgItems": [{ "isCatchUp": true, "StartTime": null, "Title": null, "DurationInMinutes": 1440, "IsEmpty": false, "ShowTitle": true, "UnixStartTime": 0, "UnixEndTime": 0, "ProgrammeId": 0, "ProgrammeUrl": null, "ProgrammeDesc": null, "EpisodeNo": null, "Season": null, "Cast": null, "IsPlayingNow": false, "IsCatchUp": true, "EpgItemId": 0, "StartDate": "0001-01-01T00:00:00", "EndDate": "0001-01-01T00:00:00", "ChannelId": 0 }], "CssName": null, "CatchUpUrl": "/CatchUp/ZEECAPAC/{0}", "CatchUpEnabled": true, "Enabled": false, "OnNow": null, "ComingUp": null, "IsLoading": true, "Category": "Family", "ShortName": "ZEECAPAC", "Language": "Hindi", "MetaDescription": "Products Description", "MetaKeywords": "Products, Stuff, Monies", "PageTitle": "ZEE Classic", "CustomerCanWatch": true }, { "Name": "ZEE Marudhara", "number": "26", "Id": 28, "Desc": "ZEE Marudhara is a Rajasthani entertainment channel that features dramas, Bollywood gossip, news bulletins, movies and music based programming. ", "Url": "/Live/ZEEMARUDH/28", "LogoUrl": "http://res.cloudinary.com/idiso/image/upload/h_250/v1411275092/kkfthn5oty9ityrq3ba7.png", "ChannelTypeId": null, "EpgItems": [{ "isCatchUp": true, "StartTime": null, "Title": null, "DurationInMinutes": 1440, "IsEmpty": false, "ShowTitle": true, "UnixStartTime": 0, "UnixEndTime": 0, "ProgrammeId": 0, "ProgrammeUrl": null, "ProgrammeDesc": null, "EpisodeNo": null, "Season": null, "Cast": null, "IsPlayingNow": false, "IsCatchUp": true, "EpgItemId": 0, "StartDate": "0001-01-01T00:00:00", "EndDate": "0001-01-01T00:00:00", "ChannelId": 0 }], "CssName": null, "CatchUpUrl": "/CatchUp/ZEEMARUDH/{0}", "CatchUpEnabled": false, "Enabled": false, "OnNow": null, "ComingUp": null, "IsLoading": true, "Category": "News", "ShortName": "ZEEMARUDH", "Language": "Hindi", "MetaDescription": "Products Description", "MetaKeywords": "Products, Stuff, Monies", "PageTitle": "ZEE Marudhara", "CustomerCanWatch": true }, { "Name": "ZEE Kalinga", "number": "27", "Id": 29, "Desc": "ZEE Kalinga is one of the first 24-hour Oriya language channels. It features dramas, talk shows, news bulletins, and music based programming.  ", "Url": "/Live/ZEEKALING/29", "LogoUrl": "http://res.cloudinary.com/idiso/image/upload/h_250/v1411275219/debvsbahf6fqzi3g0bni.png", "ChannelTypeId": null, "EpgItems": [{ "isCatchUp": true, "StartTime": null, "Title": null, "DurationInMinutes": 1440, "IsEmpty": false, "ShowTitle": true, "UnixStartTime": 0, "UnixEndTime": 0, "ProgrammeId": 0, "ProgrammeUrl": null, "ProgrammeDesc": null, "EpisodeNo": null, "Season": null, "Cast": null, "IsPlayingNow": false, "IsCatchUp": true, "EpgItemId": 0, "StartDate": "0001-01-01T00:00:00", "EndDate": "0001-01-01T00:00:00", "ChannelId": 0 }], "CssName": null, "CatchUpUrl": "/CatchUp/ZEEKALING/{0}", "CatchUpEnabled": false, "Enabled": false, "OnNow": null, "ComingUp": null, "IsLoading": true, "Category": "News", "ShortName": "ZEEKALING", "Language": "Hindi", "MetaDescription": "Products Description", "MetaKeywords": "Products, Stuff, Monies", "PageTitle": "ZEE Kalinga", "CustomerCanWatch": true }, { "Name": "ZEE MP & CH", "number": "28", "Id": 30, "Desc": "ZEE MP & Chhattisgarh is a regional news channel dedicated to local and national news coverage. Viewers will have access to news bulletins, talk shows, and much more!", "Url": "/Live/ZEE MADHYA/30", "LogoUrl": "http://res.cloudinary.com/idiso/image/upload/h_250/v1411275240/cfawvykdtnv67oy7rvlh.png", "ChannelTypeId": null, "EpgItems": [{ "isCatchUp": true, "StartTime": null, "Title": null, "DurationInMinutes": 1440, "IsEmpty": false, "ShowTitle": true, "UnixStartTime": 0, "UnixEndTime": 0, "ProgrammeId": 0, "ProgrammeUrl": null, "ProgrammeDesc": null, "EpisodeNo": null, "Season": null, "Cast": null, "IsPlayingNow": false, "IsCatchUp": true, "EpgItemId": 0, "StartDate": "0001-01-01T00:00:00", "EndDate": "0001-01-01T00:00:00", "ChannelId": 0 }], "CssName": null, "CatchUpUrl": "/CatchUp/ZEE MADHYA/{0}", "CatchUpEnabled": false, "Enabled": false, "OnNow": null, "ComingUp": null, "IsLoading": true, "Category": "News", "ShortName": "ZEE MADHYA", "Language": "Hindi", "MetaDescription": "Products Description", "MetaKeywords": "Products, Stuff, Monies", "PageTitle": "ZEE MP & CH", "CustomerCanWatch": true }, { "Name": "TEN Cricket", "number": "48", "Id": 56, "Desc": "TEN Cricket is a 24-hour sports channel dedicated to all things cricket. Stay up-to-date on cricket news, watch athlete interviews and enjoy matches from all over the world!", "Url": "/Live/TENMEAPAC/56", "LogoUrl": "http://res.cloudinary.com/idiso/image/upload/h_250/v1425313759/wuld9v5uxitenghk1rh0.jpg", "ChannelTypeId": null, "EpgItems": [{ "isCatchUp": true, "StartTime": null, "Title": null, "DurationInMinutes": 1440, "IsEmpty": false, "ShowTitle": true, "UnixStartTime": 0, "UnixEndTime": 0, "ProgrammeId": 0, "ProgrammeUrl": null, "ProgrammeDesc": null, "EpisodeNo": null, "Season": null, "Cast": null, "IsPlayingNow": false, "IsCatchUp": true, "EpgItemId": 0, "StartDate": "0001-01-01T00:00:00", "EndDate": "0001-01-01T00:00:00", "ChannelId": 0 }], "CssName": null, "CatchUpUrl": "/CatchUp/TENMEAPAC/{0}", "CatchUpEnabled": false, "Enabled": false, "OnNow": null, "ComingUp": null, "IsLoading": true, "Category": "Sport", "ShortName": "TENMEAPAC", "Language": "Hindi", "MetaDescription": "Products Description", "MetaKeywords": "Products, Stuff, Monies", "PageTitle": "TEN Cricket", "CustomerCanWatch": true }, { "Name": "ZEE Sangam", "number": "53", "Id": 63, "Desc": "Dedicated to the states of Uttar Pradesh and Uttarakhand, ZEEE Sangam provides regional and national news coverage. With this 24-hour channel, never miss any important updates!", "Url": "/Live/ZEESANGAM/63", "LogoUrl": "http://res.cloudinary.com/idiso/image/upload/h_250/v1425679052/yxlzwpw1frhlh1uxbr9k.png", "ChannelTypeId": null, "EpgItems": [{ "isCatchUp": true, "StartTime": null, "Title": null, "DurationInMinutes": 1440, "IsEmpty": false, "ShowTitle": true, "UnixStartTime": 0, "UnixEndTime": 0, "ProgrammeId": 0, "ProgrammeUrl": null, "ProgrammeDesc": null, "EpisodeNo": null, "Season": null, "Cast": null, "IsPlayingNow": false, "IsCatchUp": true, "EpgItemId": 0, "StartDate": "0001-01-01T00:00:00", "EndDate": "0001-01-01T00:00:00", "ChannelId": 0 }], "CssName": null, "CatchUpUrl": "/CatchUp/ZEESANGAM/{0}", "CatchUpEnabled": false, "Enabled": false, "OnNow": null, "ComingUp": null, "IsLoading": true, "Category": "News", "ShortName": "ZEESANGAM", "Language": "Hindi", "MetaDescription": "Products Description", "MetaKeywords": "Products, Stuff, Monies", "PageTitle": "ZEE Sangam", "CustomerCanWatch": true }, { "Name": "ZEE Purvaiya", "number": "54", "Id": 64, "Desc": "ZEE Purvaiya is the leading 24-hour news channel dedicated to Bihar and Jharkhand. It features everything from politics to sports, the economy to weather. ", "Url": "/Live/ZEEPUR/64", "LogoUrl": "http://res.cloudinary.com/idiso/image/upload/h_250/v1425679070/skatyoktr5s1ypkrlwwp.png", "ChannelTypeId": null, "EpgItems": [{ "isCatchUp": true, "StartTime": null, "Title": null, "DurationInMinutes": 1440, "IsEmpty": false, "ShowTitle": true, "UnixStartTime": 0, "UnixEndTime": 0, "ProgrammeId": 0, "ProgrammeUrl": null, "ProgrammeDesc": null, "EpisodeNo": null, "Season": null, "Cast": null, "IsPlayingNow": false, "IsCatchUp": true, "EpgItemId": 0, "StartDate": "0001-01-01T00:00:00", "EndDate": "0001-01-01T00:00:00", "ChannelId": 0 }], "CssName": null, "CatchUpUrl": "/CatchUp/ZEEPUR/{0}", "CatchUpEnabled": false, "Enabled": false, "OnNow": null, "ComingUp": null, "IsLoading": true, "Category": "News", "ShortName": "ZEEPUR", "Language": "Hindi", "MetaDescription": "Products Description", "MetaKeywords": "Products, Stuff, Monies", "PageTitle": "ZEE Purvaiya", "CustomerCanWatch": true }];
    </script>
    <!-- Begin comScore Tag -->


    <!-- End comScore Tag -->
    <script>
        $(document).ready(function () {
            $.material.init();
            $.material.ripples();
            //$.material.checkbox();


            $(".mega-epg-cycle").responsiveSlides({
                auto: true,
                timeout: 6000,
                pause: true,
                pager: true
            });

          
            //mobile detection variable
            var md = new MobileDetect(window.navigator.userAgent);
            if (md.mobile()) {
                $('body').addClass('mobile-wrapper');
            } else {
                $('body').addClass('desktop-wrapper');
            }


            window.jRes.addFunc({
                breakpoint: ['tablet', 'laptop', 'desktop'],
                enter: function () {
                    $('.zee-mobile-search-form').removeClass('show');
                    $('.zee-blur-overlay').removeClass('show');
                    $('.zee-mobile-signup-buttons').fadeOut('fast');
                    $('body').removeClass('overlay-blur');
                },
                exit: function () {
                }
            });

            $('.zee-toolbar-search input[type="text"]').on('focus', function () {

                $(this).parents('.zee-toolbar-search').removeClass('blur').addClass('focus');

            });

            $('.zee-toolbar-search input[type="text"]').on('blur', function () {

                $(this).parents('.zee-toolbar-search').removeClass('focus').addClass('blur');

            });


            $('#zee_toolbar_menu').on('click', function (e) {
                e.preventDefault();
            });

            // launch mobile search field
            $('#search_mobile_btn').on('click', function (e) {
                e.preventDefault();
                $('.zee-mobile-search-form').addClass('show');
                $('.zee-mobile-search-form').find('input[type="search"]').focus();
            });

            // close mobile search field
            $('#zee_mobile_search_close').on('click', function (e) {
                e.preventDefault();
                $('.zee-mobile-search-form').removeClass('show');
            });

            // launch signup action popup
            $('#zee_mobile_signiup_btn').on('click', function (e) {
                e.preventDefault();
                $('.zee-blur-overlay').addClass('show');
                $('.zee-mobile-signup-buttons').fadeIn('slow');
                $('body').addClass('overlay-blur');
            });

            // signup popup close action
            $('#signup_close_btn').on('click', function (e) {
                e.preventDefault();

                $('.zee-mobile-signup-buttons').fadeOut('slow', function () {
                    $('.zee-blur-overlay').removeClass('show');
                    $('body').removeClass('overlay-blur');
                });
            });

            // browse menu
            if (md.mobile()) {
                // event on touch devices
                $('.zee-toolbar-menu').on('touchstart pointerdown', function () {
                    $(this).toggleClass('show');
                });
            }
            else {
                // event on desktop
                $('.zee-toolbar-menu').on('mouseenter', function () {
                    $(this).addClass('show');
                });
                $('.zee-toolbar-menu').on('mouseleave', function () {
                    $(this).removeClass('show');
                });
            };

            // browse menu hover effect on touch devices
            if (md.mobile()) {
                $('.dropdown-menu li a').on('touchstart pointerdown', function () {
                    $(this).addClass('hover');
                });
                $('.dropdown-menu li a').on('touchend pointerup', function () {
                    $(this).removeClass('hover');
                });
            };

            // user menu
            if (md.mobile()) {
                // event on touch devices
                $('.zee-toolbar-user').on('touchstart pointerdown', function () {
                    $(this).toggleClass('show');
                });
            }
            else {
                // event on desktop
                $('.zee-toolbar-user').on('mouseenter', function () {
                    $(this).addClass('show');
                });
                $('.zee-toolbar-user').on('mouseleave', function () {
                    $(this).removeClass('show');
                });
            };

            // mobile menu
            $('#zee_mobile_menu_trigger').on('click', function (e) {

                e.preventDefault();

                $('.zee-mobile-menu').addClass('active');
                $('.zee-mobile-menu-overlay').addClass('active');

                $('body, .zee-body-wrapper').addClass('mobile-menu-open');

            });

            $('#zee_mobile_menu_close').on('click', function (e) {

                e.preventDefault();

                $('.zee-mobile-menu').removeClass('active');
                $('.zee-mobile-menu-overlay').removeClass('active');
                $('body, .zee-body-wrapper').removeClass('mobile-menu-open');
            });
        });



    </script>
</body>
</html>