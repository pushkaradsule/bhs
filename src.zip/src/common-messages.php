<?php include 'inc/head.php'; ?>

<div class="zee-content-wrapper zee-myaccount-body">
    <div class="my-account-welcome">
        <div class="container">
            <div class="row">
                <h3>Cancel Subscription</h3>
            </div>
        </div>
    </div>
    <div class="container zee-myaccounter-container zee-myaccount-info">

        <div class="row">
            <div class="col-md-6 col-sm-6 col-xs-12">
                
                <!-- cancel subscription message -->
                <!--
                <h3>Thank you</h3>
                <p>We have canceled your subscription. However, you will still be able to enjoy this service until <strong>October 18, 2015</strong>.</p>
                -->

                <!-- change password message -->
                <!--
                <h3>Your password has been changed successfuly</h3>
                <br/>
                <button class="btn btn-primary withripple">Login With New Password</button>
                -->

                <!-- Activation Required -->
                <!--
                <h3 class="text-uppercase">YOU ARE ALMOST READY TO USE ZEE FAMILY!</h3>
                <hr class="seperator" />
                <p>Please check the email associated with your ZEE Family account. You will receive a message within 24 hours.</p>
                <p>Click on the link provided in the email to verify and activate your account. If the email is not in your <strong>inbox</strong>, please check your <strong>junk</strong> and <strong>spam</strong> folders. Be sure to accept ZEE Family as a contact to ensure future emails delivery directly to your inbox.</p>
                <p>Thank you<br/>The ZEE Family Team</p>
                <br/><br/>
                <hr class="seperator" />
                <p><small>the email is not in your inbox, please check your junk and spam ZEE Family as a contact to ensure future emails delivery directly to your inbox.</small></p>
                -->


            </div>
            <div class="col-md-5 col-sm-6 col-md-push-1 hidden-xs text-center section-seperator-gray">
                <img src="images/devices-wireframe.png" />
                <h3 class="text-uppercase">Watch Instantly</h3>
                <p>On Your PCs, iOS / Android devices<br/>& Samsung Smart TVs</p>
            </div>
        </div>


    </div>
</div>

<?php include 'inc/footer.php'; ?>