<?php $page = 'package'; include 'inc/head.php'; ?>



<div class="zee-content-wrapper no-banner zee-myaccount-body">
    <div class="my-account-welcome">
        <div class="container">
            <div class="row">
                <h3><small>welcome</small>Pushkar Adsule</h3>
            </div>
        </div>
    </div>
    <div class="container zee-myaccounter-container">



        <div class="zee-myaccount-nav-wrapper">
            <div class="visible-xs-inline-block myaccount-mobile-menu-trigger">
                <a href="#" id="zee_myaccount_mobile_menu_trigger">Menu</a>
            </div>
            <div id="zee_myaccount_mobile_menu">
                <?php $active_menu = 'manage'; include('inc/myaccount-menu.php'); ?>
                <?php
                /*
                 * <h4 class="zee-myaccount-linktv-header">Link your TV</h4>
                <ul class="zee-myaccount-linktv">
                <li>
                <a href="Samsung">
                <img src="/images/samsung-smart-tv.png">
                </a>
                </li>
                </ul>
                 */?>
            </div>
        </div>

        <div class="zee-myaccount-wrapper">
            <h3 class="zee-myaccount-section-heading my-profile-heading">Manage Subscription</h3>
            <div class="clearfix" style="height: 20px;"></div>


            <div class="row">

                <div class="col-sm-12">

                    <div class="packages-items-container">
                        <ul class="packages-list-container">
                            <?php for ($i = 0; $i <= 15; $i++) { ?>
                            <li class="packages-list-item">
                                <div class="packages-list-item-inner">
                                    <h3 class="package-title">ZEE Family Marathi Pack</h3>
                                    <div class="package-cost"><span>$</span>000.00 /month</div>
                                    <ul>
                                        <li>
                                            <i class="icon icon-th"></i>
                                            <span>10 Live Chanels</span>
                                            <a href="#">View Channels</a>
                                        </li>

                                        <?php if($i != '2') : ?>
                                        <li>
                                            <i class="icon icon-th"></i>
                                            <span>Access to more then 3000 movies</span>
                                        </li>
                                        <?php endif; ?>


                                        <?php if($i != '2') : ?>
                                        <li>
                                            <i class="icon icon-th"></i>
                                            <span>30 Days Live Catch-up</span>
                                        </li>
                                        <?php endif; ?>

                                    </ul>
                                    <button class="package-add<?php echo ($i == '3' ? ' package-added' : '') ?>"<?php echo ($i == '3' ? ' disabled="disabled"' : '') ?>><?php echo ($i == '3' ? 'Package Added' : 'Subscribe') ?></button>
                                    <p class="Package-summary">It is thriller film and based on the story by Sudhir Mishra's brother Sudhanshu Mishra who died in 1995. The entire plot of the film takes place through a single night.<?php echo ($i == '2' ? ' brother Sudhanshu Mishra who died in 1995. The entire plot of the film brother Sudhanshu Mishra who died in 1995. The entire plot of the film' : '') ?></p>
                                </div>
                            </li>
                            <?php } ?>
                        </ul>
                    </div>

                </div>


                <div class="col-sm-12 column-top-margin text-right">
                    <div class="form-group">
                        <button class="btn btn-material-grey">Cancel</button>
                        <button class="btn btn-primary">Confirm</button>
                    </div>
                </div>

            </div>

        </div>

    </div>
</div>



<?php include 'inc/footer.php'; ?>
<script>
    ;
    (function ($) {

        "use strict";

        $(document).ready(function () {

            var packageWin = jRespond([
                {
                    label: 'list',
                    enter: 0,
                    exit: 991
                },
                {
                    label: 'grid',
                    enter: 992,
                    exit: 3500
                }
            ]);
            packageWin.addFunc({
                breakpoint: ['grid'],
                enter: function () {
                    $('li.packages-list-item').matchHeight({
                        byRow: true,
                        property: 'height',
                    });
                },
                exit: function () {
                }
            });



        }); // document.ready

    })(jQuery);
</script>