<?php include 'inc/head.php'; ?>

<div class="zee-content-wrapper zee-myaccount-body">
    <div class="my-account-welcome">
        <div class="container">
            <div class="row">
                <h3>Page Title</h3>
            </div>
        </div>
    </div>
    <div class="container zee-myaccounter-container zee-myaccount-info">

        <div class="zee-myaccount-nav-wrapper">
            <div class="visible-xs-inline-block myaccount-mobile-menu-trigger">
                <a href="#" id="zee_myaccount_mobile_menu_trigger">Menu</a>
            </div>
            <div id="zee_myaccount_mobile_menu">
                <?php include('inc/pages-menu.php'); ?>
            </div>
        </div>

        <div class="zee-myaccount-wrapper">
            <h1>Lorem ipsum dolor sit amet, consectetur adipiscing elit</h1>
            <h2>Lorem ipsum dolor sit amet, consectetur adipiscing elit</h2>
            <h3>Lorem ipsum dolor sit amet, consectetur adipiscing elit</h3>
            <h4>Lorem ipsum dolor sit amet, consectetur adipiscing elit</h4>
            <h5>Lorem ipsum dolor sit amet, consectetur adipiscing elit</h5>
            <h6>Lorem ipsum dolor sit amet, consectetur adipiscing elit</h6>

            <hr class="seperator" />

            <p>
                <strong>Lorem ipsum dolor sit amet</strong>
                , consectetur adipiscing elit. Nullam varius quam id vehicula laoreet. Proin quis venenatis nibh, eget ultrices mi.
            </p>
            <p>
                <a href="#">Vestibulum ultricies</a>
                viverra enim ac cursus. Cras volutpat facilisis pulvinar.
            </p>
            <p>
                <u>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse nunc lorem, molestie vitae felis eget.</u>
            </p>
            <p>
                <em>efficitur convallis turpis. Nam accumsan arcu risus, a gravida ipsum porttitor in. Nam venenatis urna quis tincidunt dictum.</em>
            </p>
            <p class="text-uppercase">Cras ante orci, pellentesque ut maximus nec, fringilla nec felis. Phasellus rutrum at ligula vitae imperdiet.</p>
            <p class="text-lowercase">Aliquam massa risus, aliquam a orci in, sollicitudin sagittis dolor. Nam gravida ultricies nisl, ac porttitor tellus lobortis ac.</p>
            <p>
                <small>Fusce rutrum dolor sit amet dolor dignissim ornare. Etiam dignissim libero vestibulum ornare vehicula. Nulla facilisi. Nam ac ultrices sem, vitae pulvinar nisi.</small>
            </p>

            <hr class="seperator" />

            <button class="btn btn-primary">Primary Button</button>
            <button class="btn btn-material-grey">Secondary Button</button>

        </div>


    </div>
</div>

<?php include 'inc/footer.php'; ?>