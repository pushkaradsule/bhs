<?php
$banner = '1';
$compact_topbar == '0';
$footer_static = '1';
include 'inc/head.php';
$page = 'home';
?>
<input id="antiForgeryToken" type="hidden" value='Xte4ARRA-I47GWQegL7ehqnzUGVBRVgaFrGcHQtL_VyCg9XWfzYOMLetqaGyliGt3XVvD3u3QzkBp65zD4zHBW6nKQOJZHwD8Oe_azsVAlg1:d2fNuosbXT9KG8uQ4hlqLf1OXvgIe2y86fCZZfBfiUi-QhDmAu-ct05sk0sBvYQbQL3r5Oi9TIRskLAHpqqArdbM81Z9ZoYDfARykGkx28k1' />
<?php if($login == '0'){ ?>
<div class="zee-header-wrapper">
    <div class="zee-main-banner min-height">
        <ul class="pgwSlider zee-banner-slider" id="zee_main_banner" data-duration="10000">
            <li>
                <a href="http://bit.ly/liveCU">
                    <img src="//az608750.vo.msecnd.net/thumb/0062311.jpeg?v=997" />
                </a>
            </li>
            <li>
                <a href="http://www.zeefamily.tv/en-US">
                    <img src="//az608750.vo.msecnd.net/thumb/0062311.jpeg?v=997" />
                </a>
            </li>
        </ul><a href="#" class="banner-register-btn withripple">Click here to watch Live TV*</a></div>
</div>
<div class="zee-banner-footer">
    <div class="container-fluid">
        <div class="col-sm-6 col-sm-push-6 text-right">
            <span class="zee-banner-footer-info">*No credit card required</span>
        </div>
        <div class="col-sm-6 col-sm-pull-6">
            <a href="#" class="carousel-headers">
                <h2 class="zee-carousel-heading">Live TV</h2>
                <span class="carousel-more-arrow">
                    <i class="icon icon-right-open-2"></i>
                </span>
            </a>
        </div>
    </div>
</div>
<?php } ?>
<div class="zee-content-wrapper">
    <div class="container-fluid">

        <div class="row zee-carousel-wrapper zee-livetv-carousel">

            <div class="zee-carousel-content">
                <?php include 'inc/carousel-tv-channels.php'; ?>
                <?php //include 'inc/carousel-allchannels.php'; ?>
            </div>
        </div>

        <div class="row zee-carousel-wrapper">

            <a href="#" class="carousel-headers">
                <h2 class="zee-carousel-heading">Catchup your favorite missed TV shows</h2>
                <i class="icon icon-info-circled"></i>
            </a>
            <div class="zee-carousel-content">

                <?php include 'inc/carousel-landscape.php'; ?>

            </div>

        </div>

        <div class="row zee-carousel-wrapper">

            <a href="#" class="carousel-headers">
                <h2 class="zee-carousel-heading">Classic Shows</h2>
                <i class="icon icon-info-circled"></i>
            </a>
            <div class="zee-carousel-content">

                <?php include 'inc/carousel-portrait.php'; ?>

            </div>

        </div>

        <div class="row zee-carousel-wrapper">

            <a href="#" class="carousel-headers">
                <h2 class="zee-carousel-heading">Movie Collections</h2>
                <i class="icon icon-info-circled"></i>
            </a>
            <div class="zee-carousel-content">

                <?php include 'inc/carousel-landscape.php'; ?>

            </div>

        </div>

        <div class="row zee-carousel-wrapper">

            <a href="#" class="carousel-headers">
                <h2 class="zee-carousel-heading">Mix Marathi</h2>
                <i class="icon icon-info-circled"></i>
            </a>
            <div class="zee-carousel-content">

                <?php include 'inc/carousel-mix.php'; ?>

            </div>

        </div>

        <div class="row zee-carousel-wrapper">

            <a href="#" class="carousel-headers">
                <h2 class="zee-carousel-heading">New Release movies</h2>
                <i class="icon icon-info-circled"></i>
            </a>
            <div class="zee-carousel-content">

                <?php include 'inc/carousel-portrait.php'; ?>

            </div>

        </div>




    </div>

</div>

<div class="gototop">
    <a href="javascript:void(0)" class="withripple">
        <i class="icon icon-up-open-3"></i>
    </a>
</div>
<?php include 'inc/footer.php'; ?>
