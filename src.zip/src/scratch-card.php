<?php include 'inc/head.php'; ?>

<div class="zee-content-wrapper zee-myaccount-body">
    <div class="my-account-welcome">
        <div class="container">
            <div class="row">
                <h3>Festival Special</h3>
            </div>
        </div>
    </div>
    <div class="container zee-myaccounter-container zee-myaccount-info">

        <div class="row">
            <div class="col-md-6 col-sm-6 col-xs-12">
                <h3>Redeme Your Scratch Card</h3>
                <hr class="seperator" />
                
                <div class="zee-myaccount-error-message">
                    <div class="zee-form-message error">
                        <i class="icon icon-info"></i>
                        <p>Invalid scratch card number.</p>
                    </div>
                    <div class="clearfix" style="height: 20px;"></div>
                </div>

                <div class="zee-myaccount-error-message">
                    <div class="zee-form-message success">
                        <i class="icon icon-ok-1"></i>
                        <p>Coupon applied succesfully!</p>
                    </div>
                    <div class="clearfix" style="height: 20px;"></div>
                </div>

                <br />
                <div class="form-group">
                    <label>Scratch Card Number</label>
                    <input class="form-control" placeholder="Enter your scratch card number" type="text" />
                </div>
                <div class="form-group">
                    <button class="btn btn-primary">Redeme Now</button>
                </div>

            </div>
            <div class="col-md-6 col-sm-6 hidden-xs text-center">
                <img src="images/diwali-scratch-card-2015.jpg" class="rounded-banner" />
            </div>
        </div>


    </div>
</div>

<?php include 'inc/footer.php'; ?>