<?php
$footer_auto = '0';
$no_banner = '1';
$compact_topbar = '1';
$bodyclass = 'zee-liveplayer-page';
include 'inc/head.php';
?>




<div class="zee-content-wrapper" id="showContainer" data-player-info="{&quot;s&quot;:&quot;&#175;7&#209;&#221;&#234;&#172;&#231;u&#226;i&#170;R&#185;\u001e&#231;\u001a\u00074?&#170;il\u0010&#246;&#213;P&#203;&#223;\u0015gl&#196;e\u0017&#191;�%?,??K&#223;\u0019&#247;r�A&#234;P&#255;u\f(gs&#205;?\b?&#229;#?g\&quot;? \bp&#182;\u0014z&#247;R\u001d&#194;(?&#223;8X&#197;\u0002?S&#196;?J&#235;\u0003\&quot;&#39;&#220;C]Q&#252;L&#232;}?Vt&#39;&lt;\u0003E\u0013&#248;\u0000pi&#174;?&#233;&#188;\u0000&#165;?&#168;\u0001?\u0011&#230;8f7J@q&#216;&#203;&#166;&#189;&#178;&#248;\u0007VA\u0015/?\u000e&#197;?6&#248;&#190;&#160;&#210;&#166;B&#243;2&#204;&#242;&#239;)\u0000&#227;U?&#250;&#168;sg&#180;&quot;,&quot;h&quot;:&quot;510&quot;,&quot;w&quot;:&quot;930&quot;,&quot;BaseUrl&quot;:&quot;/&quot;,&quot;p&quot;:60,&quot;l&quot;:false,&quot;k&quot;:&quot;yhRoljHcZ98bQ0k+HbNfEXuVBdo=&quot;,&quot;i&quot;:&quot;3083&quot;,&quot;t&quot;:&quot;S&quot;,&quot;c&quot;:&quot;Avantika&quot;,&quot;pr&quot;:null,&quot;se&quot;:null}">
    <input id="antiForgeryToken" type="hidden" value='FjpgSTCoaNnkNJ7eRZXgMF9DxxXC5GEqSRV__6-IE7_gNn3Ws_-D85JOkqJr5ge8ICuNfTbwMxpNgcg64_OCwx7Hkz55-W7HohNP2-FtpUM1:wCQE9Q0GCk3A-LlKXUwg5_i5qiGgt3FvfhTQzcIq5q4Newp3Z2muYIxIUEK_vYq14w173tRuANL8IxZb96fqGI0J3ww_Tgh5NIYrzJTlx4o1' />
    <div class="live-now-paying-label">
        <label>Show</label>
        <span>Avantika - Episode 12</span>
    </div>
    <div class="zee-media-player-wrapper" style="background-image: url(http://res.cloudinary.com/idiso/image/upload/v1416706038/twozkebf46h6fsfogvhn.jpg)">
        <div class="zee-media-player" ng-hide="playerLoading">
            <!-- overlay -->
            <div class="zee-player-overlay">
                <div class="zee-player-overlay-content player-upnext-content">

                    <?php /*
                    <ul class="zee-player-overlay-items">

                    <li><a href="javascript:void(0)"><i class="icon icon-ccw"></i>Rewatch Episode 12</a></li>
                    <li><a href="javascript:void(0)" class="primary-action"><i class="icon icon-play-circled"></i>Watch Episode 13</a></li>

                    <li><a href="#"><i class="icon icon-clock"></i>Resume Play From <time>00:12:43</time> </a></li>
                    <li><a href="#" class="primary-action"><i class="icon icon-play-circled"></i>Play From Begining</a></li>

                    <li>
                    <div class="zee-player-error"><i class="icon icon-block"></i>You do now have access to this content, please login to your account and watch the show, have fun and enjoy your life.</div>
                    </li>

                    </ul>
                     */ ?>

                    <div class="player-upnext-wrapper">
                        <label>Up Next</label>
                        <h3>Episode - 13</h3>
                        <a href="#" class="play-upnext" id="play_upnext_circle"><i class="icon icon-play"></i></a>
                        <!--<div id="play_upnext_circle"></div>-->
                        <div class="clearfix"></div>
                        <a href="#" class="player-upnext-cancel">Cancel</a>
                    </div>


                </div>
            </div>

            <?php /*
            <!-- place video player code here-->
            <script src="//zeefamily.azurewebsites.net/js/jwplayer.js"></script>
            <div style="display: table; width: 100%; height: 100%;"><div id="zeeplayer"></div></div>
            <script>jwplayer.key = "udcJDrJH7pZfao0pgVPEyTqve+EFlQQdkggxCw==";
            jwplayer("zeeplayer").setup({ 
            file: "http://zeetv.vo.llnwd.net/v1/u/ZeeTV/DID_USA_NORTH_AMERICA_EDITION_ZUSA_HD.mp4",
            autostart: true, 
            width: '100%',
            height: '100%',
            aspectration: '16:9',
            primary: 'flash',
            skin: {
            name: 'seven',
            active: '#a389e3',
            inactive: '#c1c1c1',
            background: 'black'
            }
            });
            </script>
             */ ?>
        </div>
    </div>



</div>

<div class="zee-player-options-bar">
    <div class="container">
        <div class="row">
            <ul class="zee-player-options-items">
                <li><a href="javascript:void(0)" class="withripple" data-tab="player_options_tab_showoverview"><i class="icon icon-eye"></i><span class="tab-label">Show Overview</span></a></li>
                <li><a href="javascript:void(0)" class="withripple" data-tab="player_options_tab_showsynopsis"><i class="icon icon-article-alt"></i><span class="tab-label">Synopsis</span></a></li>
                <li><a href="javascript:void(0)" class="withripple" data-tab="player_options_tab_showepisodes"><i class="icon icon-th"></i><span class="tab-label">Browse Episodes</span></a></li>
            </ul>
        </div>
    </div>
</div>

<div class="zee-player-options-wrapper" id="zee_player_options_data">


    <a href="javascript:void(0)" class="close-player-info-touch" style="display: none;"><i class="icon icon-cancel-1"></i></a>

    <div class="zee-player-options-tab" id="player_options_tab_showoverview">

        <div class="container">
            <div class="row">
                <div class="col-md-2 hidden-xs hidden-sm zee-player-options-thumbnail">
                    <img src="http://images.nextv.ca/image/upload/v1416521965/z51hnowa1pevor52wbd8.jpg" />
                </div>
                <div class="col-md-10 col-xs-12">
                    <div class="zee-movies-player-info zee-show-data">
                        <div class="zee-live-channel-data">
                            <h3>Avantika</h3>
                            <ul class="channel-icons show-info-icons">
                                <li><span><i class="icon icon-tag-2"></i>Drama</span></li>
                                <li><span><i class="icon icon-globe-1"></i>Marathi</span></li>
                                <li><span><i class="icon icon-list"></i>Total Episodes: 737</span></li>
                            </ul>
                            <p class="zee-movies-cast"><span>Cast</span>Sandeep Kulkarni, Subodh Bhave, Sulekha Talwalkar, Sunil Barve, Mrinal Kulkarni, Deepa Shreeram, Sharvani Pillai, Shreyas Talpade, Ravindra Mankani, Smita Talwalkar, Purnima Bhave, Shrikant Moghe, Aadesh Bandekar, Sucheta Bandekar, Dr. Girish Oak</p>
                            <p class="zee-movies-synopsis">
                                <span>Synopsis</span> <span>This serial is the story of Avantika (Mrinal Kulkarni), a very intelligent and emotional girl, a true follower of her principles and beliefs. This serial showcases the way Avantika deals with all the trials and tribulations of her life with grit and a strong determination. She is hurt by many but never wavers and her confidence never lets her cower before the difficulties faced by her.
                                </span>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <div class="zee-player-options-tab" id="player_options_tab_showsynopsis">

        <div class="container">
            <div class="row">
                <div class="col-md-2 hidden-xs hidden-sm zee-player-options-thumbnail">
                    <img src="http://images.nextv.ca/image/upload/v1416521965/z51hnowa1pevor52wbd8.jpg" />
                </div>
                <div class="col-md-10 col-xs-12">
                    <div class="zee-movies-player-info zee-show-data">
                        <div class="zee-live-channel-data">
                            <h3>Episode - 12</h3>
                            <p class="in-this-episode">
                                <label>In this episode</label><br>
                                <span>This serial is the story of Avantika (Mrinal Kulkarni), a very intelligent and emotional girl, a true follower of her principles and beliefs. This serial showcases the way Avantika deals with all the trials and tribulations of her life with grit and a strong determination. She is hurt by many but never wavers and her confidence never lets her cower before the difficulties faced by her.</span>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <div class="zee-player-options-tab zee-player-carousel-container" id="player_options_tab_showepisodes">
        <div class="zee-player-options-utility">
            <ul>
                <li class="zee-player-options-utility-clear hidden-xs hidden-sm"><a href="javascript:void(0)" class="withripple"><i class="icon icon-clock"></i>Clear Watch History</a></li>
                <li class="zee-player-options-utility-paging">
                    <div class="form-inline">
                        <div class="form-group">
                            <label>Jump to episode no.</label>
                            <input type="number" class="form-control">
                        </div>
                        <button type="button" class="btn btn-primary">go</button>
                    </div>
                </li>
                <?php /*
                <li class="zee-player-options-utility-search">
                <div class="form-inline">
                <div class="form-group">
                <input type="text" class="form-control" placeholder="search episode">
                </div>
                <button type="button" class="btn btn-primary">searh</button>
                </div>
                </li>
                 */ ?>
            </ul>
        </div>
        <div class="player-episodes-carousel-outer all-episodes-carousel-wrapper">
            <div id="player_options_episodes_carousel">
                <?php for ($x = 13; $x <= 23; $x++) { ?>
                <a href="#" class="player-episodes-carousel-item">
                    <h3>Episode - <?php echo $x ?></h3>
                    <i class="icon icon-play-circled-1"></i>
                    <time class="all-shows-player-duration">
                        <i class="icon icon-clock-alt">00:00:00</i>
                    </time>
                    <div class="clearfix"></div>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque nec velit porttitor, bibendum neque faucibus, tempor nibh. Nunc viverra aliquet nisl, vitae blandit ex pharetra ac. Curabitur at orci at dui pulvinar rhoncus. Nunc iaculis tincidunt dui in mattis. Cras sagittis lorem ac mauris varius.</p>
                </a>
                <?php } ?>
            </div>
        </div>
    </div>

</div>


<?php $hide_footer = '1'; include 'inc/footer.php'; ?>
