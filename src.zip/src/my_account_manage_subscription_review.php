<?php include 'inc/head.php'; ?>



<div class="zee-content-wrapper no-banner zee-myaccount-body">
    <div class="my-account-welcome">
        <div class="container">
            <div class="row">
                <h3><small>welcome</small>Pushkar Adsule</h3>
            </div>
        </div>
    </div>
    <div class="container zee-myaccounter-container">



        <div class="zee-myaccount-nav-wrapper">
            <div class="visible-xs-inline-block myaccount-mobile-menu-trigger">
                <a href="#" id="zee_myaccount_mobile_menu_trigger">Menu</a>
            </div>
            <div id="zee_myaccount_mobile_menu">
                <?php $active_menu = 'manage'; include('inc/myaccount-menu.php'); ?>
                <?php
                /*
                 * <h4 class="zee-myaccount-linktv-header">Link your TV</h4>
                <ul class="zee-myaccount-linktv">
                <li>
                <a href="Samsung">
                <img src="/images/samsung-smart-tv.png">
                </a>
                </li>
                </ul>
                 */?>
            </div>
        </div>

        <div class="zee-myaccount-wrapper">
            <h3 class="zee-myaccount-section-heading my-profile-heading">Review Subscription</h3>
            <div class="clearfix" style="height: 20px;"></div>


            <div class="row">

                <div class="col-md-6 col-sm-12">
                    <div class="managesubs-review managesubs-review-old">
                        <h3>Your Old Subscription</h3>
                        <table class="table tablesaw tablesaw-stack table-chromeless" data-tablesaw-mode="stack">
                            <thead>
                                <tr>
                                    <th>Package</th>
                                    <th>Plan</th>
                                    <th class="table-cell-right">Price</th>
                                </tr>
                            </thead>
                            <tfoot>
                                <tr>
                                    <th class="tablesaw-cell-bold">Subtotal</th>
                                    <th class="tablesaw-cell-hide"></th>
                                    <th class="table-cell-right">$348.00</th>
                                </tr>
                            </tfoot>
                            <tbody>
                                <tr>
                                    <td>Zee Family Pack</td>
                                    <td>Monthly</td>
                                    <td class="table-cell-right">$249.00</td>
                                </tr>
                                <tr>
                                    <td>Zee Family Marathi Pack</td>
                                    <td>Monthly</td>
                                    <td class="table-cell-right">$99.00</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="col-md-6 col-sm-12">
                    <div class="managesubs-review managesubs-review-new">
                        <h3>Your New Subscription</h3>
                        <table class="table tablesaw tablesaw-stack table-chromeless" data-tablesaw-mode="stack">
                            <thead>
                                <tr>
                                    <th>Package</th>
                                    <th>Plan</th>
                                    <th class="table-cell-right">Price</th>
                                </tr>
                            </thead>
                            <tfoot>
                                <tr>
                                    <th class="tablesaw-cell-bold">Subtotal</th>
                                    <th class="tablesaw-cell-hide"></th>
                                    <th class="table-cell-right">$348.00</th>
                                </tr>
                            </tfoot>
                            <tbody>
                                <tr>
                                    <td>Zee Family Pack</td>
                                    <td>Monthly</td>
                                    <td class="table-cell-right">$249.00</td>
                                </tr>
                                <tr>
                                    <td>Zee Family Marathi Pack</td>
                                    <td>Monthly</td>
                                    <td class="table-cell-right">$99.00</td>
                                </tr>
                                <tr>
                                    <td>Zee Family Marathi Pack</td>
                                    <td>Monthly</td>
                                    <td class="table-cell-right">$99.00</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>


                <div class="col-sm-12 column-top-margin">
                    <div class="row">
                        <div class="checkbox checkbox-primary">
                            <label>
                                <input type="checkbox" />
                                <span class="checkbox-lbl-txt">By checking this box, I agree to allow ZEE Family to charge my credit card already on file.</span>
                            </label>
                        </div>
                        <p style="margin: 0 0 0 35px">To edit your payment information, please <a href="#">click here</a>.</p>
                    </div>
                </div>



                <div class="col-sm-12 column-top-margin text-right">
                    <button class="btn btn-material-grey">Back</button>
                    <button class="btn btn-primary">Confirm</button>
                </div>


            </div>

        </div>

    </div>
</div>

<?php include 'inc/footer.php'; ?>