<div class="zee-carousel-data zee-carousel-channels-list" ng-controller="homechannels" ng-app="home" id="channelTray">
    <div class="item">
        <div class="carousel-helper-wrapper">
            <a href="liveplayer.php/Live/ZEEHDIND/76" class="carousel-live-action"
                data-assetname="ZeeTV HD India"
                data-url="liveplayer.php/Live/ZEEHDIND/76"
                data-language="Hindi"
                data-desc="ZEE TV is a Hindi entertainment  channel which offers the best in programming ranging from gripping dramas to engaging reality shows, news, movies, special events and more!  "
                data-genre="Family"
                data-live="Live"
                data-now=""
                data-next="" data-url-catchup="/CatchUp/ZEEHDIND/{0}" data-assetid="76"></a>
            <span class="carousel-helper carousel-helper-play">
                <a href="/Live/ZEEHDIND/76"><i class="icon icon-play-1"></i></a>
            </span>
            <span class="carousel-helper carousel-helper-info">
                <a href="#" class="carousel-mobile-channel-info" data-channel-logo="http://res.cloudinary.com/idiso/image/upload/h_250/v1429565816/xbxxzff5rs8kugrtebjy.png"><i class="icon icon-info-1"></i></a>
            </span>
        </div>
        <img class="owl-lazy carousel-thumbnail carousel-allchannel-thumb" data-src="http://res.cloudinary.com/idiso/image/upload/h_250/v1429565816/xbxxzff5rs8kugrtebjy.png" />
        <label class="carousel-allchannels-label">ZeeTV HD India</label>
    </div>
    <div class="item">
        <div class="carousel-helper-wrapper">
            <a href="liveplayer.php/Live/ANDTVAPAC/57" class="carousel-live-action"
                data-assetname="ANDTV HD"
                data-url="/Live/ANDTVAPAC/57"
                data-language="Hindi"
                data-desc="&amp;TV is the flagship Hindi GEC amongst the �&amp;� bouquet of channels. Staying true to the personification of the Ampersand, &amp;TV signifies a conjunction of aspirations and rootedness which is synonymous with the spirit of New Age India. Through our content offering, we will bring together people and ideologies thus fostering cohesive viewing within Indian households. We will showcase a diverse and dynamic mix of relatable fiction, high voltage non-fiction, marquee events and blockbuster movies. 
"
                data-genre="Entertainment"
                data-live="Live"
                data-now=""
                data-next="" data-url-catchup="/CatchUp/ANDTVAPAC/{0}" data-assetid="57"></a>
            <span class="carousel-helper carousel-helper-play">
                <a href="/Live/ANDTVAPAC/57"><i class="icon icon-play-1"></i></a>
            </span>
            <span class="carousel-helper carousel-helper-info">
                <a href="#" class="carousel-mobile-channel-info" data-channel-logo="http://res.cloudinary.com/idiso/image/upload/h_250/v1425403195/brfr7r7wblj225978df9.png"><i class="icon icon-info-1"></i></a>
            </span>
        </div>
        <img class="owl-lazy carousel-thumbnail carousel-allchannel-thumb" data-src="http://res.cloudinary.com/idiso/image/upload/h_250/v1425403195/brfr7r7wblj225978df9.png" />
        <label class="carousel-allchannels-label">ANDTV HD</label>
    </div>
    <div class="item">
        <div class="carousel-helper-wrapper">
            <a href="/Live/ZEEKKAPAC/45" class="carousel-live-action"
                data-assetname="Living Foodz"
                data-url="/Live/ZEEKKAPAC/45"
                data-language="Hindi"
                data-desc="Living Foodz is an international, premium food &amp; lifestyle channel for the new age viewer. Now relish food, entertainment, lifestyle, adventure and a whole lot of fun all at once on Living Foodz."
                data-genre="Family"
                data-live="Live"
                data-now=""
                data-next="" data-url-catchup="/CatchUp/ZEEKKAPAC/{0}" data-assetid="45"></a>
            <span class="carousel-helper carousel-helper-play">
                <a href="/Live/ZEEKKAPAC/45"><i class="icon icon-play-1"></i></a>
            </span>
            <span class="carousel-helper carousel-helper-info">
                <a href="#" class="carousel-mobile-channel-info" data-channel-logo="http://res.cloudinary.com/idiso/image/upload/h_250/v1441985758/ziu16jotuguconptg4zr.png"><i class="icon icon-info-1"></i></a>
            </span>
        </div>
        <img class="owl-lazy carousel-thumbnail carousel-allchannel-thumb" data-src="http://res.cloudinary.com/idiso/image/upload/h_250/v1441985758/ziu16jotuguconptg4zr.png" />
        <label class="carousel-allchannels-label">Living Foodz</label>
    </div>
    <div class="item">
        <div class="carousel-helper-wrapper">
            <a href="/Live/ZEECININD/77" class="carousel-live-action"
                data-assetname="ZEE Cinema HD"
                data-url="/Live/ZEECININD/77"
                data-language="Hindi"
                data-desc="India�s first Bollywood movie channel, ZEE Cinema has more than 5,000 hours of movies, making it one of the largest libraries of Indian movie titles. Watch movies of all genres, from recent blockbuster hits to evergreen classics, 24-hours a day!"
                data-genre="Movies"
                data-live="Live"
                data-now=""
                data-next="" data-url-catchup="/CatchUp/ZEECININD/{0}" data-assetid="77"></a>
            <span class="carousel-helper carousel-helper-play">
                <a href="/Live/ZEECININD/77"><i class="icon icon-play-1"></i></a>
            </span>
            <span class="carousel-helper carousel-helper-info">
                <a href="#" class="carousel-mobile-channel-info" data-channel-logo="http://res.cloudinary.com/idiso/image/upload/h_250/v1429630434/a09wfnlodfus0thfzrjn.png"><i class="icon icon-info-1"></i></a>
            </span>
        </div>
        <img class="owl-lazy carousel-thumbnail carousel-allchannel-thumb" data-src="http://res.cloudinary.com/idiso/image/upload/h_250/v1429630434/a09wfnlodfus0thfzrjn.png" />
        <label class="carousel-allchannels-label">ZEE Cinema HD</label>
    </div>
    <div class="item">
        <div class="carousel-helper-wrapper">
            <a href="/Live/ZEEN/18" class="carousel-live-action"
                data-assetname="ZEE News"
                data-url="/Live/ZEEN/18"
                data-language="Hindi"
                data-desc="Get the latest headlines and breaking news from India and around the globe with ZEE News. With local, regional and international coverage of politics, business, sports and entertainment, ZEE News will help you stay informed."
                data-genre="News"
                data-live="Live"
                data-now=""
                data-next="" data-url-catchup="/CatchUp/ZEEN/{0}" data-assetid="18"></a>
            <span class="carousel-helper carousel-helper-play">
                <a href="/Live/ZEEN/18"><i class="icon icon-play-1"></i></a>
            </span>
            <span class="carousel-helper carousel-helper-info">
                <a href="#" class="carousel-mobile-channel-info" data-channel-logo="http://res.cloudinary.com/idiso/image/upload/h_250/v1411274620/ev84roo9ucfuv5tbj3ms.png"><i class="icon icon-info-1"></i></a>
            </span>
        </div>
        <img class="owl-lazy carousel-thumbnail carousel-allchannel-thumb" data-src="http://res.cloudinary.com/idiso/image/upload/h_250/v1411274620/ev84roo9ucfuv5tbj3ms.png" />
        <label class="carousel-allchannels-label">ZEE News</label>
    </div>
    <div class="item">
        <div class="carousel-helper-wrapper">
            <a href="/Live/ZLIVUS/35" class="carousel-live-action"
                data-assetname="Z Living"
                data-url="/Live/ZLIVUS/35"
                data-language="English"
                data-desc="Nirvana has a new channel! With over 50 series on healthy cooking, fitness, yoga and travel, getting wellness is now as easy as turning on the TV. Let Z Living take you to your happy place.
"
                data-genre="Entertainment"
                data-live="Live"
                data-now=""
                data-next="" data-url-catchup="/CatchUp/ZLIVUS/{0}" data-assetid="35"></a>
            <span class="carousel-helper carousel-helper-play">
                <a href="/Live/ZLIVUS/35"><i class="icon icon-play-1"></i></a>
            </span>
            <span class="carousel-helper carousel-helper-info">
                <a href="#" class="carousel-mobile-channel-info" data-channel-logo="http://res.cloudinary.com/idiso/image/upload/h_250/v1414188089/rnz115plgr35fjtyyfpw.png"><i class="icon icon-info-1"></i></a>
            </span>
        </div>
        <img class="owl-lazy carousel-thumbnail carousel-allchannel-thumb" data-src="http://res.cloudinary.com/idiso/image/upload/h_250/v1414188089/rnz115plgr35fjtyyfpw.png" />
        <label class="carousel-allchannels-label">Z Living</label>
    </div>
    <div class="item">
        <div class="carousel-helper-wrapper">
            <a href="/Live/ZMARINDA/49" class="carousel-live-action"
                data-assetname="ZEE Marathi India"
                data-url="/Live/ZMARINDA/49"
                data-language="Marathi"
                data-desc="ZEE Marathi is an entertainment channel that features dramas, non-fiction shows, reality shows, news bulletins, devotional programs, movies and music-based shows. "
                data-genre="Family"
                data-live="Live"
                data-now=""
                data-next="" data-url-catchup="/CatchUp/ZMARINDA/{0}" data-assetid="49"></a>
            <span class="carousel-helper carousel-helper-play">
                <a href="/Live/ZMARINDA/49"><i class="icon icon-play-1"></i></a>
            </span>
            <span class="carousel-helper carousel-helper-info">
                <a href="#" class="carousel-mobile-channel-info" data-channel-logo="http://res.cloudinary.com/idiso/image/upload/h_250/v1422033997/bnew2kl8uh4chei6pm9b.png"><i class="icon icon-info-1"></i></a>
            </span>
        </div>
        <img class="owl-lazy carousel-thumbnail carousel-allchannel-thumb" data-src="http://res.cloudinary.com/idiso/image/upload/h_250/v1422033997/bnew2kl8uh4chei6pm9b.png" />
        <label class="carousel-allchannels-label">ZEE Marathi India</label>
    </div>
    <div class="item">
        <div class="carousel-helper-wrapper">
            <a href="/Live/ZEEBAAPAC/38" class="carousel-live-action"
                data-assetname="ZEE Bangla"
                data-url="/Live/ZEEBAAPAC/38"
                data-language="Bangla"
                data-desc="ZEE Bangla is an entertainment channel that features dramas, non-fiction shows, reality shows, news bulletins, devotional programs, movies and music based shows. "
                data-genre="Family"
                data-live="Live"
                data-now=""
                data-next="" data-url-catchup="/CatchUp/ZEEBAAPAC/{0}" data-assetid="38"></a>
            <span class="carousel-helper carousel-helper-play">
                <a href="/Live/ZEEBAAPAC/38"><i class="icon icon-play-1"></i></a>
            </span>
            <span class="carousel-helper carousel-helper-info">
                <a href="#" class="carousel-mobile-channel-info" data-channel-logo="http://res.cloudinary.com/idiso/image/upload/h_250/v1422033186/yqzaic50wozz0ahw4umu.png"><i class="icon icon-info-1"></i></a>
            </span>
        </div>
        <img class="owl-lazy carousel-thumbnail carousel-allchannel-thumb" data-src="http://res.cloudinary.com/idiso/image/upload/h_250/v1422033186/yqzaic50wozz0ahw4umu.png" />
        <label class="carousel-allchannels-label">ZEE Bangla</label>
    </div>
    <div class="item">
        <div class="carousel-helper-wrapper">
            <a href="/Live/ZEESALAPAC/55" class="carousel-live-action"
                data-assetname="ZEE Salaam"
                data-url="/Live/ZEESALAPAC/55"
                data-language="Urdu"
                data-desc="ZEE Salaam is an Urdu language religious and spiritual channel. It aims to entertain the viewers with mythological movies, serials, religious discourses and spiritual programs. Audiences will learn about alternative and holistic approaches to health and wellness in addition to spiritual wellbeing. "
                data-genre="Family"
                data-live="Live"
                data-now=""
                data-next="" data-url-catchup="/CatchUp/ZEESALAPAC/{0}" data-assetid="55"></a>
            <span class="carousel-helper carousel-helper-play">
                <a href="/Live/ZEESALAPAC/55"><i class="icon icon-play-1"></i></a>
            </span>
            <span class="carousel-helper carousel-helper-info">
                <a href="#" class="carousel-mobile-channel-info" data-channel-logo="http://res.cloudinary.com/idiso/image/upload/h_250/v1422032950/r6zd651v3wvf6zauzt0f.png"><i class="icon icon-info-1"></i></a>
            </span>
        </div>
        <img class="owl-lazy carousel-thumbnail carousel-allchannel-thumb" data-src="http://res.cloudinary.com/idiso/image/upload/h_250/v1422032950/r6zd651v3wvf6zauzt0f.png" />
        <label class="carousel-allchannels-label">ZEE Salaam</label>
    </div>
    <div class="item">
        <div class="carousel-helper-wrapper">
            <a href="/Live/ZEEBUSAPAC/39" class="carousel-live-action"
                data-assetname="ZEE Business"
                data-url="/Live/ZEEBUSAPAC/39"
                data-language="English"
                data-desc="ZEE Business is a 24-hour news and infotainment channel that keeps viewers updated on happenings in the business world, from the stock market to investment trends to real estate and tech news!"
                data-genre="News"
                data-live="Live"
                data-now=""
                data-next="" data-url-catchup="/CatchUp/ZEEBUSAPAC/{0}" data-assetid="39"></a>
            <span class="carousel-helper carousel-helper-play">
                <a href="/Live/ZEEBUSAPAC/39"><i class="icon icon-play-1"></i></a>
            </span>
            <span class="carousel-helper carousel-helper-info">
                <a href="#" class="carousel-mobile-channel-info" data-channel-logo="http://res.cloudinary.com/idiso/image/upload/h_250/v1422033286/hn9lyexfcxv7hai5nojm.png"><i class="icon icon-info-1"></i></a>
            </span>
        </div>
        <img class="owl-lazy carousel-thumbnail carousel-allchannel-thumb" data-src="http://res.cloudinary.com/idiso/image/upload/h_250/v1422033286/hn9lyexfcxv7hai5nojm.png" />
        <label class="carousel-allchannels-label">ZEE Business</label>
    </div>
    <div class="item">
        <div class="carousel-helper-wrapper">
            <a href="/Live/ZEEPUNAPAC/44" class="carousel-live-action"
                data-assetname="ZEE Punjabi"
                data-url="/Live/ZEEPUNAPAC/44"
                data-language="Punjabi"
                data-desc="ZEE Punjabi is a channel that offers a variety of programs such as dramas, talk shows, game shows, comedies, cooking shows, and films. With this family entertainment channel, viewers will enjoy top-rated Punjabi programming all day long!"
                data-genre="Family"
                data-live="Live"
                data-now=""
                data-next="" data-url-catchup="/CatchUp/ZEEPUNAPAC/{0}" data-assetid="44"></a>
            <span class="carousel-helper carousel-helper-play">
                <a href="/Live/ZEEPUNAPAC/44"><i class="icon icon-play-1"></i></a>
            </span>
            <span class="carousel-helper carousel-helper-info">
                <a href="#" class="carousel-mobile-channel-info" data-channel-logo="http://res.cloudinary.com/idiso/image/upload/h_250/v1422033564/nzdub4zif1fjirlft6fu.png"><i class="icon icon-info-1"></i></a>
            </span>
        </div>
        <img class="owl-lazy carousel-thumbnail carousel-allchannel-thumb" data-src="http://res.cloudinary.com/idiso/image/upload/h_250/v1422033564/nzdub4zif1fjirlft6fu.png" />
        <label class="carousel-allchannels-label">ZEE Punjabi</label>
    </div>
    <div class="item">
        <div class="carousel-helper-wrapper">
            <a href="/Live/ZEETALAPAC/40" class="carousel-live-action"
                data-assetname="ZEE Talkies"
                data-url="/Live/ZEETALAPAC/40"
                data-language="Marathi"
                data-desc="ZEE Talkies is a Marathi language movie channel. Tune in for your favorite action, comedy, romantic and classic movies from the entire repertoire of Marathi Cinema, 24-hours a day!"
                data-genre="Family"
                data-live="Live"
                data-now=""
                data-next="" data-url-catchup="/CatchUp/ZEETALAPAC/{0}" data-assetid="40"></a>
            <span class="carousel-helper carousel-helper-play">
                <a href="/Live/ZEETALAPAC/40"><i class="icon icon-play-1"></i></a>
            </span>
            <span class="carousel-helper carousel-helper-info">
                <a href="#" class="carousel-mobile-channel-info" data-channel-logo="http://res.cloudinary.com/idiso/image/upload/h_250/v1422033374/vxfggc2wlv5fbcxrfiqr.png"><i class="icon icon-info-1"></i></a>
            </span>
        </div>
        <img class="owl-lazy carousel-thumbnail carousel-allchannel-thumb" data-src="http://res.cloudinary.com/idiso/image/upload/h_250/v1422033374/vxfggc2wlv5fbcxrfiqr.png" />
        <label class="carousel-allchannels-label">ZEE Talkies</label>
    </div>
    <div class="item">
        <div class="carousel-helper-wrapper">
            <a href="/Live/24TA/13" class="carousel-live-action"
                data-assetname="24 Taas"
                data-url="/Live/24TA/13"
                data-language="Marathi"
                data-desc="The first and leading 24-hour Marathi news channel of its kind, 24 Taas dedicated to local, regional and national news coverage. It also offers sports programming and entertainment news, all in Marathi!"
                data-genre="News"
                data-live="Live"
                data-now=""
                data-next="" data-url-catchup="/CatchUp/24TA/{0}" data-assetid="13"></a>
            <span class="carousel-helper carousel-helper-play">
                <a href="/Live/24TA/13"><i class="icon icon-play-1"></i></a>
            </span>
            <span class="carousel-helper carousel-helper-info">
                <a href="#" class="carousel-mobile-channel-info" data-channel-logo="http://res.cloudinary.com/idiso/image/upload/h_250/v1411274824/jg6m4f2ys0ibfnhahxor.png"><i class="icon icon-info-1"></i></a>
            </span>
        </div>
        <img class="owl-lazy carousel-thumbnail carousel-allchannel-thumb" data-src="http://res.cloudinary.com/idiso/image/upload/h_250/v1411274824/jg6m4f2ys0ibfnhahxor.png" />
        <label class="carousel-allchannels-label">24 Taas</label>
    </div>
    <div class="item">
        <div class="carousel-helper-wrapper">
            <a href="/Live/ZEEBCAPAC/41" class="carousel-live-action"
                data-assetname="ZEE Bangla Cinema"
                data-url="/Live/ZEEBCAPAC/41"
                data-language="Bangla"
                data-desc="ZEE Bangla Cinema is a Bangla language movie channel. Tune in for your favorite action, comedy, romantic and classic movies from the entire repertoire of Bengali Cinema, 24-hours a day!"
                data-genre="Family"
                data-live="Live"
                data-now=""
                data-next="" data-url-catchup="/CatchUp/ZEEBCAPAC/{0}" data-assetid="41"></a>
            <span class="carousel-helper carousel-helper-play">
                <a href="/Live/ZEEBCAPAC/41"><i class="icon icon-play-1"></i></a>
            </span>
            <span class="carousel-helper carousel-helper-info">
                <a href="#" class="carousel-mobile-channel-info" data-channel-logo="http://res.cloudinary.com/idiso/image/upload/h_250/v1422033435/z0jrff5jlcktgu4qfx7v.png"><i class="icon icon-info-1"></i></a>
            </span>
        </div>
        <img class="owl-lazy carousel-thumbnail carousel-allchannel-thumb" data-src="http://res.cloudinary.com/idiso/image/upload/h_250/v1422033435/z0jrff5jlcktgu4qfx7v.png" />
        <label class="carousel-allchannels-label">ZEE Bangla Cinema</label>
    </div>
    <div class="item">
        <div class="carousel-helper-wrapper">
            <a href="/Live/24G/14" class="carousel-live-action"
                data-assetname="24 Ghanta"
                data-url="/Live/24G/14"
                data-language="Bangla"
                data-desc="The first and leading 24-hour Bengali news channel of its kind, 24 Ghanta is dedicated to local, regional and national news coverage. It also offers sports programming and entertainment news, all in Bengali!"
                data-genre="Regional"
                data-live="Live"
                data-now=""
                data-next="" data-url-catchup="/CatchUp/24G/{0}" data-assetid="14"></a>
            <span class="carousel-helper carousel-helper-play">
                <a href="/Live/24G/14"><i class="icon icon-play-1"></i></a>
            </span>
            <span class="carousel-helper carousel-helper-info">
                <a href="#" class="carousel-mobile-channel-info" data-channel-logo="http://res.cloudinary.com/idiso/image/upload/h_250/v1411274881/aioxxbysulmx1fdcn493.png"><i class="icon icon-info-1"></i></a>
            </span>
        </div>
        <img class="owl-lazy carousel-thumbnail carousel-allchannel-thumb" data-src="http://res.cloudinary.com/idiso/image/upload/h_250/v1411274881/aioxxbysulmx1fdcn493.png" />
        <label class="carousel-allchannels-label">24 Ghanta</label>
    </div>
    <div class="item">
        <div class="carousel-helper-wrapper">
            <a href="/Live/AETCPUS/26" class="carousel-live-action"
                data-assetname="Alpha ETC Punjabi"
                data-url="/Live/AETCPUS/26"
                data-language="Punjabi"
                data-desc="Alpha ETC Punjabi offers a full range of programming including Live cultural and religious discourses, top-rated drama series, news, music and much more!"
                data-genre="Family"
                data-live="Live"
                data-now=""
                data-next="" data-url-catchup="/CatchUp/AETCPUS/{0}" data-assetid="26"></a>
            <span class="carousel-helper carousel-helper-play">
                <a href="/Live/AETCPUS/26"><i class="icon icon-play-1"></i></a>
            </span>
            <span class="carousel-helper carousel-helper-info">
                <a href="#" class="carousel-mobile-channel-info" data-channel-logo="http://res.cloudinary.com/idiso/image/upload/h_250/v1411274989/vsahtmg4ktx8beuhj6jm.png"><i class="icon icon-info-1"></i></a>
            </span>
        </div>
        <img class="owl-lazy carousel-thumbnail carousel-allchannel-thumb" data-src="http://res.cloudinary.com/idiso/image/upload/h_250/v1411274989/vsahtmg4ktx8beuhj6jm.png" />
        <label class="carousel-allchannels-label">Alpha ETC Punjabi</label>
    </div>
    <div class="item">
        <div class="carousel-helper-wrapper">
            <a href="/Live/ZEECAPAC/46" class="carousel-live-action"
                data-assetname="ZEE Classic"
                data-url="/Live/ZEECAPAC/46"
                data-language="Hindi"
                data-desc="ZEE Classic is dedicated to Hindi cinema from 1940 to 1970. Enjoy hundreds of classic films from the era that shaped Indian cinema, starring timeless actors, including Raj Kapoor, Dev Anand, Dilip Kumar, Nargis, Vyjayanthimala, and many more!"
                data-genre="Family"
                data-live="Live"
                data-now=""
                data-next="" data-url-catchup="/CatchUp/ZEECAPAC/{0}" data-assetid="46"></a>
            <span class="carousel-helper carousel-helper-play">
                <a href="/Live/ZEECAPAC/46"><i class="icon icon-play-1"></i></a>
            </span>
            <span class="carousel-helper carousel-helper-info">
                <a href="#" class="carousel-mobile-channel-info" data-channel-logo="http://res.cloudinary.com/idiso/image/upload/h_250/v1422033877/bnikq20udkhsdcjndawn.png"><i class="icon icon-info-1"></i></a>
            </span>
        </div>
        <img class="owl-lazy carousel-thumbnail carousel-allchannel-thumb" data-src="http://res.cloudinary.com/idiso/image/upload/h_250/v1422033877/bnikq20udkhsdcjndawn.png" />
        <label class="carousel-allchannels-label">ZEE Classic</label>
    </div>
    <div class="item">
        <div class="carousel-helper-wrapper">
            <a href="/Live/ZEEMARUDH/28" class="carousel-live-action"
                data-assetname="ZEE Marudhara"
                data-url="/Live/ZEEMARUDH/28"
                data-language="Hindi"
                data-desc="ZEE Marudhara is a Rajasthani entertainment channel that features dramas, Bollywood gossip, news bulletins, movies and music based programming. "
                data-genre="News"
                data-live="Live"
                data-now=""
                data-next="" data-url-catchup="/CatchUp/ZEEMARUDH/{0}" data-assetid="28"></a>
            <span class="carousel-helper carousel-helper-play">
                <a href="/Live/ZEEMARUDH/28"><i class="icon icon-play-1"></i></a>
            </span>
            <span class="carousel-helper carousel-helper-info">
                <a href="#" class="carousel-mobile-channel-info" data-channel-logo="http://res.cloudinary.com/idiso/image/upload/h_250/v1411275092/kkfthn5oty9ityrq3ba7.png"><i class="icon icon-info-1"></i></a>
            </span>
        </div>
        <img class="owl-lazy carousel-thumbnail carousel-allchannel-thumb" data-src="http://res.cloudinary.com/idiso/image/upload/h_250/v1411275092/kkfthn5oty9ityrq3ba7.png" />
        <label class="carousel-allchannels-label">ZEE Marudhara</label>
    </div>
    <div class="item">
        <div class="carousel-helper-wrapper">
            <a href="/Live/ZEEKALING/29" class="carousel-live-action"
                data-assetname="ZEE Kalinga"
                data-url="/Live/ZEEKALING/29"
                data-language="Hindi"
                data-desc="ZEE Kalinga is one of the first 24-hour Oriya language channels. It features dramas, talk shows, news bulletins, and music based programming.  "
                data-genre="News"
                data-live="Live"
                data-now=""
                data-next="" data-url-catchup="/CatchUp/ZEEKALING/{0}" data-assetid="29"></a>
            <span class="carousel-helper carousel-helper-play">
                <a href="/Live/ZEEKALING/29"><i class="icon icon-play-1"></i></a>
            </span>
            <span class="carousel-helper carousel-helper-info">
                <a href="#" class="carousel-mobile-channel-info" data-channel-logo="http://res.cloudinary.com/idiso/image/upload/h_250/v1411275219/debvsbahf6fqzi3g0bni.png"><i class="icon icon-info-1"></i></a>
            </span>
        </div>
        <img class="owl-lazy carousel-thumbnail carousel-allchannel-thumb" data-src="http://res.cloudinary.com/idiso/image/upload/h_250/v1411275219/debvsbahf6fqzi3g0bni.png" />
        <label class="carousel-allchannels-label">ZEE Kalinga</label>
    </div>
    <div class="item">
        <div class="carousel-helper-wrapper">
            <a href="/Live/ZEE MADHYA/30" class="carousel-live-action"
                data-assetname="ZEE MP &amp; CH"
                data-url="/Live/ZEE MADHYA/30"
                data-language="Hindi"
                data-desc="ZEE MP &amp; Chhattisgarh is a regional news channel dedicated to local and national news coverage. Viewers will have access to news bulletins, talk shows, and much more!"
                data-genre="News"
                data-live="Live"
                data-now=""
                data-next="" data-url-catchup="/CatchUp/ZEE MADHYA/{0}" data-assetid="30"></a>
            <span class="carousel-helper carousel-helper-play">
                <a href="/Live/ZEE MADHYA/30"><i class="icon icon-play-1"></i></a>
            </span>
            <span class="carousel-helper carousel-helper-info">
                <a href="#" class="carousel-mobile-channel-info" data-channel-logo="http://res.cloudinary.com/idiso/image/upload/h_250/v1411275240/cfawvykdtnv67oy7rvlh.png"><i class="icon icon-info-1"></i></a>
            </span>
        </div>
        <img class="owl-lazy carousel-thumbnail carousel-allchannel-thumb" data-src="http://res.cloudinary.com/idiso/image/upload/h_250/v1411275240/cfawvykdtnv67oy7rvlh.png" />
        <label class="carousel-allchannels-label">ZEE MP &amp; CH</label>
    </div>
    <div class="item">
        <div class="carousel-helper-wrapper">
            <a href="/Live/TENMEAPAC/56" class="carousel-live-action"
                data-assetname="TEN Cricket"
                data-url="/Live/TENMEAPAC/56"
                data-language="Hindi"
                data-desc="TEN Cricket is a 24-hour sports channel dedicated to all things cricket. Stay up-to-date on cricket news, watch athlete interviews and enjoy matches from all over the world!"
                data-genre="Sport"
                data-live="Live"
                data-now=""
                data-next="" data-url-catchup="/CatchUp/TENMEAPAC/{0}" data-assetid="56"></a>
            <span class="carousel-helper carousel-helper-play">
                <a href="/Live/TENMEAPAC/56"><i class="icon icon-play-1"></i></a>
            </span>
            <span class="carousel-helper carousel-helper-info">
                <a href="#" class="carousel-mobile-channel-info" data-channel-logo="http://res.cloudinary.com/idiso/image/upload/h_250/v1425313759/wuld9v5uxitenghk1rh0.jpg"><i class="icon icon-info-1"></i></a>
            </span>
        </div>
        <img class="owl-lazy carousel-thumbnail carousel-allchannel-thumb" data-src="http://res.cloudinary.com/idiso/image/upload/h_250/v1425313759/wuld9v5uxitenghk1rh0.jpg" />
        <label class="carousel-allchannels-label">TEN Cricket</label>
    </div>
    <div class="item">
        <div class="carousel-helper-wrapper">
            <a href="/Live/ZEESANGAM/63" class="carousel-live-action"
                data-assetname="ZEE Sangam"
                data-url="/Live/ZEESANGAM/63"
                data-language="Hindi"
                data-desc="Dedicated to the states of Uttar Pradesh and Uttarakhand, ZEEE Sangam provides regional and national news coverage. With this 24-hour channel, never miss any important updates!"
                data-genre="News"
                data-live="Live"
                data-now=""
                data-next="" data-url-catchup="/CatchUp/ZEESANGAM/{0}" data-assetid="63"></a>
            <span class="carousel-helper carousel-helper-play">
                <a href="/Live/ZEESANGAM/63"><i class="icon icon-play-1"></i></a>
            </span>
            <span class="carousel-helper carousel-helper-info">
                <a href="#" class="carousel-mobile-channel-info" data-channel-logo="http://res.cloudinary.com/idiso/image/upload/h_250/v1425679052/yxlzwpw1frhlh1uxbr9k.png"><i class="icon icon-info-1"></i></a>
            </span>
        </div>
        <img class="owl-lazy carousel-thumbnail carousel-allchannel-thumb" data-src="http://res.cloudinary.com/idiso/image/upload/h_250/v1425679052/yxlzwpw1frhlh1uxbr9k.png" />
        <label class="carousel-allchannels-label">ZEE Sangam</label>
    </div>
    <div class="item">
        <div class="carousel-helper-wrapper">
            <a href="/Live/ZEEPUR/64" class="carousel-live-action"
                data-assetname="ZEE Purvaiya"
                data-url="/Live/ZEEPUR/64"
                data-language="Hindi"
                data-desc="ZEE Purvaiya is the leading 24-hour news channel dedicated to Bihar and Jharkhand. It features everything from politics to sports, the economy to weather. "
                data-genre="News"
                data-live="Live"
                data-now=""
                data-next="" data-url-catchup="/CatchUp/ZEEPUR/{0}" data-assetid="64"></a>
            <span class="carousel-helper carousel-helper-play">
                <a href="/Live/ZEEPUR/64"><i class="icon icon-play-1"></i></a>
            </span>
            <span class="carousel-helper carousel-helper-info">
                <a href="#" class="carousel-mobile-channel-info" data-channel-logo="http://res.cloudinary.com/idiso/image/upload/h_250/v1425679070/skatyoktr5s1ypkrlwwp.png"><i class="icon icon-info-1"></i></a>
            </span>
        </div>
        <img class="owl-lazy carousel-thumbnail carousel-allchannel-thumb" data-src="http://res.cloudinary.com/idiso/image/upload/h_250/v1425679070/skatyoktr5s1ypkrlwwp.png" />
        <label class="carousel-allchannels-label">ZEE Purvaiya</label>
    </div>
    <div class="item no-hover-arrow">
        <a href="#">
            <img class="owl-lazy carousel-thumbnail carousel-allchannel-thumb" data-src="images/153x153-tv-guide.png" />
            <label class="carousel-allchannels-label">TV GUIDE</label>
        </a>
    </div>

</div>

<?php /*
<div class="zee-carousel-data">

<?php for ($i = 0; $i <= 14; $i++) { ?>
<div class="item">

<div class="carousel-helper-wrapper">
<a href="/WatchMovie/is-raat-ki-subah-nahi/373" class="carousel-live-action"
data-assetname="ZeeTV HD India"
data-url="liveplayer.php/Live/ZEEHDIND/76"
data-language="Hindi"
data-desc="ZEE TV is a Hindi entertainment  channel which offers the best in programming ranging from gripping dramas to engaging reality shows, news, movies, special events and more!  "
data-genre="Family"
data-live="Live"
data-now=""
data-next="" data-url-catchup="/CatchUp/ZEEHDIND/{0}" data-assetid="76"></a>
<span class="carousel-helper carousel-helper-play">
<a href="/WatchMovie/is-raat-ki-subah-nahi/373"><i class="icon icon-play-1"></i></a>
</span>
<span class="carousel-helper carousel-helper-info">
<a href="#" class="carousel-mobile-info" data-thumbnail="http://images.nextv.ca/image/upload/h_250/v1433862639/kq9hph2wev6upc9crx4i.jpg"><i class="icon icon-info-1"></i></a>
</span>
</div>
<img class="carousel-thumbnail carousel-allchannel-thumb" src="http://res.cloudinary.com/idiso/image/upload/h_250/v1425403195/brfr7r7wblj225978df9.png">
<label class="carousel-allchannels-label">Zee Family HD</label>
</div>
<?php } ?>
</div>
 */ ?>