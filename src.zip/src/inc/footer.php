</div>
<?php if(!isset($hide_footer)){ ?>
<div class="zee-footer">
    <div class="container">
        <div class="row zee-footer-devices">
            <div class="col-md-6 col-lg-4 col-sm-6 col-xs-12 zee-footer-link">
                <h3>Need Help?</h3>
                <ul class="col-md-6 col-sm-6 col-xs-6">

                    <li><i class="icon icon-angle-right"></i><a href="/about-us">About Us</a></li>
                    <li><i class="icon icon-angle-right"></i><a href="/contact-us">Contact Us</a></li>
                    <li><i class="icon icon-angle-right"></i><a href="/what-is-zee-family-tv">What is ZEE Family?</a></li>
                </ul>

                <ul class="col-md-6 col-sm-6 col-xs-6">
                    <li><i class="icon icon-angle-right"></i><a href="/privacy-policy">Privacy Policy</a></li>
                    <li><i class="icon icon-angle-right"></i><a href="/terms-of-use">Terms Of Service</a></li>
                    <li class="zee-social-links">
                        <div class="zee-social-connection">
                            <a href="//www.facebook.com/ZeeFamilyTV" target="_blank"><i class="icon icon-facebook"></i><span class="sr-only">facebook</span></a>
                            <a href="//twitter.com/zeefamilytv" target="_blank"><i class="icon icon-twitter"></i><span class="sr-only">twitter</span></a>
                            <a href="//plus.google.com/107041805342725425376" target="_blank"><i class="icon icon-gplus-1"></i><span class="sr-only">google plus</span></a>
                            <a href="https://www.youtube.com/channel/UCfd_l16LomZ0dRkIGxnGbWA" target="_blank"><i class="icon icon-youtube-play"></i><span class="sr-only">YouTube</span></a>
                        </div>
                    </li>
                </ul>

            </div>
            <div class="col-md-6 col-lg-8 col-sm-6 col-xs-12">
                <h3>Supported Devices</h3>
                <div class="zee-devices-carousel">
                    <img src="/images/devices-desktop.jpg">
                    <a href="//itunes.apple.com/us/app/zeefamily/id932704754?mt=8" target="_blank">
                        <img src="/images/devices-ios.jpg">
                    </a>
                    <a href="/Samsung">
                        <img src="/images/devices-samsung-tv.jpg">
                    </a>
                    <a href="//play.google.com/store/apps/details?id=ca.icssolutions.zeefamily.mobile" target="_blank">
                        <img src="/images/devices-android.jpg">
                    </a>
                    <a href="//bit.ly/ZFAmazonApp" target="_blank">
                        <img src="/images/sd-amazon.jpg">
                    </a>
                    <a href="#" target="_blank">
                        <img src="/images/device-firetv.jpg">
                    </a>
                    <a href="#" target="_blank">
                        <img src="/images/device-roku.jpg">
                    </a>
                </div>
            </div>
        </div>
        <div class="row-fluid zee-footer-copyright">
            <p>
                Use of ZEE Family TV and this website constitutes acceptance of our <a style="color: #505050" href="/terms-of-use">Terms Of Service</a>. All rights reserved.
            </p>
        </div>
    </div>
</div>
<?php } ?>



<script src='/js/jquery-1.11.0.min.js'></script>
<script src='/js/jquery-migrate-1.2.1.min.js'></script>
<script src='/js/modernizr.custom.min.js'></script>
<script src='/js/jrespond.min.js'></script>
<script src='/js/jquery.tinyscrollbar.min.js'></script>
<script src='/js/typehead.js'></script>
<script src='/js/handlebars-v1.3.0.js'></script>
<script src='/js/jquery.jscroll.js'></script>
<script src='/js/toe.js'></script>
<script src='/js/mobile-detect.min.js'></script>
<script src='/js/mobile-detect-modernizr.js'></script>
<script src='/js/waypoints.min.js'></script>
<script src='/js/imagesloaded.js'></script>
<script src='/js/jquery.lazy.min.js'></script>
<script src='/js/throttle.deboiunce.min.js'></script>
<script src='/js/underscore-min.js'></script>
<script src='/js/owl.carousel.js'></script>
<script src='/js/jquery.qtip.min.js'></script>
<script src='/js/pgwslider.min.js'></script>
<script src='/js/jquery.shorten.js'></script>
<script src='/js/jquery.magnific-popup.min.js'></script>
<script src='/js/tinynav.min.js'></script>
<script src='/js/jquery.selectric.min.js'></script>
<script src='/js/icheck.min.js'></script>
<script src='/js/footable.min.js'></script>
<script src='/js/jquery.mCustomScrollbar.concat.min.js'></script>
<script src='/js/pageguide.min.js'></script>
<script src='/js/sweet-alert.js'></script>
<script src='/js/swfobject.js'></script>
<script src='/js/responsiveslides.min.js'></script>
<script src='/js/circle-progress.js'></script>

<script src='/js/jquery.matchheight-min.js'></script>

<script src='/js/tablesaw.js'></script>
<script src='/js/ripples.min.js'></script>
<script src='/js/material.min.js'></script>

<script src='/js/browse-shows-movies.js'></script>
<script src='/js/scripts.js'></script>


<?php 
if ($page =='livepage') { ?>


<script src='/js/angular.min.js'></script>
<script src='/json/angular-mocks.js'></script>
<script src='/js/angular-ui-router.js'></script>
<script src='/js/streamsense.4.1505.18.min.js'></script>
<script src='/js/liveplayer.module.js'></script>
<script src='/js/jwplayer.js'></script>
<script src='/scripts/jquery.sha1.js'></script>
<script src='/scripts/totalStorage.js'></script>
<script src='/scripts/jwplayer-resumable.js'></script>
<script src='/scripts/linqjs.js'></script>
<script src='/js/ngProgress.js'></script>
<script src='/js/ZeeEpgService.js'></script>
<script src='/js/liveplayer.js'></script>
<script src='/js/zeeplayer.js'></script>

<script>
    window.baseUrl = "/";
    angular.module("main").value("playerData", { k: "FtqY5w/CvgEGEaFhYMKjb85OUyc=", s: "e50c1f38-1b6c-4eba-808f-b97048e3a5db" })
		.value("allChannels", [{ "Name": "ZeeTV HD India", "number": "01", "Id": 76, "Desc": "ZEE TV is a Hindi entertainment  channel which offers the best in programming ranging from gripping dramas to engaging reality shows, news, movies, special events and more!  ", "Url": "/Live/ZEEHDIND/76", "LogoUrl": "http://res.cloudinary.com/idiso/image/upload/h_250/v1429565816/xbxxzff5rs8kugrtebjy.png", "ChannelTypeId": null, "EpgItems": [{ "isCatchUp": true, "StartTime": null, "Title": null, "DurationInMinutes": 1440, "IsEmpty": false, "ShowTitle": true, "UnixStartTime": 0, "UnixEndTime": 0, "ProgrammeId": 0, "ProgrammeUrl": null, "ProgrammeDesc": null, "EpisodeNo": null, "Season": null, "Cast": null, "IsPlayingNow": false, "IsCatchUp": true, "EpgItemId": 0, "StartDate": "0001-01-01T00:00:00", "EndDate": "0001-01-01T00:00:00", "ChannelId": 0 }], "CssName": null, "CatchUpUrl": "/CatchUp/ZEEHDIND/{0}", "CatchUpEnabled": true, "Enabled": false, "OnNow": null, "ComingUp": null, "IsLoading": true, "Category": "Family", "ShortName": "ZEEHDIND", "Language": "Hindi", "MetaDescription": "Products Description", "MetaKeywords": "Products, Stuff, Monies", "PageTitle": "ZeeTV HD India", "CustomerCanWatch": true }, { "Name": "ANDTV HD", "number": "02", "Id": 57, "Desc": "&TV is the flagship Hindi GEC amongst the �&� bouquet of channels. Staying true to the personification of the Ampersand, &TV signifies a conjunction of aspirations and rootedness which is synonymous with the spirit of New Age India. Through our content offering, we will bring together people and ideologies thus fostering cohesive viewing within Indian households. We will showcase a diverse and dynamic mix of relatable fiction, high voltage non-fiction, marquee events and blockbuster movies. \r\n", "Url": "/Live/ANDTVAPAC/57", "LogoUrl": "http://res.cloudinary.com/idiso/image/upload/h_250/v1425403195/brfr7r7wblj225978df9.png", "ChannelTypeId": null, "EpgItems": [{ "isCatchUp": true, "StartTime": null, "Title": null, "DurationInMinutes": 1440, "IsEmpty": false, "ShowTitle": true, "UnixStartTime": 0, "UnixEndTime": 0, "ProgrammeId": 0, "ProgrammeUrl": null, "ProgrammeDesc": null, "EpisodeNo": null, "Season": null, "Cast": null, "IsPlayingNow": false, "IsCatchUp": true, "EpgItemId": 0, "StartDate": "0001-01-01T00:00:00", "EndDate": "0001-01-01T00:00:00", "ChannelId": 0 }], "CssName": null, "CatchUpUrl": "/CatchUp/ANDTVAPAC/{0}", "CatchUpEnabled": true, "Enabled": false, "OnNow": null, "ComingUp": null, "IsLoading": true, "Category": "Entertainment", "ShortName": "ANDTVAPAC", "Language": "Hindi", "MetaDescription": "Products Description", "MetaKeywords": "Products, Stuff, Monies", "PageTitle": "ANDTV HD", "CustomerCanWatch": true }, { "Name": "Living Foodz", "number": "03", "Id": 45, "Desc": "Living Foodz is an international, premium food & lifestyle channel for the new age viewer. Now relish food, entertainment, lifestyle, adventure and a whole lot of fun all at once on Living Foodz.", "Url": "/Live/ZEEKKAPAC/45", "LogoUrl": "http://res.cloudinary.com/idiso/image/upload/h_250/v1441985758/ziu16jotuguconptg4zr.png", "ChannelTypeId": null, "EpgItems": [{ "isCatchUp": true, "StartTime": null, "Title": null, "DurationInMinutes": 1440, "IsEmpty": false, "ShowTitle": true, "UnixStartTime": 0, "UnixEndTime": 0, "ProgrammeId": 0, "ProgrammeUrl": null, "ProgrammeDesc": null, "EpisodeNo": null, "Season": null, "Cast": null, "IsPlayingNow": false, "IsCatchUp": true, "EpgItemId": 0, "StartDate": "0001-01-01T00:00:00", "EndDate": "0001-01-01T00:00:00", "ChannelId": 0 }], "CssName": null, "CatchUpUrl": "/CatchUp/ZEEKKAPAC/{0}", "CatchUpEnabled": false, "Enabled": false, "OnNow": null, "ComingUp": null, "IsLoading": true, "Category": "Family", "ShortName": "ZEEKKAPAC", "Language": "Hindi", "MetaDescription": "Products Description", "MetaKeywords": "Products, Stuff, Monies", "PageTitle": "Living Foodz", "CustomerCanWatch": true }, { "Name": "ZEE Cinema HD", "number": "03", "Id": 77, "Desc": "India�s first Bollywood movie channel, ZEE Cinema has more than 5,000 hours of movies, making it one of the largest libraries of Indian movie titles. Watch movies of all genres, from recent blockbuster hits to evergreen classics, 24-hours a day!", "Url": "/Live/ZEECININD/77", "LogoUrl": "http://res.cloudinary.com/idiso/image/upload/h_250/v1429630434/a09wfnlodfus0thfzrjn.png", "ChannelTypeId": null, "EpgItems": [{ "isCatchUp": true, "StartTime": null, "Title": null, "DurationInMinutes": 1440, "IsEmpty": false, "ShowTitle": true, "UnixStartTime": 0, "UnixEndTime": 0, "ProgrammeId": 0, "ProgrammeUrl": null, "ProgrammeDesc": null, "EpisodeNo": null, "Season": null, "Cast": null, "IsPlayingNow": false, "IsCatchUp": true, "EpgItemId": 0, "StartDate": "0001-01-01T00:00:00", "EndDate": "0001-01-01T00:00:00", "ChannelId": 0 }], "CssName": null, "CatchUpUrl": "/CatchUp/ZEECININD/{0}", "CatchUpEnabled": true, "Enabled": false, "OnNow": null, "ComingUp": null, "IsLoading": true, "Category": "Movies", "ShortName": "ZEECININD", "Language": "Hindi", "MetaDescription": "Products Description", "MetaKeywords": "Products, Stuff, Monies", "PageTitle": "ZEE Cinema HD", "CustomerCanWatch": true }, { "Name": "ZEE News", "number": "04", "Id": 18, "Desc": "Get the latest headlines and breaking news from India and around the globe with ZEE News. With local, regional and international coverage of politics, business, sports and entertainment, ZEE News will help you stay informed.", "Url": "/Live/ZEEN/18", "LogoUrl": "http://res.cloudinary.com/idiso/image/upload/h_250/v1411274620/ev84roo9ucfuv5tbj3ms.png", "ChannelTypeId": null, "EpgItems": [{ "isCatchUp": true, "StartTime": null, "Title": null, "DurationInMinutes": 1440, "IsEmpty": false, "ShowTitle": true, "UnixStartTime": 0, "UnixEndTime": 0, "ProgrammeId": 0, "ProgrammeUrl": null, "ProgrammeDesc": null, "EpisodeNo": null, "Season": null, "Cast": null, "IsPlayingNow": false, "IsCatchUp": true, "EpgItemId": 0, "StartDate": "0001-01-01T00:00:00", "EndDate": "0001-01-01T00:00:00", "ChannelId": 0 }], "CssName": null, "CatchUpUrl": "/CatchUp/ZEEN/{0}", "CatchUpEnabled": false, "Enabled": false, "OnNow": null, "ComingUp": null, "IsLoading": true, "Category": "News", "ShortName": "ZEEN", "Language": "Hindi", "MetaDescription": "Products Description", "MetaKeywords": "Products, Stuff, Monies", "PageTitle": "ZEE News", "CustomerCanWatch": true }, { "Name": "Z Living", "number": "05", "Id": 35, "Desc": "Nirvana has a new channel! With over 50 series on healthy cooking, fitness, yoga and travel, getting wellness is now as easy as turning on the TV. Let Z Living take you to your happy place.\r\n", "Url": "/Live/ZLIVUS/35", "LogoUrl": "http://res.cloudinary.com/idiso/image/upload/h_250/v1414188089/rnz115plgr35fjtyyfpw.png", "ChannelTypeId": null, "EpgItems": [{ "isCatchUp": true, "StartTime": null, "Title": null, "DurationInMinutes": 1440, "IsEmpty": false, "ShowTitle": true, "UnixStartTime": 0, "UnixEndTime": 0, "ProgrammeId": 0, "ProgrammeUrl": null, "ProgrammeDesc": null, "EpisodeNo": null, "Season": null, "Cast": null, "IsPlayingNow": false, "IsCatchUp": true, "EpgItemId": 0, "StartDate": "0001-01-01T00:00:00", "EndDate": "0001-01-01T00:00:00", "ChannelId": 0 }], "CssName": null, "CatchUpUrl": "/CatchUp/ZLIVUS/{0}", "CatchUpEnabled": true, "Enabled": false, "OnNow": null, "ComingUp": null, "IsLoading": true, "Category": "Entertainment", "ShortName": "ZLIVUS", "Language": "English", "MetaDescription": "Products Description", "MetaKeywords": "Products, Stuff, Monies", "PageTitle": "Z Living", "CustomerCanWatch": true }, { "Name": "ZEE Marathi India", "number": "06", "Id": 49, "Desc": "ZEE Marathi is an entertainment channel that features dramas, non-fiction shows, reality shows, news bulletins, devotional programs, movies and music-based shows. ", "Url": "/Live/ZMARINDA/49", "LogoUrl": "http://res.cloudinary.com/idiso/image/upload/h_250/v1422033997/bnew2kl8uh4chei6pm9b.png", "ChannelTypeId": null, "EpgItems": [{ "isCatchUp": true, "StartTime": null, "Title": null, "DurationInMinutes": 1440, "IsEmpty": false, "ShowTitle": true, "UnixStartTime": 0, "UnixEndTime": 0, "ProgrammeId": 0, "ProgrammeUrl": null, "ProgrammeDesc": null, "EpisodeNo": null, "Season": null, "Cast": null, "IsPlayingNow": false, "IsCatchUp": true, "EpgItemId": 0, "StartDate": "0001-01-01T00:00:00", "EndDate": "0001-01-01T00:00:00", "ChannelId": 0 }], "CssName": null, "CatchUpUrl": "/CatchUp/ZMARINDA/{0}", "CatchUpEnabled": true, "Enabled": false, "OnNow": null, "ComingUp": null, "IsLoading": true, "Category": "Family", "ShortName": "ZMARINDA", "Language": "Marathi", "MetaDescription": "Products Description", "MetaKeywords": "Products, Stuff, Monies", "PageTitle": "ZEE Marathi India", "CustomerCanWatch": true }, { "Name": "ZEE Bangla", "number": "07", "Id": 38, "Desc": "ZEE Bangla is an entertainment channel that features dramas, non-fiction shows, reality shows, news bulletins, devotional programs, movies and music based shows. ", "Url": "/Live/ZEEBAAPAC/38", "LogoUrl": "http://res.cloudinary.com/idiso/image/upload/h_250/v1422033186/yqzaic50wozz0ahw4umu.png", "ChannelTypeId": null, "EpgItems": [{ "isCatchUp": true, "StartTime": null, "Title": null, "DurationInMinutes": 1440, "IsEmpty": false, "ShowTitle": true, "UnixStartTime": 0, "UnixEndTime": 0, "ProgrammeId": 0, "ProgrammeUrl": null, "ProgrammeDesc": null, "EpisodeNo": null, "Season": null, "Cast": null, "IsPlayingNow": false, "IsCatchUp": true, "EpgItemId": 0, "StartDate": "0001-01-01T00:00:00", "EndDate": "0001-01-01T00:00:00", "ChannelId": 0 }], "CssName": null, "CatchUpUrl": "/CatchUp/ZEEBAAPAC/{0}", "CatchUpEnabled": true, "Enabled": false, "OnNow": null, "ComingUp": null, "IsLoading": true, "Category": "Family", "ShortName": "ZEEBAAPAC", "Language": "Bangla", "MetaDescription": "Products Description", "MetaKeywords": "Products, Stuff, Monies", "PageTitle": "ZEE Bangla", "CustomerCanWatch": true }, { "Name": "ZEE Salaam", "number": "08", "Id": 55, "Desc": "ZEE Salaam is an Urdu language religious and spiritual channel. It aims to entertain the viewers with mythological movies, serials, religious discourses and spiritual programs. Audiences will learn about alternative and holistic approaches to health and wellness in addition to spiritual wellbeing. ", "Url": "/Live/ZEESALAPAC/55", "LogoUrl": "http://res.cloudinary.com/idiso/image/upload/h_250/v1422032950/r6zd651v3wvf6zauzt0f.png", "ChannelTypeId": null, "EpgItems": [{ "isCatchUp": true, "StartTime": null, "Title": null, "DurationInMinutes": 1440, "IsEmpty": false, "ShowTitle": true, "UnixStartTime": 0, "UnixEndTime": 0, "ProgrammeId": 0, "ProgrammeUrl": null, "ProgrammeDesc": null, "EpisodeNo": null, "Season": null, "Cast": null, "IsPlayingNow": false, "IsCatchUp": true, "EpgItemId": 0, "StartDate": "0001-01-01T00:00:00", "EndDate": "0001-01-01T00:00:00", "ChannelId": 0 }], "CssName": null, "CatchUpUrl": "/CatchUp/ZEESALAPAC/{0}", "CatchUpEnabled": true, "Enabled": false, "OnNow": null, "ComingUp": null, "IsLoading": true, "Category": "Family", "ShortName": "ZEESALAPAC", "Language": "Urdu", "MetaDescription": "Products Description", "MetaKeywords": "Products, Stuff, Monies", "PageTitle": "ZEE Salaam", "CustomerCanWatch": true }, { "Name": "ZEE Business", "number": "09", "Id": 39, "Desc": "ZEE Business is a 24-hour news and infotainment channel that keeps viewers updated on happenings in the business world, from the stock market to investment trends to real estate and tech news!", "Url": "/Live/ZEEBUSAPAC/39", "LogoUrl": "http://res.cloudinary.com/idiso/image/upload/h_250/v1422033286/hn9lyexfcxv7hai5nojm.png", "ChannelTypeId": null, "EpgItems": [{ "isCatchUp": true, "StartTime": null, "Title": null, "DurationInMinutes": 1440, "IsEmpty": false, "ShowTitle": true, "UnixStartTime": 0, "UnixEndTime": 0, "ProgrammeId": 0, "ProgrammeUrl": null, "ProgrammeDesc": null, "EpisodeNo": null, "Season": null, "Cast": null, "IsPlayingNow": false, "IsCatchUp": true, "EpgItemId": 0, "StartDate": "0001-01-01T00:00:00", "EndDate": "0001-01-01T00:00:00", "ChannelId": 0 }], "CssName": null, "CatchUpUrl": "/CatchUp/ZEEBUSAPAC/{0}", "CatchUpEnabled": true, "Enabled": false, "OnNow": null, "ComingUp": null, "IsLoading": true, "Category": "News", "ShortName": "ZEEBUSAPAC", "Language": "English", "MetaDescription": "Products Description", "MetaKeywords": "Products, Stuff, Monies", "PageTitle": "ZEE Business", "CustomerCanWatch": true }, { "Name": "ZEE Punjabi", "number": "11", "Id": 44, "Desc": "ZEE Punjabi is a channel that offers a variety of programs such as dramas, talk shows, game shows, comedies, cooking shows, and films. With this family entertainment channel, viewers will enjoy top-rated Punjabi programming all day long!", "Url": "/Live/ZEEPUNAPAC/44", "LogoUrl": "http://res.cloudinary.com/idiso/image/upload/h_250/v1422033564/nzdub4zif1fjirlft6fu.png", "ChannelTypeId": null, "EpgItems": [{ "isCatchUp": true, "StartTime": null, "Title": null, "DurationInMinutes": 1440, "IsEmpty": false, "ShowTitle": true, "UnixStartTime": 0, "UnixEndTime": 0, "ProgrammeId": 0, "ProgrammeUrl": null, "ProgrammeDesc": null, "EpisodeNo": null, "Season": null, "Cast": null, "IsPlayingNow": false, "IsCatchUp": true, "EpgItemId": 0, "StartDate": "0001-01-01T00:00:00", "EndDate": "0001-01-01T00:00:00", "ChannelId": 0 }], "CssName": null, "CatchUpUrl": "/CatchUp/ZEEPUNAPAC/{0}", "CatchUpEnabled": true, "Enabled": false, "OnNow": null, "ComingUp": null, "IsLoading": true, "Category": "Family", "ShortName": "ZEEPUNAPAC", "Language": "Punjabi", "MetaDescription": "Products Description", "MetaKeywords": "Products, Stuff, Monies", "PageTitle": "ZEE Punjabi", "CustomerCanWatch": true }, { "Name": "ZEE Talkies", "number": "11", "Id": 40, "Desc": "ZEE Talkies is a Marathi language movie channel. Tune in for your favorite action, comedy, romantic and classic movies from the entire repertoire of Marathi Cinema, 24-hours a day!", "Url": "/Live/ZEETALAPAC/40", "LogoUrl": "http://res.cloudinary.com/idiso/image/upload/h_250/v1422033374/vxfggc2wlv5fbcxrfiqr.png", "ChannelTypeId": null, "EpgItems": [{ "isCatchUp": true, "StartTime": null, "Title": null, "DurationInMinutes": 1440, "IsEmpty": false, "ShowTitle": true, "UnixStartTime": 0, "UnixEndTime": 0, "ProgrammeId": 0, "ProgrammeUrl": null, "ProgrammeDesc": null, "EpisodeNo": null, "Season": null, "Cast": null, "IsPlayingNow": false, "IsCatchUp": true, "EpgItemId": 0, "StartDate": "0001-01-01T00:00:00", "EndDate": "0001-01-01T00:00:00", "ChannelId": 0 }], "CssName": null, "CatchUpUrl": "/CatchUp/ZEETALAPAC/{0}", "CatchUpEnabled": true, "Enabled": false, "OnNow": null, "ComingUp": null, "IsLoading": true, "Category": "Family", "ShortName": "ZEETALAPAC", "Language": "Marathi", "MetaDescription": "Products Description", "MetaKeywords": "Products, Stuff, Monies", "PageTitle": "ZEE Talkies", "CustomerCanWatch": true }, { "Name": "24 Taas", "number": "12", "Id": 13, "Desc": "The first and leading 24-hour Marathi news channel of its kind, 24 Taas dedicated to local, regional and national news coverage. It also offers sports programming and entertainment news, all in Marathi!", "Url": "/Live/24TA/13", "LogoUrl": "http://res.cloudinary.com/idiso/image/upload/h_250/v1411274824/jg6m4f2ys0ibfnhahxor.png", "ChannelTypeId": null, "EpgItems": [{ "isCatchUp": true, "StartTime": null, "Title": null, "DurationInMinutes": 1440, "IsEmpty": false, "ShowTitle": true, "UnixStartTime": 0, "UnixEndTime": 0, "ProgrammeId": 0, "ProgrammeUrl": null, "ProgrammeDesc": null, "EpisodeNo": null, "Season": null, "Cast": null, "IsPlayingNow": false, "IsCatchUp": true, "EpgItemId": 0, "StartDate": "0001-01-01T00:00:00", "EndDate": "0001-01-01T00:00:00", "ChannelId": 0 }], "CssName": null, "CatchUpUrl": "/CatchUp/24TA/{0}", "CatchUpEnabled": false, "Enabled": false, "OnNow": null, "ComingUp": null, "IsLoading": true, "Category": "News", "ShortName": "24TA", "Language": "Marathi", "MetaDescription": "Products Description", "MetaKeywords": "Products, Stuff, Monies", "PageTitle": "24 Taas", "CustomerCanWatch": true }, { "Name": "ZEE Bangla Cinema", "number": "14", "Id": 41, "Desc": "ZEE Bangla Cinema is a Bangla language movie channel. Tune in for your favorite action, comedy, romantic and classic movies from the entire repertoire of Bengali Cinema, 24-hours a day!", "Url": "/Live/ZEEBCAPAC/41", "LogoUrl": "http://res.cloudinary.com/idiso/image/upload/h_250/v1422033435/z0jrff5jlcktgu4qfx7v.png", "ChannelTypeId": null, "EpgItems": [{ "isCatchUp": true, "StartTime": null, "Title": null, "DurationInMinutes": 1440, "IsEmpty": false, "ShowTitle": true, "UnixStartTime": 0, "UnixEndTime": 0, "ProgrammeId": 0, "ProgrammeUrl": null, "ProgrammeDesc": null, "EpisodeNo": null, "Season": null, "Cast": null, "IsPlayingNow": false, "IsCatchUp": true, "EpgItemId": 0, "StartDate": "0001-01-01T00:00:00", "EndDate": "0001-01-01T00:00:00", "ChannelId": 0 }], "CssName": null, "CatchUpUrl": "/CatchUp/ZEEBCAPAC/{0}", "CatchUpEnabled": true, "Enabled": false, "OnNow": null, "ComingUp": null, "IsLoading": true, "Category": "Family", "ShortName": "ZEEBCAPAC", "Language": "Bangla", "MetaDescription": "Products Description", "MetaKeywords": "Products, Stuff, Monies", "PageTitle": "ZEE Bangla Cinema", "CustomerCanWatch": true }, { "Name": "24 Ghanta", "number": "15", "Id": 14, "Desc": "The first and leading 24-hour Bengali news channel of its kind, 24 Ghanta is dedicated to local, regional and national news coverage. It also offers sports programming and entertainment news, all in Bengali!", "Url": "/Live/24G/14", "LogoUrl": "http://res.cloudinary.com/idiso/image/upload/h_250/v1411274881/aioxxbysulmx1fdcn493.png", "ChannelTypeId": null, "EpgItems": [{ "isCatchUp": true, "StartTime": null, "Title": null, "DurationInMinutes": 1440, "IsEmpty": false, "ShowTitle": true, "UnixStartTime": 0, "UnixEndTime": 0, "ProgrammeId": 0, "ProgrammeUrl": null, "ProgrammeDesc": null, "EpisodeNo": null, "Season": null, "Cast": null, "IsPlayingNow": false, "IsCatchUp": true, "EpgItemId": 0, "StartDate": "0001-01-01T00:00:00", "EndDate": "0001-01-01T00:00:00", "ChannelId": 0 }], "CssName": null, "CatchUpUrl": "/CatchUp/24G/{0}", "CatchUpEnabled": false, "Enabled": false, "OnNow": null, "ComingUp": null, "IsLoading": true, "Category": "Regional", "ShortName": "24G", "Language": "Bangla", "MetaDescription": "Products Description", "MetaKeywords": "Products, Stuff, Monies", "PageTitle": "24 Ghanta", "CustomerCanWatch": true }, { "Name": "Alpha ETC Punjabi", "number": "20", "Id": 26, "Desc": "Alpha ETC Punjabi offers a full range of programming including Live cultural and religious discourses, top-rated drama series, news, music and much more!", "Url": "/Live/AETCPUS/26", "LogoUrl": "http://res.cloudinary.com/idiso/image/upload/h_250/v1411274989/vsahtmg4ktx8beuhj6jm.png", "ChannelTypeId": null, "EpgItems": [{ "isCatchUp": true, "StartTime": null, "Title": null, "DurationInMinutes": 1440, "IsEmpty": false, "ShowTitle": true, "UnixStartTime": 0, "UnixEndTime": 0, "ProgrammeId": 0, "ProgrammeUrl": null, "ProgrammeDesc": null, "EpisodeNo": null, "Season": null, "Cast": null, "IsPlayingNow": false, "IsCatchUp": true, "EpgItemId": 0, "StartDate": "0001-01-01T00:00:00", "EndDate": "0001-01-01T00:00:00", "ChannelId": 0 }], "CssName": null, "CatchUpUrl": "/CatchUp/AETCPUS/{0}", "CatchUpEnabled": true, "Enabled": false, "OnNow": null, "ComingUp": null, "IsLoading": true, "Category": "Family", "ShortName": "AETCPUS", "Language": "Punjabi", "MetaDescription": "Products Description", "MetaKeywords": "Products, Stuff, Monies", "PageTitle": "Alpha ETC Punjabi", "CustomerCanWatch": true }, { "Name": "ZEE Classic", "number": "24", "Id": 46, "Desc": "ZEE Classic is dedicated to Hindi cinema from 1940 to 1970. Enjoy hundreds of classic films from the era that shaped Indian cinema, starring timeless actors, including Raj Kapoor, Dev Anand, Dilip Kumar, Nargis, Vyjayanthimala, and many more!", "Url": "/Live/ZEECAPAC/46", "LogoUrl": "http://res.cloudinary.com/idiso/image/upload/h_250/v1422033877/bnikq20udkhsdcjndawn.png", "ChannelTypeId": null, "EpgItems": [{ "isCatchUp": true, "StartTime": null, "Title": null, "DurationInMinutes": 1440, "IsEmpty": false, "ShowTitle": true, "UnixStartTime": 0, "UnixEndTime": 0, "ProgrammeId": 0, "ProgrammeUrl": null, "ProgrammeDesc": null, "EpisodeNo": null, "Season": null, "Cast": null, "IsPlayingNow": false, "IsCatchUp": true, "EpgItemId": 0, "StartDate": "0001-01-01T00:00:00", "EndDate": "0001-01-01T00:00:00", "ChannelId": 0 }], "CssName": null, "CatchUpUrl": "/CatchUp/ZEECAPAC/{0}", "CatchUpEnabled": true, "Enabled": false, "OnNow": null, "ComingUp": null, "IsLoading": true, "Category": "Family", "ShortName": "ZEECAPAC", "Language": "Hindi", "MetaDescription": "Products Description", "MetaKeywords": "Products, Stuff, Monies", "PageTitle": "ZEE Classic", "CustomerCanWatch": true }, { "Name": "ZEE Marudhara", "number": "26", "Id": 28, "Desc": "ZEE Marudhara is a Rajasthani entertainment channel that features dramas, Bollywood gossip, news bulletins, movies and music based programming. ", "Url": "/Live/ZEEMARUDH/28", "LogoUrl": "http://res.cloudinary.com/idiso/image/upload/h_250/v1411275092/kkfthn5oty9ityrq3ba7.png", "ChannelTypeId": null, "EpgItems": [{ "isCatchUp": true, "StartTime": null, "Title": null, "DurationInMinutes": 1440, "IsEmpty": false, "ShowTitle": true, "UnixStartTime": 0, "UnixEndTime": 0, "ProgrammeId": 0, "ProgrammeUrl": null, "ProgrammeDesc": null, "EpisodeNo": null, "Season": null, "Cast": null, "IsPlayingNow": false, "IsCatchUp": true, "EpgItemId": 0, "StartDate": "0001-01-01T00:00:00", "EndDate": "0001-01-01T00:00:00", "ChannelId": 0 }], "CssName": null, "CatchUpUrl": "/CatchUp/ZEEMARUDH/{0}", "CatchUpEnabled": false, "Enabled": false, "OnNow": null, "ComingUp": null, "IsLoading": true, "Category": "News", "ShortName": "ZEEMARUDH", "Language": "Hindi", "MetaDescription": "Products Description", "MetaKeywords": "Products, Stuff, Monies", "PageTitle": "ZEE Marudhara", "CustomerCanWatch": true }, { "Name": "ZEE Kalinga", "number": "27", "Id": 29, "Desc": "ZEE Kalinga is one of the first 24-hour Oriya language channels. It features dramas, talk shows, news bulletins, and music based programming.  ", "Url": "/Live/ZEEKALING/29", "LogoUrl": "http://res.cloudinary.com/idiso/image/upload/h_250/v1411275219/debvsbahf6fqzi3g0bni.png", "ChannelTypeId": null, "EpgItems": [{ "isCatchUp": true, "StartTime": null, "Title": null, "DurationInMinutes": 1440, "IsEmpty": false, "ShowTitle": true, "UnixStartTime": 0, "UnixEndTime": 0, "ProgrammeId": 0, "ProgrammeUrl": null, "ProgrammeDesc": null, "EpisodeNo": null, "Season": null, "Cast": null, "IsPlayingNow": false, "IsCatchUp": true, "EpgItemId": 0, "StartDate": "0001-01-01T00:00:00", "EndDate": "0001-01-01T00:00:00", "ChannelId": 0 }], "CssName": null, "CatchUpUrl": "/CatchUp/ZEEKALING/{0}", "CatchUpEnabled": false, "Enabled": false, "OnNow": null, "ComingUp": null, "IsLoading": true, "Category": "News", "ShortName": "ZEEKALING", "Language": "Hindi", "MetaDescription": "Products Description", "MetaKeywords": "Products, Stuff, Monies", "PageTitle": "ZEE Kalinga", "CustomerCanWatch": true }, { "Name": "ZEE MP & CH", "number": "28", "Id": 30, "Desc": "ZEE MP & Chhattisgarh is a regional news channel dedicated to local and national news coverage. Viewers will have access to news bulletins, talk shows, and much more!", "Url": "/Live/ZEE MADHYA/30", "LogoUrl": "http://res.cloudinary.com/idiso/image/upload/h_250/v1411275240/cfawvykdtnv67oy7rvlh.png", "ChannelTypeId": null, "EpgItems": [{ "isCatchUp": true, "StartTime": null, "Title": null, "DurationInMinutes": 1440, "IsEmpty": false, "ShowTitle": true, "UnixStartTime": 0, "UnixEndTime": 0, "ProgrammeId": 0, "ProgrammeUrl": null, "ProgrammeDesc": null, "EpisodeNo": null, "Season": null, "Cast": null, "IsPlayingNow": false, "IsCatchUp": true, "EpgItemId": 0, "StartDate": "0001-01-01T00:00:00", "EndDate": "0001-01-01T00:00:00", "ChannelId": 0 }], "CssName": null, "CatchUpUrl": "/CatchUp/ZEE MADHYA/{0}", "CatchUpEnabled": false, "Enabled": false, "OnNow": null, "ComingUp": null, "IsLoading": true, "Category": "News", "ShortName": "ZEE MADHYA", "Language": "Hindi", "MetaDescription": "Products Description", "MetaKeywords": "Products, Stuff, Monies", "PageTitle": "ZEE MP & CH", "CustomerCanWatch": true }, { "Name": "TEN Cricket", "number": "48", "Id": 56, "Desc": "TEN Cricket is a 24-hour sports channel dedicated to all things cricket. Stay up-to-date on cricket news, watch athlete interviews and enjoy matches from all over the world!", "Url": "/Live/TENMEAPAC/56", "LogoUrl": "http://res.cloudinary.com/idiso/image/upload/h_250/v1425313759/wuld9v5uxitenghk1rh0.jpg", "ChannelTypeId": null, "EpgItems": [{ "isCatchUp": true, "StartTime": null, "Title": null, "DurationInMinutes": 1440, "IsEmpty": false, "ShowTitle": true, "UnixStartTime": 0, "UnixEndTime": 0, "ProgrammeId": 0, "ProgrammeUrl": null, "ProgrammeDesc": null, "EpisodeNo": null, "Season": null, "Cast": null, "IsPlayingNow": false, "IsCatchUp": true, "EpgItemId": 0, "StartDate": "0001-01-01T00:00:00", "EndDate": "0001-01-01T00:00:00", "ChannelId": 0 }], "CssName": null, "CatchUpUrl": "/CatchUp/TENMEAPAC/{0}", "CatchUpEnabled": false, "Enabled": false, "OnNow": null, "ComingUp": null, "IsLoading": true, "Category": "Sport", "ShortName": "TENMEAPAC", "Language": "Hindi", "MetaDescription": "Products Description", "MetaKeywords": "Products, Stuff, Monies", "PageTitle": "TEN Cricket", "CustomerCanWatch": true }, { "Name": "ZEE Sangam", "number": "53", "Id": 63, "Desc": "Dedicated to the states of Uttar Pradesh and Uttarakhand, ZEEE Sangam provides regional and national news coverage. With this 24-hour channel, never miss any important updates!", "Url": "/Live/ZEESANGAM/63", "LogoUrl": "http://res.cloudinary.com/idiso/image/upload/h_250/v1425679052/yxlzwpw1frhlh1uxbr9k.png", "ChannelTypeId": null, "EpgItems": [{ "isCatchUp": true, "StartTime": null, "Title": null, "DurationInMinutes": 1440, "IsEmpty": false, "ShowTitle": true, "UnixStartTime": 0, "UnixEndTime": 0, "ProgrammeId": 0, "ProgrammeUrl": null, "ProgrammeDesc": null, "EpisodeNo": null, "Season": null, "Cast": null, "IsPlayingNow": false, "IsCatchUp": true, "EpgItemId": 0, "StartDate": "0001-01-01T00:00:00", "EndDate": "0001-01-01T00:00:00", "ChannelId": 0 }], "CssName": null, "CatchUpUrl": "/CatchUp/ZEESANGAM/{0}", "CatchUpEnabled": false, "Enabled": false, "OnNow": null, "ComingUp": null, "IsLoading": true, "Category": "News", "ShortName": "ZEESANGAM", "Language": "Hindi", "MetaDescription": "Products Description", "MetaKeywords": "Products, Stuff, Monies", "PageTitle": "ZEE Sangam", "CustomerCanWatch": true }, { "Name": "ZEE Purvaiya", "number": "54", "Id": 64, "Desc": "ZEE Purvaiya is the leading 24-hour news channel dedicated to Bihar and Jharkhand. It features everything from politics to sports, the economy to weather. ", "Url": "/Live/ZEEPUR/64", "LogoUrl": "http://res.cloudinary.com/idiso/image/upload/h_250/v1425679070/skatyoktr5s1ypkrlwwp.png", "ChannelTypeId": null, "EpgItems": [{ "isCatchUp": true, "StartTime": null, "Title": null, "DurationInMinutes": 1440, "IsEmpty": false, "ShowTitle": true, "UnixStartTime": 0, "UnixEndTime": 0, "ProgrammeId": 0, "ProgrammeUrl": null, "ProgrammeDesc": null, "EpisodeNo": null, "Season": null, "Cast": null, "IsPlayingNow": false, "IsCatchUp": true, "EpgItemId": 0, "StartDate": "0001-01-01T00:00:00", "EndDate": "0001-01-01T00:00:00", "ChannelId": 0 }], "CssName": null, "CatchUpUrl": "/CatchUp/ZEEPUR/{0}", "CatchUpEnabled": false, "Enabled": false, "OnNow": null, "ComingUp": null, "IsLoading": true, "Category": "News", "ShortName": "ZEEPUR", "Language": "Hindi", "MetaDescription": "Products Description", "MetaKeywords": "Products, Stuff, Monies", "PageTitle": "ZEE Purvaiya", "CustomerCanWatch": true }]);

</script>

<?php } 
else if($page =='home') { ?>
<script src='/js/linqjs.js'></script>
<script src='/js/angular.min.js'></script>

<script src='/js/homepage.js'></script>

<?php } ?>

<?php if($page=='login')  { ?>

<script src='/js/forms-validation/jquery.validate.js'></script>
<script src='/js/forms-validation/jquery.validate.unobtrusive.min.js'></script>
<script src='/js/forms-validation/zee-validation.js'></script>
<script src='/js/zee-register-qtip.js'></script>


<?php } ?>


<?php if($page=='movies')  { ?>
<script>
    window.baseUrl = "/";
</script>

<script src="/js/angular.min.js"></script>
<script src="/js/movielisting.js"></script>



<?php } ?>

<?php if($page=='show')  { ?>
<script>
    window.baseUrl = "/";
</script>
<script src="/js/angular.min.js"></script>
<script src="/js/showlisting.js"></script>


<?php } ?>


<?php if($page =='device') { ?>

<script src="/scripts/moment.min.js"></script>
<script src="/js/smoke.min.js"></script>
<script>
    $(document).ready(function () {
        var dt;
        $(".zee-myaccount-grid-placeholder").find("[data-time]").each(function () {
            dt = new Date($(this).data('time'));
            $(this).html('Added : ' + moment(dt).calendar());
            dt = null;
        });

        $(".remove-device").each(function () {
            $(this).click(function () {
                var that = $(this);
                smoke.confirm("Are you sure?", function (e) {
                    if (e) {

                    } else {

                    }
                }, {
                    ok: "Yep",
                    cancel: "Nope",
                    classname: "custom-class",
                    reverseButtons: true
                });
                /*
                swal({
                    title: "Deauthorize device",
                    text: "you will no longer be able to watch content on this device after deauthorizing.",
                    type: "warning",
                    showCancelButton: true,
                    confirmButtonColor: '#ef102e',
                    confirmButtonText: 'Yes',
                    closeOnConfirm: false,
                    closeOnCancel: false,
                    cancelButtonText: 'No'
                },
                    function (isConfirm) {
                        if (isConfirm) {
                            var token = $('#antiForgeryToken').val();
                            var baseUrl = '/';
                            var deviceId = that.data("device");
                            var deviceName = that.data("devicetype");
                            var divid = that.data("id");

                            var request = {
                                "DeviceKey": deviceId,
                                "DeviceName": deviceName

                            };

                            $.ajax({
                                url: baseUrl + "delinkDevice",
                                type: "POST",
                                dataType: 'json',
                                data: request,
                                headers: { 'RequestVerificationToken': token },
                                success: function () {
                                    $(divid).hide('slow', function () { $(divid).remove(); });
                                    swal("Deauthorized!", "Your device has been deauthorized.", "success");
                                }
                            });

                        } else {
                            swal("Cancelled", "Cancelled:)", "error");
                        }

                        event.preventDefault();
                    });
                */
            });
        });


    });

</script>

<?php  } ?>



<?php if($page =='package') { ?>

<script src="/js/packages.js"></script>

<?php  } ?>

<?php if($page =='packages_new') { ?>

<script src="/js/iscroll.js"></script>
<script src="/js/packages_new.js"></script>

<?php  } ?>




<?php if($page =='checkout') { ?>

<script src='/js/forms-validation/jquery.validate.js'></script>
<script src='/js/forms-validation/jquery.validate.unobtrusive.min.js'></script>
<script src='/js/forms-validation/zee-validation.js'></script>

<script src='/js/braintree.js'></script>
<script src='/js/checkout.js'></script>
<script src='/js/zee-register-qtip.js'></script>

<?php  } ?>

</body>
</html>
