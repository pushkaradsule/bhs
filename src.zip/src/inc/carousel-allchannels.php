<div class="zee-carousel-allchannels">

    <?php for ($i = 0; $i <= 14; $i++) { ?>
    <div class="item">

        <div class="carousel-helper-wrapper">
            <a href="/WatchMovie/is-raat-ki-subah-nahi/373" class="carousel-thumb-action"></a>
            <span class="carousel-helper carousel-helper-play">
                <a href="/WatchMovie/is-raat-ki-subah-nahi/373"><i class="icon icon-play-1"></i></a>
            </span>
        </div>
        <img class="carousel-thumbnail carousel-allchannel-thumb" src="http://res.cloudinary.com/idiso/image/upload/h_250/v1425403195/brfr7r7wblj225978df9.png">
        <label class="carousel-allchannels-label">Zee Family HD</label>
    </div>
    <?php } ?>
</div>
