<ul class="zee-myaccount-tabs">
    <li class="zee-myaccount-profile<?php echo ($active_menu == 'profile' ? ' active-tab' : ''); ?>"><a href="/MyAccount.php"><span class="icon icon-user-1"></span><span class="text">Profile</span></a></li>
    <li class="zee-myaccount-devices<?php echo ($active_menu == 'devices' ? ' active-tab' : ''); ?>"><a href="/mydevices.php"><span class="icon icon-mobile-1"></span><span class="text">Devices</span></a></li>
    <li class="zee-myaccount-linktv<?php echo ($active_menu == 'linktv' ? ' active-tab' : ''); ?>"><a href="#"><span class="icon icon-link-2"></span><span class="text">Link Your TV</span></a></li>
    <li class="zee-myaccount-billing<?php echo ($active_menu == 'billing' ? ' active-tab' : ''); ?>"><a href="/billing.php"><span class="icon icon-credit-card"></span><span class="text">Billing</span></a></li>
    <li class="zee-myaccount-changepass<?php echo ($active_menu == 'changepass' ? ' active-tab' : ''); ?>"><a href="/changePassword.php"><span class="icon icon-keyboard"></span><span class="text">Change Password</span></a></li>
    <li class="zee-myaccount-managesubs<?php echo ($active_menu == 'manage' ? ' active-tab' : ''); ?>"><a href="/manage-subscription.php"><span class="icon icon-box"></span><span class="text">Manage Subscription</span></a></li>
    <li class="zee-myaccount-cancelsubs<?php echo ($active_menu == 'cancelsubs' ? ' active-tab' : ''); ?>"><a href="/can-sub.php"><span class="icon icon-off-1"></span><span class="text">Cancel Subscription</span></a></li>
</ul>
