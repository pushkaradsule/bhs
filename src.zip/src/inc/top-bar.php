<!-- mobile search form -->
<div class="zee-mobile-search-form">
    <form action="/search-mobile" autocomplete="off" class="form-inline" id="search-form-mobile" method="post">
        <div class="form-group">
            <div class="input-group">
                <input type="search" id="mobileSearch" name="mobileSearch" placeholder="Search">
                <button type="submit">
                    <i class="icon icon-magnifyingglass29"></i>
                </button>
            </div>
        </div>
    </form>
    <a href="#" id="zee_mobile_search_close" class="icon icon-cancel-3"></a>
</div>

<!-- toolbar -->
<div class="zee-toolbar" data-compact="<?php echo (isset($compact_topbar) ? '0' : '1') ?>">
    <div class="container">
        <div class="row zee-toolbar-inner">
            <ul class="zee-toolbar-utils-left">
                <li class="zee-toolbar-logo visible-md-inline-block visible-lg-inline-block">
                    <a href="/en-IN">
                        <img src="/images/zee-family-logo.png">
                    </a>
                </li>
                <li class="zee-toolbar-menu visible-md-inline-block visible-lg-inline-block">

                    <a href="javascript:void(0)" id="zee_toolbar_menu">
                        <span class="icon icon-menu-1"></span>
                        <span class="texts">Menu</span>
                        <span class="icon icon-down-open"></span>
                    </a>
                    <ul class="dropdown-menu">
                        <li class="menu-items-col">
                            <ul>
                                <li>
                                    <a class="menu-item" href="/index.php">
                                        <i class="link-icon icon icon-home166"></i>
                                        <span>Home</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="/epg-guide.php" class="link-live-tv menu-item">
                                        <i class="link-icon icon icon-tvscreen32"></i>
                                        <span>Live TV & Catch-Up</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="/Movies.php" class="link-movies menu-item">
                                        <i class="link-icon icon icon-cinema130"></i>
                                        <span>Movies</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="/Shows.php" class="link-classic-shows menu-item">
                                        <i class="link-icon icon icon-tragedy3"></i>
                                        <span>Shows</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="/packages_new.php" class="link-package menu-item">
                                        <i class="link-icon icon icon-boxes30"></i>
                                        <span>Packages</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="/MyAccount.php" class="link-my-account menu-item">
                                        <i class="link-icon icon icon-padlock118"></i>
                                        <span>My Account</span>
                                    </a>
                                </li>
                            </ul>
                        </li>
                        <li class="banner">
                            <div class="mega-menu-epg">
                                <ul class="mega-epg-cycle">
                                    <li class="mega-menu-epg-program-details">
                                        <img src="http://res.cloudinary.com/idiso/image/upload/h_250/v1414188089/rnz115plgr35fjtyyfpw.png" alt="Channel Name" />
                                        <a href="#"><span>ON NOW <i class="icon icon-play-circled"></i></span></a>
                                        <p>Ek Tha Raja Ek Thi Rani</p>
                                        <time>9:00 AM - 9:30 AM</time>
                                        <div class="loading" style="display: none">
                                            <div class="loading-bar"></div>
                                            <div class="loading-bar"></div>
                                            <div class="loading-bar"></div>
                                            <div class="loading-bar"></div>
                                            <div class="loading-bar"></div>
                                        </div>
                                    </li>
                                    <li class="mega-menu-epg-program-details">
                                        <img src="http://res.cloudinary.com/idiso/image/upload/h_250/v1441985758/ziu16jotuguconptg4zr.png" alt="Channel Name" />
                                        <a href="#"><span>ON NOW <i class="icon icon-play-circled"></i></span></a>
                                        <p>Special Program</p>
                                        <time>9:05 AM - 9:20 AM</time>
                                    </li>
                                    <li class="mega-menu-epg-program-details">
                                        <img src="http://res.cloudinary.com/idiso/image/upload/h_250/v1425403195/brfr7r7wblj225978df9.png" alt="Channel Name" />
                                        <a href="#"><span>ON NOW <i class="icon icon-play-circled"></i></span></a>
                                        <p>Dilli Wali Thakur Gurls</p>
                                        <time>9:00 AM - 9:30 AM</time>
                                    </li>
                                    <li class="mega-menu-epg-program-details">
                                        <img src="http://res.cloudinary.com/idiso/image/upload/h_250/v1425679052/yxlzwpw1frhlh1uxbr9k.png" alt="Channel Name" />
                                        <a href="#"><span>ON NOW <i class="icon icon-play-circled"></i></span></a>
                                        <p>Special Program</p>
                                        <time>9:00 AM - 6:00 PM</time>
                                    </li>
                                    <li class="mega-menu-epg-program-details">
                                        <img src="http://res.cloudinary.com/idiso/image/upload/h_250/v1422033997/bnew2kl8uh4chei6pm9b.png" alt="Channel Name" />
                                        <a href="#"><span>ON NOW <i class="icon icon-play-circled"></i></span></a>
                                        <p>Honar Sun Mi Hya Gharchi</p>
                                        <time>9:00 AM - 9:30 AM</time>
                                    </li>
                                </ul>
                            </div>
                        </li>
                    </ul>
                </li>
                <li class="zee-toolbar-mobile-menu visible-sm-inline-block visible-xs-inline-block">
                    <a href="#" id="zee_mobile_menu_trigger">
                        <div class="icon icon-menu-1"></div>
                    </a>
                </li>
            </ul>
            <div class="zee-toolbar-mobile-logo visible-sm-inline-block visible-xs-inline-block">
                <a href="/en-IN">
                    <img src="/images/zee-family-logo.png">
                </a>
            </div>
            <div class="zee-toolbar-search visible-md-inline-block visible-lg-inline-block">

                <form action="/search-all" autocomplete="off" class="form-inline" id="search-form" method="post" style="height: 36px;">
                    <div class="form-group" style="margin: 0">
                        <div class="input-group">
                            <input type="text" id="zeeSearch" name="zeeSearch" placeholder="Search">
                            <button type="submit"><i class="icon icon-magnifyingglass29"></i></button>
                        </div>
                    </div>
                </form>
            </div>
            <?php if($login == '1'){ ?>
            <ul class="zee-toolbar-utils-right zee-toolbar-post-login visible-md-inline-block visible-lg-inline-block">
                <li class="zee-toolbar-user">
                    <a href="javascript:void(0)" id="zee_user_menu">
                        <span class="icon icon-user43"></span>
                        <span class="text">Pushkar</span>
                        <span class="icon icon-down-open"></span>
                    </a>
                    <ul class="dropdown-user-menu">
                        <li><a href="/MyAccount" class="withripple">My Account</a></li>
                        <li><a href="/ChangePassword" class="withripple">Change Password</a></li>
                        <li><a href="/SignOut" class="withripple">Logout</a></li>
                    </ul>
                </li>
            </ul>
            <ul class="zee-toolbar-utils-right zee-toolbar-post-login visible-sm-inline-block visible-xs-inline-block">
                <li class="zee-toolbar-mobile-search">
                    <a href="#" id="search_mobile_btn">
                        <div class="icon icon-tool192"></div>
                    </a>
                </li>
                <li class="zee-toolbar-mobile-signup">
                    <a href="#" id="zee_mobile_signiup_btn">
                        <div class="icon icon-user43"></div>
                    </a>
                </li>
            </ul>

            <?php } else { ?>
            <ul class="zee-toolbar-utils-right visible-md-inline-block visible-lg-inline-block">
                <li class="zee-toolbar-login">
                    <a href="/Login" class="withripple">
                        <span class="text">Log In</span>
                        <span class="hover-icon">
                            <i class="icon icon-ok-1"></i>
                        </span>
                    </a>
                </li>
                <li class="zee-toolbar-signup visible-md-inline-block visible-lg-inline-block">
                    <a href="/Register" class="withripple">Register</a>
                </li>
            </ul>

            <ul class="zee-toolbar-utils-right visible-sm-inline-block visible-xs-inline-block">
                <li class="zee-toolbar-mobile-search">
                    <a href="#" id="search_mobile_btn">
                        <div class="icon icon-tool192"></div>
                    </a>
                </li>
                <li class="zee-toolbar-mobile-signup">
                    <a href="#" id="zee_mobile_signiup_btn">
                        <div class="icon icon-user43"></div>
                    </a>
                </li>
            </ul>
            <?php } ?>
        </div>
    </div>
</div>
<script>
    window.baseUrl = "/";
</script>
