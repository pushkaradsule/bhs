<!-- user menu mobile overlay -->
<div class="zee-blur-overlay">
    <div class="zee-mobile-signup-buttons">
        <ul class="zee-mobile-logged-in">
            <?php if($login == '1'){ ?><li><a href="/MyAccount">my Account</a></li><?php }else{ ?><li><a href="/MyAccount">Register</a></li><?php } ?>
            <?php if($login == '1'){ ?><li><li><a href="/ChangePassword">Change Password</a></li><?php }else{ ?><li><a href="/MyAccount">Log in</a></li><?php } ?>
            <?php if($login == '1'){ ?><li><a href="/SignOut" class="log-out-btn">Logout</a></li><?php } ?>
            <li>
                <a href="#" class="signup-close-btn" id="signup_close_btn">
                    <i class="zee close-small"></i>Close
                </a>
            </li>
        </ul>
    </div>
</div>

<!-- mobile menu -->
<div class="zee-mobile-menu">
    <a href="#" id="zee_mobile_menu_close">
        <i class="icon icon-cancel-3"></i>
    </a>
    <ul class="mobile-menu">
        <li>
            <a href="/index.php">
                <i class="icon icon-home166"></i>
                <span>Home</span>
            </a>
        </li>
        <li>
            <a href="/epg-guide.php" class="link-live-tv">
                <i class="icon icon-tvscreen32"></i>
                <span>Live TV & Catch-Up</span>
            </a>
        </li>
        <li>
            <a href="/Movies.php" class="link-movies">
                <i class="icon icon-cinema130 "></i>
                <span>Movies</span>
            </a>
        </li>
        <li>
            <a href="/Shows.php" class="link-classic-shows">
                <i class="icon icon-tragedy3"></i>
                <span>Shows</span>
            </a>
        </li>
        <li>
            <a href="/packages_new.php" class="link-package">
                <i class="icon icon-boxes30"></i>
                <span>Packages</span>
            </a>
        </li>

        <li>
            <a href="/MyAccount.php" class="link-my-account">
                <i class="icon icon-padlock118"></i>
                <span>My Account</span>
            </a>
        </li>

    </ul>
</div>
<div class="zee-mobile-menu-overlay"></div>
