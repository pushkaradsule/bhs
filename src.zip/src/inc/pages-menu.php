<ul class="zee-myaccount-tabs zee-pages-tabs">
    <li class="active-tab"><a href="#"><span class="text">Item #1</span></a></li>
    <li><a href="#"><span class="text">Menu Item #2</span></a></li>
    <li><a href="#"><span class="text">Menu Item #3</span></a></li>
    <li><a href="#"><span class="text">Menu Item #4</span></a></li>
    <li><a href="#"><span class="text">Menu Item #5</span></a></li>
    <li><a href="#"><span class="text">Menu Item #6</span></a></li>
    <li><a href="#"><span class="text">Menu Item #7</span></a></li>
</ul>