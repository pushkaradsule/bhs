<div class="zee-carousel-similar-movies">

    <?php for ($i = 0; $i <= 14; $i++) { ?>
    <div class="item">

        <div class="carousel-helper-wrapper">
            <a href="/WatchMovie/is-raat-ki-subah-nahi/373" class="carousel-thumb-action"></a>
            <span class="carousel-helper carousel-helper-play">
                <a href="/WatchMovie/is-raat-ki-subah-nahi/373"><i class="icon icon-play-1"></i></a>
            </span>
        </div>
        <img class="carousel-thumbnail" src="/images/178x250.png">
    </div>
    <?php } ?>
    <?php if(!isset($similar)){ ?>
    <div class="item no-hover-arrow">
        <a href="#">
            <img src="/images/carousel-view-all.png" /></a>
    </div>
    <?php } ?>
</div>
