<div class="zee-carousel-epglive">
    <?php $titles = ['Kumkum Bhagya','Sarojini','Ek Tha Raja Ek Thi Rani','Jamai Raja','Yeh Vaada Raha','Satrangi Sasuraal','Sarojini','Ek Tha Raja Ek Thi Rani Aur Ek Thi Unki Amma','Qubool Hai','Tashn-E-Ishq','Kumkum Bhagya','Ek Tha Raja Ek Thi Rani','Yeh Vaada Raha','Tumhi Ho Bandhu Sakha Tumhi','Dilli Wali Thakur Gurls','Bhabhiji Ghar Pe Hai','Tashn-E-Ishq','Kumkum Bhagya','Ek Tha Raja Ek Thi Rani','Yeh Vaada Raha','Tumhi Ho Bandhu Sakha Tumhi','Dilli Wali Thakur Gurls','Bhabhiji Ghar Pe Hai']; ?>
    <?php foreach ($titles as $title) { ?>
    <div class="player-episodes-carousel-item">
        <?php echo ($title != 'Bhabhiji Ghar Pe Hai' ? '<a href="#">' : '<div>'); ?>
        <h3><?php echo $title ?></h3>
        <?php if($title == 'Ek Tha Raja Ek Thi Rani Aur Ek Thi Unki Amma'){ ?>
        <span class="epg-carousel-onnow">ON NOW<i class="icon icon-play-circled-1"></i></span>
        <?php } else { ?>
        <?php echo ($title != 'Bhabhiji Ghar Pe Hai' ? '<i class="icon icon-play-circled-1"></i>' : ''); ?>
        <?php } ?>
        <div class="clearfix"></div>
        <time>
            <i class="icon icon-clock-alt">00:00</i>
        </time>
        <?php echo ($title != 'Bhabhiji Ghar Pe Hai' ? '</a>' : '</div>'); ?>
    </div>
    <?php } ?>
</div>
