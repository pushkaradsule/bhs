<div class="zee-carousel-mix">

    <div class="item" style="width:390px;">

        <div class="carousel-helper-wrapper">
            <a href="/WatchMovie/is-raat-ki-subah-nahi/373" class="carousel-thumb-action carousel-thumb-action-tooltip"
                data-assetname="Is Raat Ki Subah Nahi"
                data-genre="Thriller"
                data-runningtime="130"
                data-desc="It is thriller film and based on the story by Sudhir Mishra&#39;s brother Sudhanshu Mishra who died in 1995. The entire plot of the film takes place through a single night.
"
                data-actors="Ashish Vidyarthi, Nirmal Pandey, Saurabh Shukla, Smriti Mishra"
                data-year="1996"
                data-language="Hindi"
                data-location="AsiaTv"
                data-url="/WatchMovie/is-raat-ki-subah-nahi/373"></a>
            <span class="carousel-helper carousel-helper-play">
                <a href="/WatchMovie/is-raat-ki-subah-nahi/373"><i class="icon icon-play-1"></i></a>
            </span>
            <span class="carousel-helper carousel-helper-info">
                <a href="#" class="carousel-mobile-info" data-thumbnail="http://images.nextv.ca/image/upload/h_250/v1433862639/kq9hph2wev6upc9crx4i.jpg"><i class="icon icon-info-1"></i></a>
            </span>
        </div>
        <img class="carousel-thumbnail" src="/images/390x250.png">
    </div>
    <?php for ($i = 0; $i <= 13; $i++) { ?>
    <div class="item" style="width:178px;">

        <div class="carousel-helper-wrapper">
            <a href="/WatchMovie/is-raat-ki-subah-nahi/373" class="carousel-thumb-action carousel-thumb-action-tooltip"
                data-assetname="Is Raat Ki Subah Nahi"
                data-genre="Thriller"
                data-runningtime="130"
                data-desc="It is thriller film and based on the story by Sudhir Mishra&#39;s brother Sudhanshu Mishra who died in 1995. The entire plot of the film takes place through a single night.
"
                data-actors="Ashish Vidyarthi, Nirmal Pandey, Saurabh Shukla, Smriti Mishra"
                data-year="1996"
                data-language="Hindi"
                data-location="AsiaTv"
                data-url="/WatchMovie/is-raat-ki-subah-nahi/373"></a>
            <span class="carousel-helper carousel-helper-play">
                <a href="/WatchMovie/is-raat-ki-subah-nahi/373"><i class="icon icon-play-1"></i></a>
            </span>
            <span class="carousel-helper carousel-helper-info">
                <a href="#" class="carousel-mobile-info" data-thumbnail="http://images.nextv.ca/image/upload/h_250/v1433862639/kq9hph2wev6upc9crx4i.jpg"><i class="icon icon-info-1"></i></a>
            </span>
        </div>
        <img class="carousel-thumbnail" src="/images/178x250.png">
    </div>
    <?php } ?>
</div>
