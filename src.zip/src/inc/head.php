<?php
$login ='0'; // 1|0
if($login == '1'){
    if(isset($bodyclass)){
        $bodyclass = $bodyclass . ' home-logged-in';
    } else {
        $bodyclass = 'home-logged-in';
    }
}
?>
<!doctype html>
<html class="no-js" lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="description" content="">
    <meta name="HandheldFriendly" content="True">
    <meta name="MobileOptimized" content="320">
    <meta name="viewport" content="initial-scale=1,user-scalable=no,maximum-scale=1,width=device-width">
    <meta http-equiv="cleartype" content="on">
    <meta http-equiv="x-dns-prefetch-control" content="off">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta name="apple-mobile-web-app-title" content="ZeeFamily.tv">
    <base href="/">
    <title>ZEE Family | Better than ANYFLIX </title>
    <meta name="description" content="Find top rated live channels, Bollywood films and classic shows all " />
    <meta name="keywords" content="watch bollywood movies online, Indian movies, Bollywood, zee TV online" />
    <link href="/styles/normalize.css" rel="stylesheet" />

    <link href='//fonts.googleapis.com/css?family=Roboto:100,400,400italic,300,300italic,500,700,900' rel='stylesheet' type='text/css'>
    <link href="/icons/icon-pack/fontello.css" rel="stylesheet" />
    <link href="/styles/animate.css" rel="stylesheet" />
    <link href="/styles/layout.css?v=1" rel="stylesheet" />
    <link href="/styles/selectric.css" rel="stylesheet" />
    <link href="/styles/ickeck.css" rel="stylesheet" />
    <link href="/styles/ngProgress.css" rel="stylesheet" />
    <link href="/styles/sweet-alert.css" rel="stylesheet" />
    <link href="/styles/tablesaw.stackonly.css" rel="stylesheet" />
    <link href="/styles/ripples.min.css" rel="stylesheet" />
    <link href="/styles/material.css?v=1" rel="stylesheet" />
    <link href="/styles/magnific-popup.css" rel="stylesheet" />
    <link href="/styles/footable.skin.css" rel="stylesheet" />



    <link href="/styles/toolbar.css" rel="stylesheet" />
    <link href="/styles/banner.css" rel="stylesheet" />
    <link href="/styles/carousel.css" rel="stylesheet" />
    <link href="/styles/zeeicon.css" rel="stylesheet" />
    <link href="/styles/jquery.qtip.css" rel="stylesheet" />
    <link href="/styles/footer.css" rel="stylesheet" />
    <link href="/styles/live-tv.css" rel="stylesheet" />
    <link href="/styles/movies.css" rel="stylesheet" />
    <link href="/styles/login.css" rel="stylesheet" />
    <link href="/styles/my_account.css" rel="stylesheet" />
    <!--<link href="/styles/packages.css" rel="stylesheet" />-->
    <link href="/styles/packages_new.css" rel="stylesheet" />
    <link href="/styles/packages_new_2.css" rel="stylesheet" />
    <link href="/styles/checkout.css" rel="stylesheet" />
    <link href="/styles/classic_show.css" rel="stylesheet" />
    <link href="/styles/search_results.css" rel="stylesheet" />
    <link href="/styles/epg.css" rel="stylesheet" />
    <link href="/styles/pageguide.min.css" rel="stylesheet" />
    <!--<link href="/styles/my_pages.css" rel="stylesheet" />-->
    <link href="/styles/smoke.css" rel="stylesheet" />
    <link href="/styles/shows-movies-content.css" rel="stylesheet" />



    <!-- skin -->
    <link rel="stylesheet" href="skins/theme-zblue.css" />
</head>
<body class="<?php echo (isset($bodyclass) ? $bodyclass : '') ?><?php echo ($footer_static == '1' ? ' static-footer' : '') ?><?php echo ($compact_topbar == '1' ? ' zee-toolbar-compact' : '') ?><?php echo ($banner == '1' ? ' page-with-banner' : '') ?>">

    <?php include('inc/mobile-utility.php'); ?>

    <div class="zee-body-wrapper">

<?php include('inc/top-bar.php'); ?>