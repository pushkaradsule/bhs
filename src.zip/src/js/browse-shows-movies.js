﻿;
(function ($) {

    "use strict";

    $(document).ready(function () {

        var md = new MobileDetect(window.navigator.userAgent);

        $('.zee-browse-header-utility > li> a:not(".no-tab-action")').on('click', function () {
            $('.zee-browse-header-utility > li > a').removeClass('active');
            $(this).addClass('active');
            var show_tab_id = $(this).data('tab');

            $('.search-result-tab').css('display', 'none');
            $('#' + show_tab_id).css('display', 'block');

        });


        $('.zee-player-overlay-items a').on('click touchstart pointerdown', function () {
            $('.zee-player-options-items > li > a').removeClass('active');
            $('#zee_player_options_data').removeClass('show');
        });

        $('.zee-player-options-items > li > a:not(".no-tab-action")').on('click touchstart pointerdown', function () {

            // set active tab
            $('.zee-player-options-items > li > a').removeClass('active');
            $(this).addClass('active');

            $('#zee_player_options_data').addClass('show');

            // show tab
            var ths = $(this),
                ths_tab = ths.data('tab');

            $('.zee-player-options-tab').removeClass('show-tab');
            $('#' + ths_tab).addClass('show-tab');


        });

        if (md.mobile()) {
            $('.close-player-info-touch').on('click touchstart pointerdown', function () {
                $('.zee-player-options-items > li > a').removeClass('active');
                $('#zee_player_options_data').removeClass('show');
            });
        } else {
            $('#zee_player_options_data').on('mouseleave', function () {
                $('.zee-player-options-items > li > a').removeClass('active');
                $('#zee_player_options_data').removeClass('show');
            });
        };


        $('#player_options_episodes_carousel').owlCarousel({
            margin: 15,
            nav: true,
            loop: false,
            dots: false,
            mouseDrag: true,
            baseClass: 'zee-carousel',
            themeClass: 'zee-carousel-theme',
            itemClass: 'zee-carousel-item',
            navText: ['<i class="icon icon-left-open-big"></i>', '<i class="icon icon-right-open-big"></i>'],
            responsive: {
                0: {
                    items: 1,
                    nav: false,
                    mouseDrag: true
                },
                479: {
                    items: 1,
                    nav: false,
                    mouseDrag: true
                },
                768: {
                    items: 2
                },
                950: {
                    items: 3,
                    slideBy: 2
                },
                1140: {
                    items: 3,
                    slideBy: 2
                },
                1520: {
                    items: 3,
                    slideBy: 2
                },
                1710: {
                    items: 4,
                    slideBy: 3
                },
                1900: {
                    items: 4,
                    slideBy: 3
                },
                2090: {
                    items: 5,
                    slideBy: 4
                },
                2280: {
                    items: 5,
                    slideBy: 4
                },
                2470: {
                    items: 6,
                    slideBy: 5
                },
                2660: {
                    items: 6,
                    slideBy: 5
                },
                2850: {
                    items: 7,
                    slideBy: 6
                },
                3040: {
                    items: 7,
                    slideBy: 6
                },
                3230: {
                    items: 8,
                    slideBy: 7
                },
                3420: {
                    items: 8,
                    slideBy: 7
                },
                3610: {
                    items: 9,
                    slideBy: 8
                },
                3800: {
                    items: 9,
                    slideBy: 8
                },
                3990: {
                    items: 10,
                    slideBy: 9
                }
            }
        });

        $('#play_upnext_circle').circleProgress({
            value: 1,
            size: 90,
            thickness: 3,
            fill: {
                color: '#ffffff'
            },
            animation: {
                duration: 10000
            }

        }).on('circle-animation-end', function () {

        });


    });

})(jQuery);