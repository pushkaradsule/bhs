﻿"use strict";
angular.module("main").service('zeeEpgService', ['$http', '$q', function ($http, $q) {
    return {
        getEpg: function (baseUrl, request, token) {

            var deferred = $q.defer();
            $http(
                { method: 'GET', data: request, url: '/Json/EpgItemByChannel.js', cache: false, headers: { 'RequestVerificationToken': token } }
                ).success(function (data) {
                console.log(data);
                    deferred.resolve(data);
                }).error(function (error) {
                    deferred.reject(error);
                });
            return deferred.promise;
        },
        getCustomerChannels: function (baseUrl, token) {
            var deferred = $q.defer();
            $http(
                { method: 'GET', url: baseUrl + 'MyChannels', cache: false, headers: { 'RequestVerificationToken': token } }
                ).success(function (data) {
                    deferred.resolve(data);
                }).error(function (error) {
                    deferred.reject(error);
                });
            return deferred.promise;
        },
        getCatchUp: function (baseUrl, request, token) {
            var deferred = $q.defer();
            $http(
                { method: 'POST', url: baseUrl + 'WatchCatchUp', data: request, cache: false, headers: { 'RequestVerificationToken': token } }
                ).success(function (data) {
                    deferred.resolve(data);
                }).error(function (error) {
                    deferred.reject(error);
                });
            return deferred.promise;
        },
        getChannelInfo: function (baseUrl, request, token) {
            console.log(request);
            var deferred = $q.defer();
            $http(
                { method: 'GET', url: '/json/channelInfo.js', data: request, cache: false, headers: { 'RequestVerificationToken': token } }
                //{ method: 'GET', url: '/json/channelerror.js', data: request, cache: false, headers: { 'RequestVerificationToken': token } }
                ).success(function (data) {
                                    deferred.resolve(data);
                }).error(function (error) {
                    deferred.reject(error);
                });
            return deferred.promise;
        }
    };
}
]).factory('epgData', ['$rootScope', function ($rootScope) {
    var epgData = [];

    epgData.list = [];

    epgData.setEpgData = function (epgdata) {
        epgData.list = epgdata;
        $rootScope.$broadcast('epgFresh', 'done');
    };

    return epgData;
}]);