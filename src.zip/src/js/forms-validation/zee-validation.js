﻿(function ($) {
    var classes = { groupIdentifier: ".form-group", error: 'input-validation-error', success: null };//success: 'has-success' 
    function updateClasses(inputElement, toAdd, toRemove) {
        inputElement.addClass(toAdd).removeClass(toRemove);
    }
    function onError(inputElement, message) {
        updateClasses(inputElement, classes.error, classes.success);
        if (inputElement.next().is('p.form-alert')) {
            inputElement
          .addClass("input-validation-error")
          .next().text(message);
        } else {
            inputElement
            .addClass("input-validation-error")
            .after("<p class='form-alert text-danger'>" + message + "</p>");
        }


    }
    function onSuccess(inputElement) {
        updateClasses(inputElement, classes.success, classes.error);
        if (inputElement.next().is('p.form-alert')) {
            var nextElement = inputElement.next();
            nextElement.remove();
        }
    }

    function onValidated(errorMap, errorList) {
        $.each(errorList, function () {
            onError($(this.element), this.message);
        });

        if (this.settings.success) {
            $.each(this.successList, function () {
                onSuccess($(this));
            });
        }
    }

    $(function () {
        $('form').each(function () {
            var validator = $(this).data('validator');
            validator.settings.showErrors = onValidated;
        });
    });
}(jQuery));