﻿var zeeplayer = function () {
    "use strict";
    var message = "<p><i class='banner-play-icon'></i><span>Resume</span></p>";
    var myStreamingTag = new ns_.StreamingTag({ customerC2: '20072668' });

    function setupPlayer(channelnfo, playerDiv, baseUrl) {

        var options = channelnfo.EpgItem;

        if (!channelnfo.k) return;
        if (!channelnfo.s) return;

        var f = $.rc4Decrypt(channelnfo.k, options.u);

        var playerOptions = {
            file: f,
            autostart: options.p === 0 ? true : false,
            primary: 'flash',
            base: baseUrl + "js/",
            androidhls: true,
            analytics: {
                enabled: false
            },
           width: "100%",
           height: "100%",
            abouttext: 'ZeeFamily TV',
            aboutlink: 'http://www.zeefamily.tv',
            events: {
                onComplete: function () {
                    myStreamingTag.stop();
                }
            }
        };


        if (options.p > 0) {
            playerOptions.plugins = {
                '/overlay.js': {
                    text: '<div id="overlayDiv" style="position: relative"><button class="resumeButton" onclick="resumePlayback()"></button> <span class="resumePlayback">Resume Playback</span></div>'
                }
            }
        }


        jwplayer(playerDiv).setup(playerOptions).onReady(function () {
            jwPlayerResumable.init(options.i, options.t, baseUrl, { SessionGuid: channelnfo.s, ProgrammeName: "", ChannelName: channelnfo.ChannelName });
        }).onError(function (error) {
            console.log(error);
        });

        if (options.p > 0) {
            $("#resume-movie-wrapper").removeClass("live-de-active");
            $("#resume-movie").click(function () {
                jwplayer().seek(options.p);
                $("#resume-movie-wrapper").addClass("live-de-active");
            });

        } else {
            $("#resume-movie-wrapper").hide();
        }

        jwplayer().onError(function () {
            jwplayer().load({
                file: "http://content.jwplatform.com/videos/7RtXk3vl-52qL9xLP.mp4",
                image: "http://content.jwplatform.com/thumbs/7RtXk3vl-480.jpg"
            });
            jwplayer().play();
        });

        jwplayer().onPlay(function () {
        
            var metadata = {};

            if (channelnfo.ChannelName) {
                if (channelnfo.EpgItem.Title) {
                    metadata = {
                        ns_st_ci: options.i, // Content Asset ID
                        c3: "CATCH-UP", // Dictionary Classification Value
                        c4: channelnfo.ChannelName, // Unused Dictionary Classification Value
                        c6: channelnfo.EpgItem.Title // Unused Dictionary Classification Value
                    };
                } else {
                    metadata = {
                        ns_st_ci: options.i, // Content Asset ID
                        c3: "LIVE", // Dictionary Classification Value
                        c4:  channelnfo.ChannelName, // Unused Dictionary Classification Value
                        c6: "" // Unused Dictionary Classification Value
                    };
                }
            }


            myStreamingTag.playVideoContentPart(metadata);

            $("#pause").removeClass("live-de-active");
            $("#play").addClass("live-de-active");
        });

        jwplayer().onPause(function () {
            $("#pause").addClass("live-de-active");
            $("#play").removeClass("live-de-active");
            
        });

      

        function resumePlayback() {
            $("#overlayDiv").hide();
            jwplayer().seek(options.p);
        }

        if (options.p > 0) {
            window.resumePlayback = null;
            window.resumePlayback = resumePlayback;
        }

        function stopPlayers() {

            jwplayer().stop();
            myStreamingTag.stop();
        }

        window.onbeforeunload = stopPlayers;

    }

    function initialise(channelnfo, playerDiv, baseUrl) {
        jwplayer.key = "udcJDrJH7pZfao0pgVPEyTqve+EFlQQdkggxCw==";
        setupPlayer(channelnfo, playerDiv, baseUrl);
    }

    function pause() {
        jwplayer().pause();
    }

    function play() {
        jwplayer().play();
    }



    return {
        Initialise: initialise,
        pause: pause,
        play: play
    }
}();


