;
(function($) {

	"use strict";

	$(document).ready(function() {
		
		$('#epg_date_picker').owlCarousel({
		    margin : 5,
		    nav : true,
		    dots : false,
		    lazyLoad : false,
		    loop : false,
		    baseClass : 'epg-carousel',
		    themeClass : 'epg-carousel-theme',
		    itemClass : 'epg-carousel-item',
		    navText : ['&nbsp;','&nbsp;'],
		    responsiveClass : true,
		    mouseDrag : true,
		    responsive :{
		    	768:{
		            items:10
		        },
		        992:{
		            items:12
		        },
		        1024:{
		            items:15
		        },
		        1200: {
		        	items: 20
		        },
		        2000:{
		            items:28
		        }
		    }
		});
		
		// set epg height
		var md = new MobileDetect(window.navigator.userAgent);
		
		function set_epg_height(){
			var epg_main = $('#epg_main'),
				epg_channels = $('#epg_main_channel_outer'),
				epg_pgm = $('#epg_main_program_outer'),
				epg_ch_count = epg_channels.data('channel-count'),
				win_height = $(window).height();
			
			if (md.mobile()) {
				win_height = $(window).height() - 40;
			}
			else {
				win_height = $(window).height() - 100;
			}
			
			if($(window).width() < 992) {
				epg_main.css('height', epg_ch_count*85-5);
				epg_channels.css('height', 'auto');
				epg_pgm.css('height', epg_ch_count*85-5);
			}
			else {
				epg_main.css('height', win_height);
				epg_channels.css('height', win_height);
				epg_pgm.css('height', win_height);
			};
			
		};
		set_epg_height();
		
		$(window).on('resize', $.debounce( 200, function() {
			set_epg_height();
		}));
		
		if (!md.mobile()) {
			$('#epg_main_channel_outer, #epg_main_program_outer').mCustomScrollbar({
				axis : 'y',
				scrollbarPosition : 'outside'
			});
		};
		
		$('.epg-program-link').on('click', function(e){
			
			e.preventDefault();
			$('.epg-program-link').parent().removeClass('active-program');
			$(this).parent().addClass('active-program');
			
		});
		
		$('.epg-channel-link').on('click', function(e){
			
			e.preventDefault();
			$('.epg-channel-link').parent().removeClass('active-channel');
			$(this).parent().addClass('active-channel');
			
		});
		
		function launch_mobile_player() {
			
			if($(window).width() < 992) {
				
				$('.epg-program-link-play').on('click', function(){
					$.magnificPopup.open({
						items: {
							src: 'blank.php',
							type: 'iframe'
						},
						callbacks: {
							close: function() {
								$('.epg-program-link.epg-program-link-play').parent().removeClass('active-program');
							}
						}
					});
				});
				
			}
			
		};
		launch_mobile_player();
		
		if($(window).width() < 992) {
			
			$('.epg-program-link.epg-program-link-play').parent().removeClass('active-program');
			
		};
		
		$(window).on('resize', $.debounce( 100, function() {
			launch_mobile_player();
		}));
		
		// epg player controls
		$('#epg_player_view_toggle').on('click', function(e){
			
			e.preventDefault();
			
			if ( $(this).hasClass('epg-player-view-tv') ) {
				$(this).removeClass('epg-player-view-tv').addClass('epg-player-view-compact');
				$(this).find('span').text('Compact Mode');
				$('#epg_main').addClass('epg-full-tv-mode');
			}
			else if($(this).hasClass('epg-player-view-compact')){
				$(this).removeClass('epg-player-view-compact').addClass('epg-player-view-tv');
				$(this).find('span').text('TV Mode');
				$('#epg_main').removeClass('epg-full-tv-mode');
			}
			
		});
		
		$('#epg_player_pause').on('click', function(e){
			
			e.preventDefault();
			
			$(this).hide();
			$('#epg_player_play').css('display','block');
			
		});
		
		$('#epg_player_play').on('click', function(e){
			
			e.preventDefault();
			
			$(this).hide();
			$('#epg_player_pause').css('display','block');
			
		});	
		
		// epg tour
		if (!md.mobile()) {
			tl.pg.init({
				custom_open_button : '#epg_user_guide'
			});
		};
		
		
		
	}); // document.ready

})(jQuery);