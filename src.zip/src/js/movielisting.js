﻿"use strict";

var resizeTimer = 200;

var responsive = {
    0: {
        items: 3,
        nav: false,
        mouseDrag: true
    },
    479: {
        items: 4
    },
    760: {
        items: 5
    },
    950: {
        items: 6
    },
    1140: {
        items: 7
    },
    1520: {
        items: 8
    },
    1710: {
        items: 9
    },
    1900: {
        items: 10
    },
    2090: {
        items: 11
    },
    2280: {
        items: 12
    },
    2470: {
        items: 13
    },
    2660: {
        items: 14
    },
    2850: {
        items: 15
    },
    3040: {
        items: 16
    },
    3230: {
        items: 17
    },
    3420: {
        items: 18
    },
    3610: {
        items: 19
    },
    3800: {
        items: 20
    },
    3990: {
        items: 21
    }
};


function onResize() {
    var noOfItems = -1;

    var containerSize = $(".grid-container").width();

    $.each(responsive, function (breakpoint) {
        if (breakpoint <= containerSize && breakpoint > noOfItems) {
            noOfItems = Number(breakpoint);
        }
    });
    var itemsCount = responsive[noOfItems].items;

    var itemWidth = (containerSize - (itemsCount * 10)) / itemsCount;

    $(".movies-grid-items").css("width", Number(itemWidth).toFixed(2));
    $(".movies-grid-items").css("margin-right", 10);
    $(".movies-grid-items:nth-child(" + itemsCount + "n)").css({ "margin-right": "0", "clear": "both" });


}


/* ng-infinite-scroll - v1.0.0 - 2013-02-23 */
var mod;

mod = angular.module('infinite-scroll', []);

mod.directive('infiniteScroll', [
  '$rootScope', '$window', '$timeout', function ($rootScope, $window, $timeout) {
      return {
          link: function (scope, elem, attrs) {
              var checkWhenEnabled, handler, scrollDistance, scrollEnabled;
              $window = angular.element($window);
              scrollDistance = 0;
              if (attrs.infiniteScrollDistance != null) {
                  scope.$watch(attrs.infiniteScrollDistance, function (value) {
                      return scrollDistance = parseInt(value, 10);
                  });
              }
              scrollEnabled = true;
              checkWhenEnabled = false;
              if (attrs.infiniteScrollDisabled != null) {
                  scope.$watch(attrs.infiniteScrollDisabled, function (value) {
                      scrollEnabled = !value;
                      if (scrollEnabled && checkWhenEnabled) {
                          checkWhenEnabled = false;
                          return handler();
                      }
                  });
              }
              handler = function () {
                  var elementBottom, remaining, shouldScroll, windowBottom;
                  windowBottom = $window.height() + $window.scrollTop();
                  elementBottom = elem.offset().top + elem.height();
                  remaining = elementBottom - windowBottom;
                  shouldScroll = remaining <= $window.height() * scrollDistance;
                  if (shouldScroll && scrollEnabled) {
                      if ($rootScope.$$phase) {
                          return scope.$eval(attrs.infiniteScroll);
                      } else {
                          return scope.$apply(attrs.infiniteScroll);
                      }
                  } else if (shouldScroll) {
                      return checkWhenEnabled = true;
                  }
              };
              $window.on('scroll', handler);
              scope.$on('$destroy', function () {
                  return $window.off('scroll', handler);
              });
              return $timeout((function () {
                  if (attrs.infiniteScrollImmediateCheck) {
                      if (scope.$eval(attrs.infiniteScrollImmediateCheck)) {
                          return handler();
                      }
                  } else {
                      return handler();
                  }
              }), 0);
          }
      };
  }
]);

var app = angular.module('movies', ['infinite-scroll']);


app.service('zeeMovieService', ['$http', '$q', function ($http, $q) {
    return {
        getMovies: function (url, request, token) {

            var deferred = $q.defer();
            $http(
                { method: 'GET', data: request, url: url, cache: false, headers: { 'RequestVerificationToken': token } }
                ).success(function (data) {
                console.log(data);
                    deferred.resolve(data);
                }).error(function (error) {
                    deferred.reject(error);
                });
            return deferred.promise;
        }
    };
}
]);


app.controller('MovieController',['$scope', 'MovieList', function ($scope, MovieList) {
    $scope.movieList = new MovieList();

    console.log($scope.MovieList);

    $scope.filterByAlphabet = function (alphabet) {
        $scope.movieList.noResult = false;
        $scope.movieList.searchText = "";
        $scope.movieList.CurrentPage = 0;
        $scope.movieList.alphabetFilter = true;
        $scope.movieList.alphabetFilterSearch = alphabet;
        $scope.movieList.items = [];
        $scope.movieList.nextPage();
    }


    $scope.filterByAttribute = function (alphabet) {
        $scope.movieList.noResult = false;
        var categoryOrServiceTag = $("#categories").val();

        if (categoryOrServiceTag.indexOf("PL-") === 0) {
            $scope.movieList.serviceTag = categoryOrServiceTag.split("-")[1];
            $scope.movieList.genreFilter = undefined;
        } else {
            $scope.movieList.genreFilter = categoryOrServiceTag;
            $scope.movieList.serviceTag = undefined;
        }

        var language = $("#language").val();

        if (language !== "") {
            $scope.movieList.languageFilter = $("#language").val();
        } else {
            $scope.movieList.languageFilter = undefined;
        }

        $scope.movieList.CurrentPage = 0;
        $scope.movieList.items = [];

        if ($scope.movieList.searchText && $scope.movieList.searchText.length === 0) {
            $scope.movieList.alphabetFilter = true;
            $scope.movieList.alphabetFilterSearch = alphabet;
        } else {
            $scope.movieList.alphabetFilter = false;
        }



        $scope.movieList.nextPage();

    }
    var infopopUpTemplate = _.template("<div class='carousel-info-popup container'><div class='zee-carousel-tooltip-data row'><div class='item-thumbnail col-md-4 col-sm-3 col-xs-12'><img src='<%= item.thumbnail %>'></div><div class='item-text-wrapper col-md-8 col-sm-9 col-xs-12'><div class='item-name'><h3><%= item.movieName %></h3><span>(<%= item.YearRelease %>)</span></div><div class='item-genre'><span><%=item.Genre %></span></div><ul class='item-info-list'><li><span class='item-language'><%=item.Language %></span></li><li><span class='item-length'><%= item.RunningTime %><sup>min</sup></span></li></ul><div class='item-cast'><span>cast :</span><%= item.Actors %>..</div><div class='item-details'><p><%= item.HtmlContent %></p></div><ul class='item-watch-now'><li><a href='<%= item.url %>' class='item-watch-link'>Watch Now</a></li></ul></div></div></div>");

    $scope.showMobileInfo = function (data) {

        var jsonobj = {
            movieName: data.AssetName,
            RunningTime: data.ShowTime,
            HtmlContent: data.HtmlContent,
            Actors: data.Actors,
            YearRelease: data.YearRelease,
            Language: data.Language,
            Genre: data.Genre,
            url: data.qtipUrl,
            thumbnail: data.ImageUrl
        };

        $.magnificPopup.open({
            items: {
                src: infopopUpTemplate({ item: jsonobj }),
                type: 'inline'
            }
        });
    }



}]);

app.factory('MovieList', ['$http', 'zeeMovieService', '$window', '$timeout', function ($http, zeeMovieService, $window, $timeout) {

    var movieList = function () {
        this.items = [];
        this.busy = false;
        this.after = '';
        this.CurrentPage = 0;
        this.alphabetFilter = false;
        this.serviceTag = undefined;
        this.alphabetFilterSearch = undefined;
        this.genreFilter = undefined;
        this.languageFilter = undefined;
        this.searchText = undefined;
        this.complete = false;
        this.noResult = false;
    };


    movieList.prototype.nextPage = function () {
        if (this.busy) return;
        this.busy = true;
        var that = this;
        var urlChannel = window.baseUrl + "json/getMovies" + this.CurrentPage + ".js";
        var request = {
            "CurrentPage": this.CurrentPage,
            "AlphabetFilter": this.alphabetFilter,
            "ServiceTag": $window.playList ? $window.playList : this.serviceTag,
            "GenreFilter": this.genreFilter,
            "Language": this.languageFilter,
            "SearchText": $window.searchText ? $window.searchText : this.alphabetFilter ? this.alphabetFilterSearch : this.searchText
        };
        zeeMovieService.getMovies(urlChannel, request, $('#antiForgeryToken').val())
            .then(function (data) {

                that.complete = data.length === 0;
                that.CurrentPage = that.CurrentPage + 1;

                var items = data;
                for (var i = 0; i < items.length; i++) {
                    that.items.push(items[i]);
                }

                that.busy = false;

                that.noResult = that.items.length === 0;

                $timeout(onResize, 200);

            });
    };

    return movieList;
}]);


app.directive('qtip', ['$timeout',function ($timeout) {
    return {
        restrict: 'A',
        link: function (scope, element, attrs) {
            var jsonobj = {
                movieName: attrs.qtipAssetname,
                RunningTime: attrs.qtipRunningtime,
                HtmlContent: attrs.qtipDesc,
                Actors: attrs.qtipActors,
                YearRelease: attrs.qtipYear,
                Language: attrs.qtipLanguage,
                Genre: attrs.qtipGenre,
                url: attrs.qtipUrl,
                thumbnail: attrs.qtipThumbnail
            };

            var popUpTemplate = _.template("<div class='zee-carousel-tooltip-data'><div class='item-name'><h3><%= item.movieName %></h3><span>(<%= item.YearRelease %>)</span></div><div class='item-genre'><span><%=item.Genre %></span></div><ul class='item-info-list'><li><span class='item-language'><%=item.Language %></span></li><li><span class='item-length'><%= item.RunningTime %><sup>min</sup></span></li></ul><div class='item-cast'><span>cast :</span><%= item.Actors %>..</div><div class='item-details'><p><%= item.HtmlContent %></p></div><ul class='item-watch-now'><li><a href='<%= item.url %>' class='item-watch-link'>Watch Now</a></li></ul></div>");

            element.qtip({
                id: false,
                content: {
                    text: popUpTemplate({ item: jsonobj }),
                    title: {
                        text: false,
                        button: false
                    }
                },
                position: {
                    my: 'right center',
                    at: 'left center',
                    viewport: $(window),
                    adjust: {
                        method: 'flip none'
                    }
                },
                show: {
                    solo: true,
                    delay: 500
                },
                hide: {
                    fixed: true,
                    delay: 300
                },
                style: {
                    classes: 'zee-carousel-tooltip',
                    tip: {
                        width: 15,
                        height: 6,
                        border: 0
                    }
                },
                events: {
                    show: function () {
                        $(this).find('.item-details').shorten({
                            showChars: '100',
                            moreText: '...'
                        });
                    }
                }
            });

            // carousel helpers on mobile devices
            $timeout(function () {
                $('.zee-carousel-item, .zee-movies-grid > div > div.item').on('touchstart pointerdown', function () {
                    var ts = $(this);
                    $('.zee-carousel-item, .zee-movies-grid > div > div.item').removeClass('hover');
                    ts.toggleClass('hover');
                });
            }, 200);



        }
    };
}]);

app.service('zeeEpgService', ['$http', '$q', function ($http, $q) {
    return {
        getEpgSearch: function (url, request, token) {

            var deferred = $q.defer();
            $http(
                { method: 'GET', data: request, url: '/json/EpgItemSearch.json', cache: false, headers: { 'RequestVerificationToken': token } }
                ).success(function (data) {
                    deferred.resolve(data);
                }).error(function (error) {
                    deferred.reject(error);
                });
            return deferred.promise;
        }

    };
}
]);


app.controller('epgSearchController',['$scope', '$http', '$timeout', 'zeeEpgService', '$window', function ($scope, $http, $timeout, zeeEpgService, $window) {
  
    $scope.msInDay = 86400000;
    $scope.allChannels = [];
    $scope.now = new Date();
    $scope.EpgItems = [];
    $scope.playerInfo = {};
    $scope.todayBoD = new Date($scope.now.getFullYear(), $scope.now.getMonth(), $scope.now.getDate());
    $scope.todayBoD.setTime($scope.todayBoD.getTime() - 1000);
    $scope.todayBoD = (new Date($scope.todayBoD));


    $scope.fivedays = new Date($scope.now.getFullYear(), $scope.now.getMonth(), $scope.now.getDate());
    $scope.fivedays.setTime($scope.todayBoD.getTime() - 1000 - (24 * 60 * 60 * 1000) * 5);
    $scope.fivedays = (new Date($scope.fivedays));


    $scope.playerLoading = false;
    $scope.state = true;

    $scope.getEoD = function (date) {
        var result = new Date(date);
        result.setTime(result.getTime() + $scope.msInDay - 2000);
        return new Date(result);
    };



    $scope.isEpgItemOnNow = function (epgItem) {
        var start = Date.parse(epgItem.StartDate);
        var end = Date.parse(epgItem.EndDate);
        var result = (start <= $scope.now) && ($scope.now <= end);
        epgItem.IsPlayingNow = result;
        epgItem.IsCatchUp = $scope.isPastEpgItem(epgItem);

        return result;
    }

    $scope.goBack = function () {
        $window.history.back();
    }

    $scope.isPastEpgItem = function (epgItem) {
        var end = new Date(epgItem.EndDate);
        return (end <= $scope.now);
    }

    $scope.epgItemProgress = function (epgItem) {
        var result = 0;
        if ($scope.isEpgItemOnNow(epgItem)) {
            var start = Date.parse(epgItem.StartDate);
            var end = Date.parse(epgItem.EndDate);
            result = (($scope.now - start) / (end - start));
        }
        return result;
    }

    function getEpgSearch() {
        var date = $scope.todayBoD;


        var url = $window.baseUrl + "EpgItemSearch";
        var request = {
            SearchText: $window.searchText,
            "TimeStart": $scope.fivedays.toISOString(),
            "TimeEnd": $scope.getEoD(date).toISOString(),
        }

        zeeEpgService.getEpgSearch(url, request, $('#antiForgeryToken').val())
        .then(function (data) {
            $scope.EpgItems = data;
        });





    }


    function play(url) {
        window.location.href = url;
    }

    $scope.playChannel = function (channel) {
        play(channel.Url);
    }

    $scope.catchUpPlay = function (epg) {
        var url = epg.CatchupUrl.replace("{0}", epg.EpgItemId);
        play(url);
    }

    getEpgSearch();

}]);

$(document).ready(function () {
    $(window).resize(onResize); //set th
    var searchWin = jRespond([
	        {
	            label: 'list',
	            enter: 0,
	            exit: 664
	        },
	        {
	            label: 'grid',
	            enter: 665,
	            exit: 3500
	        }
    ]);
    searchWin.addFunc({
        breakpoint: ['grid'],
        enter: function () {
            $('li.search-grid-items').matchHeight();
        },
        exit: function () {
        }
    });
});