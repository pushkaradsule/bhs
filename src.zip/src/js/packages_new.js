﻿;
(function ($) {

    "use strict";

    $(document).ready(function () {

        var packageWin = jRespond([
	        {
	            label: 'list',
	            enter: 0,
	            exit: 664
	        },
	        {
	            label: 'grid',
	            enter: 665,
	            exit: 3500
	        }
        ]);
        packageWin.addFunc({
            breakpoint: ['grid'],
            enter: function () {
                $('li.packages-list-item').matchHeight({
                    byRow: true,
                    property: 'height',
                });
            },
            exit: function () {
            }
        });

        var myScroll;

        function loaded() {
            myScroll = new IScroll('#slected_package_tray', { mouseWheel: true, click: true, tap: true });
        }

        //document.addEventListener('touchmove', function (e) { e.preventDefault(); }, false);

        loaded();

        $('#package_tray_trigger_xsmall').on('click touchstart pointerdown', function () {
            $('.package-selected-container').addClass('expand');
        });


        $('#package_tray_close_xsmall').on('click touchstart pointerdown', function () {
            $('.package-selected-container').removeClass('expand');
        });

        

    }); // document.ready

})(jQuery);