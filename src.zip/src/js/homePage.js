﻿"use strict";
var app = angular.module('home', []);

app.service('zeeEpgService', ['$http', '$q', function ($http, $q) {
    return {
        getEpg: function (url, request, token) {

            var deferred = $q.defer();
            $http(
                { method: 'GET', data: request, url: '/Json/EpgItemByChannel.js', cache: false, headers: { 'RequestVerificationToken': token } }
                ).success(function (data) {
                    deferred.resolve(data);
                }).error(function (error) {
                    deferred.reject(error);
                });
            return deferred.promise;
        }

    };
}
]);


app.controller('homechannels', ["$scope", "$http", "$timeout", "zeeEpgService", "$window", function ($scope, $http, $timeout, zeeEpgService, $window) {

    $scope.msInDay = 86400000;
    $scope.allChannels = [];
    $scope.now = new Date();
    var baseUrl = $window.baseUrl;
    $scope.EpgItems = [];
    $scope.playerInfo = {};
    $scope.todayBoD = new Date($scope.now.getFullYear(), $scope.now.getMonth(), $scope.now.getDate());
    $scope.todayBoD.setTime($scope.todayBoD.getTime() + 1000);
    $scope.todayBoD = (new Date($scope.todayBoD));
    $scope.playerLoading = false;
    $scope.state = true;

    $scope.getEoD = function (date) {
        var result = new Date(date);
        result.setTime(result.getTime() + $scope.msInDay - 2000);
        return new Date(result);
    };



    $scope.isEpgItemOnNow = function (epgItem) {
        var start = Date.parse(epgItem.StartDate);
        var end = Date.parse(epgItem.EndDate);
        var result = (start <= $scope.now) && ($scope.now <= end);
        epgItem.IsPlayingNow = result;
        epgItem.IsCatchUp = $scope.isPastEpgItem(epgItem);

        return result;
    }


    $scope.isPastEpgItem = function (epgItem) {
        var end = new Date(epgItem.EndDate);
        return (end <= $scope.now);
    }

    $scope.epgItemProgress = function (epgItem) {
        var result = 0;
        if ($scope.isEpgItemOnNow(epgItem)) {
            var start = Date.parse(epgItem.StartDate);
            var end = Date.parse(epgItem.EndDate);
            result = (($scope.now - start) / (end - start));
        }
        return result;
    }


    $scope.channels = [];

    $scope.getChannelInfo = function (d, channelId) {

        var date = $scope.todayBoD;

        if (d) {
            date = new Date(d);
        }

        var url = baseUrl + "EpgItemByChannel";
        var request = {
            "TimeStart": date.toISOString(),
            "TimeEnd": $scope.getEoD(date).toISOString(),
            "ChannelIDs": channelId
        };

        return zeeEpgService.getEpg(url, request, $('#antiForgeryToken').val())
           .then(function (data) {
               var queryResult = Enumerable.from(data)
                          .where(function (x) {
                              return $scope.now <= Date.parse(x.EndDate);
                          })
                          .toArray();

               $scope.EpgItems = data;



               if (queryResult.length > 0) {

                   var catchUpIndex = data.indexOf(queryResult[0]);
                   return { current: queryResult[0], next: queryResult[1], catchUp: catchUpIndex > 0 ? data[catchUpIndex - 1] : {} }
               }
               return null;
           });


    }

}]);


//$(document).ready(function () {

//    $('.container-fluid').jscroll({
//        loadingHtml: "<div class='loading' style='margin-left:45%;'><div class='loading-bar big'></div><div class='loading-bar big'></div><div class='loading-bar big'></div><div class='loading-bar big'></div><div class='loading-bar big'></div><div class='loading-bar big'></div><div class='loading-bar big'></div><div class='loading-bar big'></div><div class='loading-bar big'></div><div class='loading-bar big'></div></div>",
//        padding: 20,
//        nextSelector: '#nextlink',
//        debug: false,
//        callback: function () {
//            var justloadItems = $('.zee-carousel-data:not(.owl-loaded)');

//            justloadItems.owlCarousel({
//                margin: 10,
//                nav: true,
//                dots: false,
//                lazyLoad: true,
//                loop: true,
//                baseClass: 'zee-carousel',
//                themeClass: 'zee-carousel-theme',
//                itemClass: 'zee-carousel-item',
//                navText: ['&nbsp;', '&nbsp;'],
//                responsiveClass: true,
//                mouseDrag: false,
//                responsive: {
//                    0: {
//                        items: 3,
//                        nav: false,
//                        mouseDrag: true
//                    },
//                    479: {
//                        items: 4
//                    },
//                    760: {
//                        items: 5
//                    },
//                    950: {
//                        items: 6
//                    },
//                    1140: {
//                        items: 7
//                    },
//                    1520: {
//                        items: 8
//                    },
//                    1710: {
//                        items: 9
//                    },
//                    1900: {
//                        items: 10
//                    },
//                    2090: {
//                        items: 11
//                    },
//                    2280: {
//                        items: 12
//                    },
//                    2470: {
//                        items: 13
//                    },
//                    2660: {
//                        items: 14
//                    },
//                    2850: {
//                        items: 15
//                    },
//                    3040: {
//                        items: 16
//                    },
//                    3230: {
//                        items: 17
//                    },
//                    3420: {
//                        items: 18
//                    },
//                    3610: {
//                        items: 19
//                    },
//                    3800: {
//                        items: 20
//                    },
//                    3990: {
//                        items: 21
//                    }
//                }
//            });

//            // launch carousel thumbnail info on mobiles
//            justloadItems.find('.carousel-mobile-info').each(function () {

//                var infoThis = $(this),
//                    infoDataSrc = infoThis.parents('.carousel-helper-wrapper').find('.carousel-thumb-action');

//                var infoJsonobj = {
//                    movieName: infoDataSrc.data('assetname'),
//                    RunningTime: infoDataSrc.data('runningtime'),
//                    HtmlContent: infoDataSrc.data('desc'),
//                    Actors: infoDataSrc.data('actors'),
//                    YearRelease: infoDataSrc.data('year'),
//                    Language: infoDataSrc.data('language'),
//                    Genre: infoDataSrc.data('genre'),
//                    url: infoDataSrc.data('url'),
//                    favourite_txt: (infoDataSrc.data('favourite') === '1' ? 'in favourites' : 'add to favourite'),
//                    favourite_class: (infoDataSrc.data('favourite') === '1' ? ' added' : ''),
//                    thumbnail: infoThis.data('thumbnail')
//                };


//                var infopopUpTemplate = _.template("<div class='carousel-info-popup container'><div class='zee-carousel-tooltip-data row'><div class='item-thumbnail col-md-4 col-sm-3 col-xs-12'><img src='<%= item.thumbnail %>'></div><div class='item-text-wrapper col-md-8 col-sm-9 col-xs-12'><div class='item-name'><h3><%= item.movieName %></h3><span>(<%= item.YearRelease %>)</span></div><div class='item-genre'><span><%=item.Genre %></span></div><ul class='item-info-list'><li><span class='item-language'><%=item.Language %></span></li><li><span class='item-length'><%= item.RunningTime %><sup>min</sup></span></li></ul><div class='item-cast'><span>cast :</span><%= item.Actors %>..</div><div class='item-details'><p><%= item.HtmlContent %></p></div><ul class='item-watch-now'><li><a href='<%= item.url %>' class='item-watch-link'>Watch Now</a></li></ul></div></div></div>");

//                infoThis.on('click', function (event) {

//                    event.preventDefault();

//                    $.magnificPopup.open({
//                        items: {
//                            src: infopopUpTemplate({ item: infoJsonobj }),
//                            type: 'inline'
//                        }
//                    });
//                });
//            });

//            // launch show info on mobiles
//            justloadItems.find('.show-mobile-info').each(function () {

//                var infoThis = $(this),
//                    infoDataSrc = infoThis.parents('.carousel-helper-wrapper').find('.show-grid-action');

//                var infoJsonobj = {
//                    showName: infoDataSrc.data('assetname'),
//                    HtmlContent: infoDataSrc.data('desc'),
//                    Actors: infoDataSrc.data('actors'),
//                    Language: infoDataSrc.data('language'),
//                    EpisodeCount: infoDataSrc.data('runningtime'),
//                    url: infoDataSrc.data('url'),
//                    favourite_txt: (infoDataSrc.data('favourite') === '1' ? 'in favourites' : 'add to favourite'),
//                    favourite_class: (infoDataSrc.data('favourite') === '1' ? ' added' : ''),
//                    thumbnail: infoThis.data('thumbnail')
//                };


//                var infopopUpTemplate = _.template("<div class='carousel-info-popup container'><div class='zee-carousel-tooltip-data row'><div class='item-thumbnail col-md-4 col-sm-3 col-xs-12'><img src='<%= item.thumbnail %>'></div><div class='item-text-wrapper col-md-8 col-sm-9 col-xs-12'><div class='item-name'><h3><%= item.showName %></h3></div><ul class='item-info-list'><li><span class='item-language'><%=item.Language %></span></li><li><span class='item-length'><%= item.EpisodeCount %><sup>Episodes</sup></span></li></ul><div class='item-cast'><span>cast :</span><%= item.Actors %>..</div><div class='item-details'><p><%= item.HtmlContent %></p></div><ul class='item-watch-now'><li><a href='<%= item.url %>' class='item-watch-link'>Watch Now</a></li></ul></div></div></div>");

//                infoThis.on('click', function (event) {

//                    event.preventDefault();

//                    $.magnificPopup.open({
//                        items: {
//                            src: infopopUpTemplate({ item: infoJsonobj }),
//                            type: 'inline'
//                        }
//                    });
//                });
//            });

//            // show tooltip for thumbnails
//            var $carouselThumb = justloadItems.find('.carousel-thumb-action');
//            if ($carouselThumb.length) {
//                $carouselThumb.each(function () {

//                    var tsQtip = $(this);

//                    var jsonobj = {
//                        movieName: tsQtip.data('assetname'),
//                        RunningTime: tsQtip.data('runningtime'),
//                        HtmlContent: tsQtip.data('desc'),
//                        Actors: tsQtip.data('actors'),
//                        YearRelease: tsQtip.data('year'),
//                        Language: tsQtip.data('language'),
//                        Genre: tsQtip.data('genre'),
//                        url: tsQtip.data('url'),
//                        favourite_txt: (tsQtip.data('favourite') === '1' ? 'in watchlist' : 'add to watchlist'),
//                        favourite_class: (tsQtip.data('favourite') === '1' ? ' added' : '')
//                    };

//                    var popUpTemplate = _.template("<div class='zee-carousel-tooltip-data'><div class='item-name'><h3><%= item.movieName %></h3><span>(<%= item.YearRelease %>)</span></div><div class='item-genre'><span><%=item.Genre %></span></div><ul class='item-info-list'><li><span class='item-language'><%=item.Language %></span></li><li><span class='item-length'><%= item.RunningTime %><sup>min</sup></span></li></ul><div class='item-cast'><span>cast :</span><%= item.Actors %>..</div><div class='item-details'><p><%= item.HtmlContent %></p></div><ul class='item-watch-now'><li><a href='<%= item.url %>' class='item-watch-link'>Watch Now</a></li></ul></div>");

//                    tsQtip.qtip({
//                        id: false,
//                        content: {
//                            text: popUpTemplate({ item: jsonobj }),
//                            title: {
//                                text: false,
//                                button: false
//                            }
//                        },
//                        position: {
//                            my: 'right center',
//                            at: 'left center',
//                            viewport: $(window),
//                            adjust: {
//                                method: 'flip none'
//                            }
//                        },
//                        show: {
//                            solo: true,
//                            delay: 500
//                        },
//                        hide: {
//                            fixed: true,
//                            delay: 300
//                        },
//                        style: {
//                            classes: 'zee-carousel-tooltip',
//                            tip: {
//                                width: 15,
//                                height: 6,
//                                border: 0
//                            }
//                        },
//                        events: {
//                            show: function () {

//                                $(this).find('.item-details').shorten({
//                                    showChars: '100',
//                                    moreText: '...'
//                                });
//                            }
//                        }
//                    });

//                });
//            };


//            // show tooltip for shows
//            var $showThumb = justloadItems.find('.show-grid-action');
//            if ($showThumb.length) {
//                $showThumb.each(function () {

//                    var tsQtip = $(this);

//                    var jsonobj = {
//                        showName: tsQtip.data('assetname'),
//                        HtmlContent: tsQtip.data('desc'),
//                        Actors: tsQtip.data('actors'),
//                        Language: tsQtip.data('language'),
//                        EpisodeCount: tsQtip.data('runningtime'),
//                        url: tsQtip.data('url'),
//                        favourite_txt: (tsQtip.data('favourite') === '1' ? 'in watchlist' : 'add to watchlist'),
//                        favourite_class: (tsQtip.data('favourite') === '1' ? ' added' : '')
//                    };

//                    var popUpTemplate = _.template("<div class='zee-carousel-tooltip-data'><div class='item-name'><h3><%= item.showName %></h3></div><ul class='item-info-list'><li><span class='item-language'><%=item.Language %></span></li><li><span class='item-length'><%= item.EpisodeCount %><sup>Episodes</sup></span></li></ul><div class='item-cast'><span>cast :</span><%= item.Actors %>..</div><div class='item-details'><p><%= item.HtmlContent %></p></div><ul class='item-watch-now'><li><a href='<%= item.url %>' class='item-watch-link'>Watch Now</a></li></ul></div>");

//                    tsQtip.qtip({
//                        id: false,
//                        content: {
//                            text: popUpTemplate({ item: jsonobj }),
//                            title: {
//                                text: false,
//                                button: false
//                            }
//                        },
//                        position: {
//                            my: 'right center',
//                            at: 'left center',
//                            viewport: $(window),
//                            adjust: {
//                                method: 'flip none'
//                            }
//                        },
//                        show: {
//                            solo: true,
//                            delay: 500
//                        },
//                        hide: {
//                            fixed: true,
//                            delay: 300
//                            //,event: 'click'
//                        },
//                        style: {
//                            classes: 'zee-carousel-tooltip',
//                            tip: {
//                                width: 15,
//                                height: 6,
//                                border: 0
//                            }
//                        },
//                        events: {
//                            show: function () {
//                                $(this).find('.item-details').shorten({
//                                    showChars: '100',
//                                    moreText: '...'
//                                });
//                            }
//                        }
//                    });

//                });
//            };
//            var md = new MobileDetect(window.navigator.userAgent);
//            if (md.mobile()) {
//                justloadItems.addClass('carousel-mobile-device');
//            }
//            else {
//                var addClass = justloadItems.addClass('carousel-desktop-device');
//            };

//            // carousel helpers on mobile devices
//            $('.zee-carousel-item').on('touchstart pointerdown', function () {
//                var ts = $(this);
//                $('.zee-carousel-item').removeClass('hover');
//                ts.toggleClass('hover');
//            });
//        }
//    });


//});