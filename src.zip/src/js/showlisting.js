﻿"use strict";

var resizeTimer = 200;

var responsive = {
    0: {
        items: 1,
        nav: false,
        mouseDrag: true
    },
    479: {
        items: 2,
        nav: false,
        mouseDrag: true
    },
    760: {
        items: 2
    },
    950: {
        items: 3
    },
    1140: {
        items: 3
    },
    1520: {
        items: 3
    },
    1710: {
        items: 4
    },
    1900: {
        items: 4
    },
    2090: {
        items: 5
    },
    2280: {
        items: 5
    },
    2470: {
        items: 6
    },
    2660: {
        items: 6
    },
    2850: {
        items: 7
    },
    3040: {
        items: 7
    },
    3230: {
        items: 8
    },
    3420: {
        items: 8
    },
    3610: {
        items: 9
    },
    3800: {
        items: 9
    },
    3990: {
        items: 10
    }
};


function onResize() {
   
    var noOfItems = -1;

    var containerSize = $(".container-fluid").width();

    $.each(responsive, function (breakpoint) {
        if (breakpoint <= containerSize && breakpoint > noOfItems) {
            noOfItems = Number(breakpoint);
        }
    });
    var itemsCount = responsive[noOfItems].items;

    var itemWidth = (containerSize - (itemsCount * 10) + 10) / itemsCount;
    $(".movies-grid-items").css("width", Number(itemWidth).toFixed(2));
    $(".movies-grid-items").css("margin-right", 10);
    $(".movies-grid-items:nth-child(" + itemsCount + "n)").css({ "margin-right": "0", "clear": "both" });

    

}

/* ng-infinite-scroll - v1.0.0 - 2013-02-23 */
var mod;

mod = angular.module('infinite-scroll', []);

mod.directive('infiniteScroll', [
  '$rootScope', '$window', '$timeout', function ($rootScope, $window, $timeout) {
      return {
          link: function (scope, elem, attrs) {
              var checkWhenEnabled, handler, scrollDistance, scrollEnabled;
              $window = angular.element($window);
              scrollDistance = 0;
              if (attrs.infiniteScrollDistance != null) {
                  scope.$watch(attrs.infiniteScrollDistance, function (value) {
                      return scrollDistance = parseInt(value, 10);
                  });
              }
              scrollEnabled = true;
              checkWhenEnabled = false;
              if (attrs.infiniteScrollDisabled != null) {
                  scope.$watch(attrs.infiniteScrollDisabled, function (value) {
                      scrollEnabled = !value;
                      if (scrollEnabled && checkWhenEnabled) {
                          checkWhenEnabled = false;
                          return handler();
                      }
                  });
              }
              handler = function () {
                  var elementBottom, remaining, shouldScroll, windowBottom;
                  windowBottom = $window.height() + $window.scrollTop();
                  elementBottom = elem.offset().top + elem.height();
                  remaining = elementBottom - windowBottom;
                  shouldScroll = remaining <= $window.height() * scrollDistance;
                  if (shouldScroll && scrollEnabled) {
                      if ($rootScope.$$phase) {
                          return scope.$eval(attrs.infiniteScroll);
                      } else {
                          return scope.$apply(attrs.infiniteScroll);
                      }
                  } else if (shouldScroll) {
                      return checkWhenEnabled = true;
                  }
              };
              $window.on('scroll', handler);
              scope.$on('$destroy', function () {
                  return $window.off('scroll', handler);
              });
              return $timeout((function () {
                  if (attrs.infiniteScrollImmediateCheck) {
                      if (scope.$eval(attrs.infiniteScrollImmediateCheck)) {
                          return handler();
                      }
                  } else {
                      return handler();
                  }
              }), 0);
          }
      };
  }
]);

var app = angular.module('shows', ['infinite-scroll']);

app.directive('qtip', ['$timeout', function ($timeout) {
    return {
        restrict: 'A',
        link: function (scope, element, attrs) {
            var jsonobj = {
                movieName: attrs.qtipAssetname,
                RunningTime: attrs.qtipRunningtime,
                HtmlContent: attrs.qtipDesc,
                Actors: attrs.qtipActors,
                YearRelease: attrs.qtipYear,
                Language: attrs.qtipLanguage,
                Genre: attrs.qtipGenre,
                url: attrs.qtipUrl,
                thumbnail: attrs.qtipThumbnail
            };

            var popUpTemplate = _.template("<div class='zee-carousel-tooltip-data'><div class='item-name'><h3><%= item.movieName %></h3><span>(<%= item.YearRelease %>)</span></div><div class='item-genre'><span><i class='icon icon-tag-2'></i><%=item.Genre %></span></div><ul class='item-info-list'><li><span class='item-language'><i class='icon icon-globe-1'></i><%=item.Language %></span></li><li><span class='item-length'><i class='icon icon-clock'></i><%= item.RunningTime %><sup>min</sup></span></li></ul><div class='item-cast'><span>cast :</span><%= item.Actors %>..</div><div class='item-details'><p><%= item.HtmlContent %></p></div><ul class='item-watch-now'><li><a href='<%= item.url %>' class='btn btn-primary'>Watch Now</a></li></ul></div>");

            $('.browse-item-image').Lazy({
                effect: 'slideIn',
                effectTime: 'slow'
            });

            element.qtip({
                id: false,
                content: {
                    text: popUpTemplate({ item: jsonobj }),
                    title: {
                        text: false,
                        button: false
                    }
                },
                position: {
                    my: 'right center',
                    at: 'left center',
                    viewport: $(window),
                    adjust: {
                        method: 'flip none'
                    }
                },
                show: {
                    solo: true,
                    delay: 500
                },
                hide: {
                    fixed: true,
                    delay: 300
                },
                style: {
                    classes: 'zee-carousel-tooltip',
                    tip: {
                        width: 15,
                        height: 6,
                        border: 1
                    }
                }, events: {
                    show: function () {
                        $(this).find('.item-details').shorten({
                            showChars: '100',
                            moreText: '...'
                        });
                    }
                }
            });

            // carousel helpers on mobile devices
            $timeout(function () {
                $('.zee-carousel-item, .zee-movies-grid > div > div.item').on('touchstart pointerdown', function () {
                    var ts = $(this);
                    $('.zee-carousel-item, .zee-movies-grid > div > div.item').removeClass('hover');
                    ts.toggleClass('hover');
                });
            }, 200);

        }
    };
}]);
app.service('zeeShowService', ['$http', '$q', function ($http, $q) {
    return {
        getShows: function (url, request, token) {

            var deferred = $q.defer();
            $http(
                { method: 'GET', data: request, url: 'json/getShows.js', cache: false, headers: { 'RequestVerificationToken': token } }
                ).success(function (data) {
                    deferred.resolve(data);
                }).error(function (error) {
                    deferred.reject(error);
                });
            return deferred.promise;
        }
    };
}
]);

app.factory('ShowList', ['$http', 'zeeShowService', '$timeout', '$window', function ($http, zeeShowService, $timeout, $window) {

    var showList = function () {
        this.items = [];
        this.busy = false;
        this.after = '';
        this.CurrentPage = 0;
        this.alphabetFilter = false;
        this.serviceTag = undefined;
        this.alphabetFilterSearch = undefined;
        this.genreFilter = undefined;
        this.languageFilter = undefined;
        this.searchText = undefined;
        this.complete = false;
        this.noResult = false;
    };

    showList.prototype.nextPage = function () {
        if (this.busy) return;
        this.busy = true;
        var that = this;
        var urlChannel = window.baseUrl + "getShows";
        var request = {
            "CurrentPage": this.CurrentPage,
            "AlphabetFilter": this.alphabetFilter,
            "ServiceTag": this.serviceTag,
            "GenreFilter": this.genreFilter,
            "Language": this.languageFilter,
            "SearchText": $window.searchText ? $window.searchText : this.alphabetFilter ? this.alphabetFilterSearch : this.searchText
        };
        zeeShowService.getShows(urlChannel, request, $('#antiForgeryToken').val())
            .then(function (data) {

                that.complete = data.length === 0;
                that.CurrentPage = that.CurrentPage + 1;

                var items = data;
                for (var i = 0; i < items.length; i++) {
                    that.items.push(items[i]);
                }

                that.busy = false;
                (self.COMSCORE && COMSCORE.beacon({ c1: "2", c2: "20072668" }));
                that.noResult = that.items.length === 0;

                $timeout(onResize, 50);
                

            });
    };

    return showList;
}]);

app.controller('ShowController',['$scope','ShowList', function ($scope, ShowList) {
    $scope.showList = new ShowList();

    $scope.filterByAlphabet = function (alphabet) {
        $scope.showList.noResult = false;
        $scope.showList.searchText = "";
        $scope.showList.CurrentPage = 0;
        $scope.showList.alphabetFilter = true;
        $scope.showList.alphabetFilterSearch = alphabet;
        $scope.showList.items = [];
        $scope.showList.nextPage();
    }


    $scope.filterByAttribute = function (alphabet) {
        $scope.showList.noResult = false;
      
        var language = $("#language").val();

        if (language !== "") {
            $scope.showList.languageFilter = $("#language").val();
        } else {
            $scope.showList.languageFilter = undefined;
        }

        $scope.showList.CurrentPage = 0;
        $scope.showList.items = [];

        if ($scope.showList.searchText && $scope.showList.searchText.length === 0) {
            $scope.showList.alphabetFilter = true;
            $scope.showList.alphabetFilterSearch = alphabet;
        } else {
            $scope.showList.alphabetFilter = false;
        }



        $scope.showList.nextPage();

    }
    var infopopUpTemplate = _.template("<div class='carousel-info-popup container'><div class='zee-carousel-tooltip-data row'><div class='item-thumbnail col-md-4 col-sm-3 col-xs-12'><img src='<%= item.thumbnail %>'></div><div class='item-text-wrapper col-md-8 col-sm-9 col-xs-12'><div class='item-name'><h3><%= item.movieName %></h3><span>(<%= item.YearRelease %>)</span></div><div class='item-genre'><span><%=item.Genre %></span></div><ul class='item-info-list'><li><span class='item-language'><%=item.Language %></span></li><li><span class='item-length'><%= item.RunningTime %><sup>min</sup></span></li></ul><div class='item-cast'><span>cast :</span><%= item.Actors %>..</div><div class='item-details'><p><%= item.HtmlContent %></p></div><ul class='item-watch-now'><li><a href='<%= item.url %>' class='item-watch-link'>Watch Now</a></li></ul></div></div></div>");

    $scope.showMobileInfo = function (data) {

        var jsonobj = {
            movieName: data.AssetName,
            RunningTime: data.ShowTime,
            HtmlContent: data.HtmlContent,
            Actors: data.Actors,
            YearRelease: data.YearRelease,
            Language: data.Language,
            Genre: data.Genre,
            url: data.qtipUrl,
            thumbnail: data.ImageUrl
        };

        $.magnificPopup.open({
            items: {
                src: infopopUpTemplate({ item: jsonobj }),
                type: 'inline'
            }
        });
    }



}]);



$(document).ready(function () {
    $(window).resize(onResize); //set th
});