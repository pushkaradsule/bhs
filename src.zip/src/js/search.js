﻿var searchModule = function () {
    "use strict";

    function onSelected($e, datum) {

        setTimeout(function () {
            if (datum.Url === null) {
                var form = document.getElementById("search-form");
                form.submit();
            }
            else {
                window.location.href = datum.Url;
            }

        }, 300);
    }
    function initSearch(id) {

        var engine = new Bloodhound({
            remote: '/search?q=%QUERY',
            datumTokenizer: function (d) {
                return d.Name;
            },

            queryTokenizer: Bloodhound.tokenizers.whitespace

        });

        var channels = new Bloodhound({
            remote: '/channels?q=%QUERY',
            datumTokenizer: function (d) {
                return d.Name;
            },
            queryTokenizer: Bloodhound.tokenizers.whitespace

        });

        var shows = new Bloodhound({
            remote: '/show-search?q=%QUERY',
            datumTokenizer: function (d) {
                return d.Name;
            },
            queryTokenizer: Bloodhound.tokenizers.whitespace

        });

        engine.initialize();
        channels.initialize();
        shows.initialize();

        $(id).typeahead(null,
                {
                    highlight: true,
                    displayKey: 'Name',
                    source: engine.ttAdapter(),
                    templates: {
                        header: '<h5 class="movie-name">Movies & Actors</h5>'
                    },
                    minLength: 3
                },
                {
                    highlight: true,
                    displayKey: 'Name',
                    source: channels.ttAdapter(),
                    templates: {
                        header: '<div class"clearfix" </div><h5 class="channel-name">Channels</h5>',
                        empty: [
                          ''
                        ].join('\n'),
                        suggestion: Handlebars.compile('<p style="width:150px;float:left;margin-bottom:5px;padding-top:3px;clear:both">{{Name}}  </p> <a style="clear:both" href="{{Url}}">Watch Now</a>')
                    },
                    minLength: 3
                },
                {
                    highlight: true,
                    displayKey: 'Name',
                    source: shows.ttAdapter(),
                    templates: {
                        header: '<h5 class="movie-name">TV Shows</h5>'
                    },
                    minLength: 3
                }).on('typeahead:selected', onSelected);
    }


    return {
        initSearch: initSearch
    }
}();