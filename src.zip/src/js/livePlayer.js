﻿"use strict";

angular.module("main").controller('Player', ['$scope', '$timeout', 'zeeEpgService', '$window', 'ngProgress', '$stateParams', 'channel', function ($scope, $timeout, zeeEpgService, $window, ngProgress, $stateParams, channel) {

    $scope.CurrentChannel = channel;
    $scope.CurrentEpgItem = {};
    ngProgress.complete();
    var baseUrl = $window.baseUrl;
    $scope.playerLoading = false;
    $scope.state = true;
    $scope.showError = false;

    var initPlayer = function () {
        zeeplayer.Initialise($scope.CurrentChannel, "zeeplayer", baseUrl);
    }
    if ($scope.CurrentChannel.IsSuccess) {
        initPlayer();

    } else {
        $scope.showError = true;
    }

    $timeout(function () {
        $("html, body").animate({ scrollTop: 0 }, "slow");
    }, 100);

}]).
    controller('nowPlayingLive', ['$stateParams', 'epgData', '$scope', '$rootScope', function ($stateParams, epgData, $scope, $rootScope) {
        $rootScope.$on('epgFresh', function () {
            $scope.ProgrammeName = epgData.list.current.Title;
        });

    }]).controller('nowPlayingCatchUp', ['$scope','$stateParams', 'epgData','channel', function ($scope,$stateParams, epgData, channel) {
        if (channel.EpgItem.Title) {
            $scope.ProgrammeName = channel.EpgItem.Title;
            $scope.ProgrammeDateTime = channel.EpgItem.StartDate;
        }
       
    }]).controller('channelInfo', ['$scope', '$stateParams', 'channel', '$timeout', function ($scope, $stateParams, channel, $timeout) {
        console.log('Channel');
        $scope.CurrentChannel = channel;

        var loadContent = function () {

            $('.zee-browse-header-utility > li > a').on('click', function () {
                $('.zee-browse-header-utility > li > a').removeClass('active');
                $(this).addClass('active');
            });

            $('.zee-player-overlay-items a').on('click', function () {
                $('.zee-player-options-items > li > a').removeClass('active');
                $('#zee_player_options_data').removeClass('show');
            });

            $('.zee-player-options-items > li > a').on('click', function () {

                // set active tab
                $('.zee-player-options-items > li > a').removeClass('active');
                $(this).addClass('active');

                $('#zee_player_options_data').addClass('show');

                // show tab
                var ths = $(this),
                    ths_tab = ths.data('tab');

                $('.zee-player-options-tab').removeClass('show-tab');
                $('#' + ths_tab).addClass('show-tab');


            });

            $('#zee_player_options_close').on('click', function () {
                $('.zee-player-options-items > li > a').removeClass('active');
                $('#zee_player_options_data').removeClass('show');
            });


            $('#player_options_episodes_carousel').owlCarousel({
                margin: 15,
                nav: true,
                baseClass: 'zee-carousel',
                themeClass: 'zee-carousel-theme',
                itemClass: 'zee-carousel-item',
                navText: ['&nbsp;', '&nbsp;'],
                responsive: {
                    0: {
                        items: 1,
                        nav: false,
                        mouseDrag: true
                    },
                    479: {
                        items: 2,
                        nav: false,
                        mouseDrag: true
                    },
                    760: {
                        items: 2
                    },
                    950: {
                        items: 3,
                        slideBy: 2
                    },
                    1140: {
                        items: 3,
                        slideBy: 2
                    },
                    1520: {
                        items: 3,
                        slideBy: 2
                    },
                    1710: {
                        items: 4,
                        slideBy: 3
                    },
                    1900: {
                        items: 4,
                        slideBy: 3
                    },
                    2090: {
                        items: 5,
                        slideBy: 4
                    },
                    2280: {
                        items: 5,
                        slideBy: 4
                    },
                    2470: {
                        items: 6,
                        slideBy: 5
                    },
                    2660: {
                        items: 6,
                        slideBy: 5
                    },
                    2850: {
                        items: 7,
                        slideBy: 6
                    },
                    3040: {
                        items: 7,
                        slideBy: 6
                    },
                    3230: {
                        items: 8,
                        slideBy: 7
                    },
                    3420: {
                        items: 8,
                        slideBy: 7
                    },
                    3610: {
                        items: 9,
                        slideBy: 8
                    },
                    3800: {
                        items: 9,
                        slideBy: 8
                    },
                    3990: {
                        items: 10,
                        slideBy: 9
                    }
                }
            });

            $('#play_upnext_circle').circleProgress({
                value: 1,
                size: 90,
                thickness: 3,
                fill: {
                    color: '#ffffff'
                },
                animation: {
                    duration: 10000
                }

            }).on('circle-animation-end', function () {

            });
        };

        $timeout(loadContent, 500);

        

    }]).
    controller('channelControls', ['$scope', '$timeout', 'zeeEpgService', '$window', 'ngProgress', '$stateParams', 'channel', '$state', 'allChannels', 'epgData', function ($scope, $timeout, zeeEpgService, $window, ngProgress, $stateParams, channel, $state, allChannels, epgData) {
      
        $scope.CurrentChannel = channel;
        $scope.CurrentEpgItem = {};
        $scope.msInDay = 86400000;
        $scope.allChannels = [];
        $scope.now = new Date();
        var baseUrl = $window.baseUrl;
        $scope.EpgItems = [];
        $scope.playerInfo = {};
        $scope.todayBoD = new Date($scope.now.getFullYear(), $scope.now.getMonth(), $scope.now.getDate());
        $scope.todayBoD.setTime($scope.todayBoD.getTime() + 1000);
        $scope.todayBoD = (new Date($scope.todayBoD));
        $scope.playerLoading = false;
        $scope.state = true;

        $scope.getEoD = function (date) {
            var result = new Date(date);
            result.setTime(result.getTime() + $scope.msInDay - 2000);
            return new Date(result);
        };


        $scope.isEpgItemOnNow = function (epgItem) {
            var start = Date.parse(epgItem.StartDate);
            var end = Date.parse(epgItem.EndDate);
            var result = (start <= $scope.now) && ($scope.now <= end);
            epgItem.IsPlayingNow = result;
            epgItem.IsCatchUp = $scope.isPastEpgItem(epgItem);

            return result;
        }

        $scope.goBack = function () {
            $window.history.back();
        }

        $scope.isPastEpgItem = function (epgItem) {
            var end = new Date(epgItem.EndDate);
            return (end <= $scope.now);
        }

        $scope.epgItemProgress = function (epgItem) {
            var result = 0;
            if ($scope.isEpgItemOnNow(epgItem)) {
                var start = Date.parse(epgItem.StartDate);
                var end = Date.parse(epgItem.EndDate);
                result = (($scope.now - start) / (end - start));
            }
            return result;
        }

        function getChannelInfo(d) {
            
            var date = $scope.todayBoD;

            if (d) {
                date = new Date(d);
            }


            $scope.allChannels = allChannels;
            var loadChannelList = function () {
                var liveCarousel = $('#zee_live_carousel_channels');

                liveCarousel.owlCarousel({
                    margin: 10,
                    nav: true,
                    dots: false,
                    pullDrag: true,
                    loop: false,
                    autoWidth: true,
                    navText: ['&#x2190;', '&#x2192;'],
                    responsiveClass: true,
                    mouseDrag: true,
                    responsive: {
                        0: {
                            nav: false
                        },
                        768: {
                            nav: false
                        },
                        992: {
                            nav: true
                        }
                    }
                });
            };

            $timeout(loadChannelList, 500);
            console.log($scope.CurrentChannel.IsSuccess);
            if ($scope.CurrentChannel.IsSuccess) {
                var request = {
                    "TimeStart": date.toISOString(),
                    "TimeEnd": $scope.getEoD(date).toISOString(),
                    "ChannelIDs": $scope.CurrentChannel.EpgItem.i
                };
                
                zeeEpgService.getEpg(baseUrl, request, $('#antiForgeryToken').val())
                    .then(function (data) {
                        $scope.EpgItems = data;



                        var queryResult = Enumerable.from(data)
                                       .where(function (x) {
                                           return $scope.now <= Date.parse(x.EndDate);
                                       })
                                       .toArray();

                        $scope.EpgItems = data;



                        if (queryResult.length > 0) {

                            var catchUpIndex = data.indexOf(queryResult[0]);
                            epgData.setEpgData({ current: queryResult[0], next: queryResult[1], catchUp: catchUpIndex > 0 ? data[catchUpIndex - 1] : {} });
                        }


                        var loadEpgList = function () {

                            var liveCarousel = $('#zee_live_carousel_programs');


                            liveCarousel.owlCarousel({
                                margin: 10,
                                nav: true,
                                dots: false,
                                pullDrag: true,
                                loop: false,
                                autoWidth: true,
                                navText: ['&#x2190;', '&#x2192;'],
                                responsiveClass: true,
                                mouseDrag: true,
                                responsive: {
                                    0: {
                                        nav: false
                                    },
                                    768: {
                                        nav: false
                                    },
                                    992: {
                                        nav: true
                                    }
                                }
                            });


                        }

                        $timeout(loadEpgList, 1000);


                    });
            }

            $scope.watchContent = function (epgItem) {

                $state.go('catchup', { 'epgItemId': epgItem.EpgItemId, 'lang': $stateParams.lang, 'channelName': $stateParams.channelName });

                $scope.playerLoading = true;
            }
            $scope.playChannel = function (channel) {
                $state.go('live', { 'channelId': channel.Id, 'lang': $stateParams.lang, 'channelName': channel.ShortName });
                $scope.playerLoading = true;

            }
            $scope.openEpgGuide = function ($event) {

                $event.preventDefault();

                var ts = $("#zee_live_programs"),
                    tsUl = ts.parents('ul'),
                    tsLi = ts.parent(),
                    tsCarousel = tsLi.find('.zee-live-carousel');

                $('.zee-live-helper > ul > li.zee-live-all-channels, .zee-live-helper > ul > li.zee-live-all-channels > div.zee-live-carousel').removeClass('open');
                tsUl.removeClass('channels-open');
                $('.zee-live-all-channels').find('.action-url').removeClass('channel-arrow');

                $timeout(function () {
                    tsUl.toggleClass('program-open');
                    tsLi.toggleClass('open');
                    tsCarousel.toggleClass('open');
                    setTimeout(function () {
                        ts.toggleClass('program-arrow');
                    }, 200);
                }, 300);
            }

            $scope.openChannels = function ($event) {

                $event.preventDefault();

                var ts = $("#zee_live_channels"),
                    tsUl = ts.parents('ul'),
                    tsLi = ts.parent(),
                    tsCarousel = tsLi.find('.zee-live-carousel');

                $('.zee-live-helper > ul > li.zee-live-show-guide, .zee-live-helper > ul > li.zee-live-show-guide > div.zee-live-carousel').removeClass('open');
                tsUl.removeClass('program-open');
                $('.zee-live-show-guide').find('.action-url').removeClass('program-arrow');

                setTimeout(function () {
                    tsUl.toggleClass('channels-open');
                    tsLi.toggleClass('open');
                    tsCarousel.toggleClass('open');
                    setTimeout(function () {
                        ts.toggleClass('channel-arrow');
                    }, 200);
                }, 300);


            }
        }


        getChannelInfo();


    }]);

