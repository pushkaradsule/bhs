﻿;
(function($) {

    "use strict";

    $(document).ready(function () {

        $('a.offerhelp').each(function () {
            var $helpcontent = $(this).data('help');
            $(this).qtip({
                content: {
                    text: $helpcontent
                },
                position: {
                    my: 'bottom left',
                    at: 'top right'
                },
                style: {
                    classes: 'offer-tooltop',
                    tip: {
                        corner: 'bottom left',
                        border: 1,
                        width: 16,
                        height: 10,
                        offset: 5
                    }
                },
                hide: {
                    event: 'unfocus'
                },
                show: {
                    solo: true
                }
            });
        });

    }); // document.ready

})(jQuery);