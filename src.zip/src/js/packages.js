;
(function ($) {

    "use strict";
    function packageInit() {
        // console.log("ready!");
        var monthly = $("#monthly");
        var threeMonth = $("#threemonth");
        var sixmonth = $("#sixmonth");
        var yearly = $("#yearly");


        var countChecked = function () {

            var termValuem2M = 0;
            var termValueQuater = 0;
            var termValueHalf = 0;
            var termValueYear = 0;
            var options;
            var culturecode;
            var n = $("input[type=checkbox]:checked").each(function () {

                var currentItem = $(this);
                // console.log(currentItem.data("currencycode"));
                options = { style: "currency", minimumFractionDigits: 2, currency: currentItem.data("currencycode") };

                culturecode = currentItem.data("culturecode");
                var termPrice = currentItem.data("price");


                termValuem2M = _.findWhere(termPrice, { BillingTermShortCode: 'M2M' }).Price + termValuem2M;
                termValueQuater = _.findWhere(termPrice, { BillingTermShortCode: 'QUARTER' }).Price + termValueQuater;
                termValueHalf = _.findWhere(termPrice, { BillingTermShortCode: 'HALF-YEAR' }).Price + termValueHalf;
                termValueYear = _.findWhere(termPrice, { BillingTermShortCode: 'YEAR' }).Price + termValueYear;


            });


            monthly.text(new Intl.NumberFormat(undefined, options).format(termValuem2M));
            threeMonth.text(new Intl.NumberFormat(undefined, options).format(termValueQuater));
            sixmonth.text(new Intl.NumberFormat(undefined, options).format(termValueHalf));
            yearly.text(new Intl.NumberFormat(undefined, options).format(termValueYear));

            $("#header-cost-monthly").text("Your total monthly package price: " + monthly.text());
        };

        countChecked();

        $('.zee-package-checkbox').on('ifChanged', countChecked);

        $('button[name=Term]').click(function () {


            $(".zee-package-pricing-table").each(function () {
                $(this).removeClass('zee-package-popular');
            });

            var nameofCheckBox = $(this).val();

            $("#selectTerm").val(nameofCheckBox);

            $(this).parent().addClass("zee-package-popular");
        });


        $("#btnNext").click(function () {
            if ($("[name='SelectedGroups']:checked").length === 0 && $("#selectTerm").val() === "") {
                swal("Please select a package and payment plan.");
                return;
            }

            if ($("[name='SelectedGroups']:checked").length === 0) {
                swal("Please select a package.");
                return;
            }

            if ($("#selectTerm").val() === "") {
                swal("Please select a payment plan.");
                return;
            }

            var form = document.getElementById("addpackageform");
            form.submit();

        });

        var selectSelectedPackage = function () {

            $(".zee-package-pricing-table").each(function () {
                $(this).removeClass('zee-package-popular');
            });

            var nameofTerm = $("#selectTerm").val();
            if (nameofTerm) {
                $("#" + nameofTerm).addClass("zee-package-popular");
            }
        }

        selectSelectedPackage();


    }

    $(document).ready(function () {

        $('.zee-package-checkbox').iCheck({
            checkboxClass: 'icheckbox_flat-blue'
        });

        function updateSelectedCount() {
            if ($('.zee-package-checkbox:checked').length < 10) {
                $('#zee_package_active_count').find('span > a').html('0' + $('.zee-package-checkbox:checked').length);
            }
            else {
                $('#zee_package_active_count').find('span > a').html($('.zee-package-checkbox:checked').length);
            }

            $('#zee_package_active_count').removeClass().addClass('bounceIn animated').one('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend', function () {
                $(this).removeClass();
            });
        }

        if ($('.zee-package-checkbox:checked').length === 0) {

            $('#package_ZEE_Family_Gold').iCheck('check', function () {
                $('#package_ZEE_Family_Gold').parents('li').addClass('selected-package');
                updateSelectedCount();
            });

        };

        $('.zee-package-checkbox').each(function () {
            if ($(this).is(':checked')) {
                $(this).parents('li').addClass('selected-package');
            }
        });

        updateSelectedCount();

        $('.zee-package-checkbox').on('ifChecked', function (event) {
            $(this).parents('li').addClass('selected-package');
        });

        $('.zee-package-checkbox').on('ifUnchecked', function (event) {

            $(this).parents('li').removeClass('selected-package');

            setTimeout(function () {
                if ($('.zee-package-checkbox:checked').length == 0) {

                    $('#package_ZEE_Family_Gold').iCheck('check', function () {
                        $('#zee_package_active_count').find('span > a').html('01');
                    });
                }
            }, 10);

        });

        $('.zee-package-checkbox').on('ifChanged', function (event) {

            updateSelectedCount();

        });

        $('.zee-package-pricing-row').waypoint(function (direction) {
            if (direction === 'down') {
                $('body').addClass('hide-package-bubble');
            }
            else {
                $('body').removeClass('hide-package-bubble');
            }
        }, {
            offset: function () {
                return $(this).height() + 200;
            }
        });

        $('#selected_package_goto_table').on('click', function (e) {
            e.preventDefault();
            $('html, body').animate({
                scrollTop: $('#package_pricing_seperator').offset().top - 50
            }, 2000);
        });

        packageInit();

    }); // document.ready

})(jQuery);


