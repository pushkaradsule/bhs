;
(function ($) {

    "use strict";

    $(document).ready(function () {


        $.material.init();
        $.material.ripples();
        //$.material.checkbox();


        $(".mega-epg-cycle").responsiveSlides({
            auto: true,
            timeout: 6000,
            pause: true,
            pager: true
        });

        window.jRes.addFunc({
            breakpoint: ['tablet', 'laptop', 'desktop'],
            enter: function () {
                $('.managesubs-review').matchHeight();
            },
            exit: function () {
            }
        });

        // poster grid match height
        // for portraits
        /*
        move to movie/show and search result js files
        $('.portrait-grid-container .grid-item').matchHeight({
            byRow: true,
            property: 'height'
        });
        */

        function onSelected($e, datum) {

            setTimeout(function () {
                if (datum.Url === null) {
                    var form = document.getElementById("search-form");
                    form.submit();

                }
                else {
                    window.location.href = datum.Url;
                }

            }, 500);
        }

        $("#submitContactQuery").click(function () {

            var $this = $(this);
            var alreadyClicked = $this.data('clicked');
            if (alreadyClicked) {
                return false;
            }

            $this.data('clicked', true);

            var reasonCode = $("#reasonCode").val();

            var email = $("#contact-Email").val();

            var comments = $("#comments").val();

            $('#contact_form_result').fadeToggle(function () {
                $('#contact_form_wrapper').fadeToggle();
            });

            $.ajax({
                url: '/contactInfo',
                type: 'post',
                data: { ReasonCode: reasonCode, Email: email, Comments: comments },
                dataType: 'json',
                success: function () {
                    window.ga('send', 'event', { eventCategory: 'Contact Us', eventAction: 'Click', eventLabel: 'Completion', eventValue: 2 });

                    $("#reasonCode").val("");
                    $("#contact-Email").val("");
                    $("#comments").val("");



                }
            });
            return false;
        });

        function initSearch(id) {

            var engine = new Bloodhound({
                remote: '/json/search.js?q=%QUERY',
                datumTokenizer: function (d) {
                    return d.Name;
                },

                queryTokenizer: Bloodhound.tokenizers.whitespace

            });

            var channels = new Bloodhound({
                remote: '/json/channels.js?q=%QUERY',
                datumTokenizer: function (d) {
                    return d.Name;
                },
                queryTokenizer: Bloodhound.tokenizers.whitespace

            });

            var shows = new Bloodhound({
                remote: '/json/shows.js?q=%QUERY',
                datumTokenizer: function (d) {
                    return d.Name;
                },
                queryTokenizer: Bloodhound.tokenizers.whitespace

            });

            engine.initialize();
            channels.initialize();
            shows.initialize();

            $(id).typeahead(null,
                    {
                        highlight: true,
                        displayKey: 'Name',
                        source: engine.ttAdapter(),
                        templates: {
                            header: '<div class="clearfix"></div><h5 class="search-suggestion-header movie-name">Movies & Actors</h5>',
                            suggestion: Handlebars.compile('<p class="search-suggestion-content">{{Name}}</p>')
                        },
                        minLength: 3
                    },
                    {
                        highlight: true,
                        displayKey: 'Name',
                        source: channels.ttAdapter(),
                        templates: {
                            header: '<h5 class="search-suggestion-header search-channel-name">Channels</h5>',
                            empty: [
                              ''
                            ].join('\n'),
                            suggestion: Handlebars.compile('<p class="search-suggestion-content">{{Name}} <a href="{{Url}}" class="search-suggestion-watchnow"><i class="icon icon-play-circled"></i> Watch Now</a></p>')
                        },
                        minLength: 0
                    },
                    {
                        highlight: true,
                        displayKey: 'Name',
                        source: shows.ttAdapter(),
                        templates: {
                            header: '<h5 class="search-suggestion-header search-movie-name">TV Shows</h5>',
                            suggestion: Handlebars.compile('<p class="search-suggestion-content">{{Name}}</p>')
                        },
                        minLength: 3
                    }).on('typeahead:selected', onSelected);
        }
        //mobile detection variable
        var md = new MobileDetect(window.navigator.userAgent);
        if (md.mobile()) {
            $('body').addClass('mobile-wrapper');
        }
        else {
            $('body').addClass('desktop-wrapper');
        }


        window.jRes.addFunc({
            breakpoint: ['tablet', 'laptop', 'desktop'],
            enter: function () {
                $('.zee-mobile-search-form').removeClass('show');
                $('.zee-blur-overlay').removeClass('show');
                $('.zee-mobile-signup-buttons').fadeOut('fast');
                $('body').removeClass('overlay-blur');
            },
            exit: function () {
            }
        });

        $('.zee-toolbar-search input[type="text"]').on('focus', function () {

            $(this).parents('.zee-toolbar-search').removeClass('blur').addClass('focus');

        });

        $('.zee-toolbar-search input[type="text"]').on('blur', function () {

            $(this).parents('.zee-toolbar-search').removeClass('focus').addClass('blur');

        });


        $('#zee_toolbar_menu').on('click', function (e) {
            if (!md.mobile()) {
                e.preventDefault();
            }
        });

        // launch mobile search field
        $('#search_mobile_btn').on('click', function (e) {
            e.preventDefault();
            $('.zee-mobile-search-form').addClass('show');
            $('.zee-mobile-search-form').find('input[type="search"]').focus();
        });

        // close mobile search field
        $('#zee_mobile_search_close').on('click', function (e) {
            e.preventDefault();
            $('.zee-mobile-search-form').removeClass('show');
        });

        // launch signup action popup
        $('#zee_mobile_signiup_btn').on('click', function (e) {
            e.preventDefault();
            $('.zee-blur-overlay').addClass('show');
            $('.zee-mobile-signup-buttons').fadeIn('slow');
            $('body').addClass('overlay-blur');
        });

        // signup popup close action
        $('#signup_close_btn').on('click', function (e) {
            e.preventDefault();

            $('.zee-mobile-signup-buttons').fadeOut('slow', function () {
                $('.zee-blur-overlay').removeClass('show');
                $('body').removeClass('overlay-blur');
            });
        });

        // change toolbar background
        var zee_header_wrapper = $('.zee-header-wrapper'),
            zee_toolbar = $('.zee-toolbar'),
            zee_toolbar_compact = zee_toolbar.data('compact');

        if (zee_toolbar_compact == '1') {
            setTimeout(function () {
                $('.page-with-banner .zee-content-wrapper').waypoint(function (direction) {
                    if (direction === 'down') {
                        $('body').addClass('zee-toolbar-compact');
                    } else {
                        $('body').removeClass('zee-toolbar-compact');
                    }
                }, {
                    offset: 150
                });
            }, 500);
        };





        // change toolbar size


        // browse menu
        if (md.mobile()) {
            // event on touch devices
            $('#zee_toolbar_menu').on('touchstart pointerdown', function () {
                $('.zee-toolbar-user').removeClass('show');
                $(this).parents('.zee-toolbar-menu').toggleClass('show');
            });
        }
        else {
            // event on desktop
            $('.zee-toolbar-menu').on('mouseenter', function () {
                $(this).addClass('show');
            });
            $('.zee-toolbar-menu').on('mouseleave', function () {
                $(this).removeClass('show');
            });
        };

        // browse menu hover effect on touch devices
        if (md.mobile()) {
            $('.dropdown-menu li a').on('touchstart pointerdown', function () {
                $(this).addClass('hover');
            });
            $('.dropdown-menu li a').on('touchend pointerup', function () {
                $(this).removeClass('hover');
            });
        };

        // user menu
        if (md.mobile()) {
            // event on touch devices
            $('#zee_user_menu').on('touchstart pointerdown', function () {
                $('.zee-toolbar-menu').removeClass('show');
                $(this).parents('.zee-toolbar-user').toggleClass('show');
            });
        }
        else {
            // event on desktop
            $('.zee-toolbar-user').on('mouseenter', function () {
                $(this).addClass('show');
            });
            $('.zee-toolbar-user').on('mouseleave', function () {
                $(this).removeClass('show');
            });
        };

        // mobile menu
        $('#zee_mobile_menu_trigger').on('click', function (e) {

            e.preventDefault();

            $('.zee-mobile-menu').addClass('active');
            $('.zee-mobile-menu-overlay').addClass('active');

            $('body, .zee-body-wrapper').addClass('mobile-menu-open');

        });

        $('#zee_mobile_menu_close').on('click', function (e) {

            e.preventDefault();

            $('.zee-mobile-menu').removeClass('active');
            $('.zee-mobile-menu-overlay').removeClass('active');
            $('body, .zee-body-wrapper').removeClass('mobile-menu-open');
        });

        // home banner
        imagesLoaded('#zee_main_banner > li:first-child', function () {
            $('#zee_main_banner').pgwSlider({
                adaptiveHeight: true,
                displayList: false,
                autoSlide: true,
                displayControls: true,
                intervalDuration: $('#zee_main_banner').data('duration'),
                beforeSlide: function () {
                    $('.pgwSlider').removeClass('slide-active');
                },
                afterSlide: function () {
                    $('.pgwSlider').addClass('slide-active');
                    $.waypoints('refresh');
                }
            });
            setTimeout(function () {
                $('.zee-main-banner').removeClass('min-height');
            }, 400);
        });

        // zee carousel
        $('.zee-carousel-data').owlCarousel({
            margin: 10,
            nav: true,
            dots: false,
            lazyLoad: true,
            loop: false,
            baseClass: 'zee-carousel',
            themeClass: 'zee-carousel-theme',
            itemClass: 'zee-carousel-item',
            navText: ['&nbsp;', '&nbsp;'],
            responsiveClass: true,
            mouseDrag: false,
            responsive: {
                0: {
                    items: 3,
                    nav: false,
                    mouseDrag: true
                },
                479: {
                    items: 4,
                    nav: false,
                    mouseDrag: true
                },
                760: {
                    items: 5
                },
                950: {
                    items: 6
                },
                1140: {
                    items: 7
                },
                1520: {
                    items: 8
                },
                1710: {
                    items: 9
                },
                1900: {
                    items: 10
                },
                2090: {
                    items: 11
                },
                2280: {
                    items: 12
                },
                2470: {
                    items: 13
                },
                2660: {
                    items: 14
                },
                2850: {
                    items: 15
                },
                3040: {
                    items: 16
                },
                3230: {
                    items: 17
                },
                3420: {
                    items: 18
                },
                3610: {
                    items: 19
                },
                3800: {
                    items: 20
                },
                3990: {
                    items: 21
                }
            }
        });


        if (md.mobile()) {

            $('.zee-carousel-data').addClass('carousel-mobile-device');
        }
        else {

            $('.zee-carousel-data').addClass('carousel-desktop-device');
        };

        // 
        $('.zee-carousel-epglive').owlCarousel({
            margin: 25,
            loop: false,
            autoWidth: true,
            mouseDrag: true,
            nav: true,
            dots: false,
            baseClass: 'zee-carousel',
            themeClass: 'zee-carousel-theme',
            itemClass: 'zee-carousel-item',
            navText: ['<i class="icon icon-left-open-big"></i>', '<i class="icon icon-right-open-big"></i>'],
            responsive: {
                0: {
                    nav: false
                },
                760: {
                    nav: true
                }
            }
        });

        // all channels craousel in liveplayer
        $('.zee-carousel-allchannels').owlCarousel({
            margin: 10,
            nav: true,
            dots: false,
            lazyLoad: false,
            loop: false,
            baseClass: 'zee-carousel',
            themeClass: 'zee-carousel-theme',
            itemClass: 'zee-carousel-item',
            navText: ['<i class="icon icon-left-open-big"></i>', '<i class="icon icon-right-open-big"></i>'],
            responsiveClass: true,
            mouseDrag: false,
            responsive: {
                0: {
                    items: 2,
                    nav: false,
                    mouseDrag: true
                },
                479: {
                    items: 4,
                    nav: false,
                    mouseDrag: true
                },
                760: {
                    items: 5
                },
                950: {
                    items: 6
                },
                1140: {
                    items: 8
                },
                1520: {
                    items: 9
                },
                1710: {
                    items: 10
                },
                1900: {
                    items: 11
                },
                2090: {
                    items: 12
                },
                2280: {
                    items: 13
                },
                2470: {
                    items: 14
                },
                2660: {
                    items: 15
                },
                2850: {
                    items: 16
                },
                3040: {
                    items: 17
                },
                3230: {
                    items: 18
                },
                3420: {
                    items: 19
                },
                3610: {
                    items: 20
                },
                3800: {
                    items: 21
                },
                3990: {
                    items: 22
                }
            }
        });


        if (md.mobile()) {

            $('.zee-carousel-allchannels').addClass('carousel-mobile-device');
        }
        else {

            $('.zee-carousel-allchannels').addClass('carousel-desktop-device');
        };


        // zee portrait carousel
        $('.zee-carousel-portrait').owlCarousel({
            margin: 10,
            nav: true,
            dots: false,
            lazyLoad: true,
            loop: false,
            baseClass: 'zee-carousel',
            themeClass: 'zee-carousel-theme',
            itemClass: 'zee-carousel-item',
            navText: ['&nbsp;', '&nbsp;'],
            responsiveClass: true,
            mouseDrag: false,
            responsive: {
                0: {
                    items: 3,
                    nav: false,
                    mouseDrag: true
                },
                479: {
                    items: 4,
                    nav: false,
                    mouseDrag: true
                },
                760: {
                    items: 5
                },
                950: {
                    items: 6
                },
                1140: {
                    items: 7
                },
                1520: {
                    items: 8
                },
                1710: {
                    items: 9
                },
                1900: {
                    items: 10
                },
                2090: {
                    items: 11
                },
                2280: {
                    items: 12
                },
                2470: {
                    items: 13
                },
                2660: {
                    items: 14
                },
                2850: {
                    items: 15
                },
                3040: {
                    items: 16
                },
                3230: {
                    items: 17
                },
                3420: {
                    items: 18
                },
                3610: {
                    items: 19
                },
                3800: {
                    items: 20
                },
                3990: {
                    items: 21
                }
            }
        });


        if (md.mobile()) {

            $('.zee-carousel-portrait').addClass('carousel-mobile-device');
        }
        else {

            $('.zee-carousel-portrait').addClass('carousel-desktop-device');
        };

        // zee similar movies carousel
        $('.zee-carousel-similar-movies').owlCarousel({
            margin: 10,
            nav: true,
            dots: false,
            lazyLoad: false,
            loop: false,
            baseClass: 'zee-carousel',
            themeClass: 'zee-carousel-theme',
            itemClass: 'zee-carousel-item',
            navText: ['<i class="icon icon-left-open-big"></i>', '<i class="icon icon-right-open-big"></i>'],
            responsiveClass: true,
            mouseDrag: false,
            responsive: {
                0: {
                    items: 3,
                    nav: false,
                    mouseDrag: true
                },
                479: {
                    items: 4,
                    nav: false,
                    mouseDrag: true
                },
                760: {
                    items: 7
                },
                950: {
                    items: 8
                },
                1140: {
                    items: 9
                },
                1520: {
                    items: 11
                },
                1710: {
                    items: 12
                },
                1900: {
                    items: 13
                },
                2090: {
                    items: 14
                },
                2280: {
                    items: 15
                },
                2470: {
                    items: 16
                },
                2660: {
                    items: 17
                },
                2850: {
                    items: 18
                },
                3040: {
                    items: 19
                },
                3230: {
                    items: 20
                },
                3420: {
                    items: 21
                },
                3610: {
                    items: 22
                },
                3800: {
                    items: 23
                },
                3990: {
                    items: 24
                }
            }
        });


        if (md.mobile()) {

            $('.zee-carousel-portrait').addClass('carousel-mobile-device');
        }
        else {

            $('.zee-carousel-portrait').addClass('carousel-desktop-device');
        };

        // zee landscape carousel
        $('.zee-carousel-landscape').owlCarousel({
            margin: 10,
            nav: true,
            dots: false,
            lazyLoad: true,
            loop: false,
            baseClass: 'zee-carousel',
            themeClass: 'zee-carousel-theme',
            itemClass: 'zee-carousel-item',
            navText: ['&nbsp;', '&nbsp;'],
            responsiveClass: true,
            mouseDrag: false,
            responsive: {
                0: {
                    items: 1,
                    nav: false,
                    mouseDrag: true
                },
                479: {
                    items: 2,
                    nav: false,
                    mouseDrag: true
                },
                760: {
                    items: 2
                },
                950: {
                    items: 3
                },
                1140: {
                    items: 3
                },
                1520: {
                    items: 3
                },
                1710: {
                    items: 4
                },
                1900: {
                    items: 4
                },
                2090: {
                    items: 5
                },
                2280: {
                    items: 5
                },
                2470: {
                    items: 6
                },
                2660: {
                    items: 6
                },
                2850: {
                    items: 7
                },
                3040: {
                    items: 7
                },
                3230: {
                    items: 8
                },
                3420: {
                    items: 8
                },
                3610: {
                    items: 9
                },
                3800: {
                    items: 9
                },
                3990: {
                    items: 10
                }
            }
        });


        if (md.mobile()) {

            $('.zee-carousel-landscape').addClass('carousel-mobile-device');
        }
        else {

            $('.zee-carousel-landscape').addClass('carousel-desktop-device');
        };

        // zee mix carousel
        $('.zee-carousel-mix').owlCarousel({
            margin: 10,
            nav: true,
            dots: false,
            lazyLoad: true,
            loop: true,
            baseClass: 'zee-carousel',
            themeClass: 'zee-carousel-theme',
            itemClass: 'zee-carousel-item',
            navText: ['&nbsp;', '&nbsp;'],
            responsiveClass: true,
            mouseDrag: false,
            autoWidth: true,
            items: 7,
            responsive: {
                0: {
                    nav: false
                },
                760: {
                    nav: true
                }
            }
        });


        if (md.mobile()) {

            $('.zee-carousel-mix').addClass('carousel-mobile-device');
        }
        else {

            $('.zee-carousel-mix').addClass('carousel-desktop-device');
        };


        $('.zee-carousel-item, .poster-grid-container > div > div.item').on("touchstart tap pointerdown", function () {
            var ts = $(this);
            $('.zee-carousel-item').removeClass('hover');
            $('.poster-grid-container > div > div.item').removeClass('hover');
            ts.toggleClass('hover');
        });
        //// carousel helpers on mobile devices
        //$('.zee-carousel-item, .zee-movies-grid > div > div.item').on('touchstart tap pointerdown', function () {
        //    console.log('click');
        //    var ts = $(this);
        //    $('.zee-carousel-item, .zee-movies-grid > div > div.item').removeClass('hover');
        //    ts.toggleClass('hover');
        //});

        // show tooltip for thumbnails
        var $carouselThumb = $('.carousel-thumb-action-tooltip');
        if ($carouselThumb.length) {
            $carouselThumb.each(function () {

                var tsQtip = $(this);

                var jsonobj = {
                    movieName: tsQtip.data('assetname'),
                    RunningTime: tsQtip.data('runningtime'),
                    HtmlContent: tsQtip.data('desc'),
                    Actors: tsQtip.data('actors'),
                    YearRelease: tsQtip.data('year'),
                    Language: tsQtip.data('language'),
                    Genre: tsQtip.data('genre'),
                    url: tsQtip.data('url'),
                    favourite_txt: (tsQtip.data('favourite') === '1' ? 'in watchlist' : 'add to watchlist'),
                    favourite_class: (tsQtip.data('favourite') === '1' ? ' added' : '')
                };

                var popUpTemplate = _.template("<div class='zee-carousel-tooltip-data'><div class='item-name'><h3><%= item.movieName %></h3><span>(<%= item.YearRelease %>)</span></div><div class='item-genre'><span><%=item.Genre %></span></div><ul class='item-info-list'><li><span class='item-language'><%=item.Language %></span></li><li><span class='item-length'><%= item.RunningTime %><sup>min</sup></span></li></ul><div class='item-cast'><span>cast :</span><%= item.Actors %>..</div><div class='item-details'><p><%= item.HtmlContent %></p></div><ul class='item-watch-now'><li><a href='<%= item.url %>' class='item-watch-link'>Watch Now</a></li></ul></div>");

                tsQtip.qtip({
                    id: false,
                    content: {
                        text: popUpTemplate({ item: jsonobj }),
                        title: {
                            text: false,
                            button: false
                        }
                    },
                    position: {
                        my: 'right center',
                        at: 'left center',
                        viewport: $(window),
                        adjust: {
                            method: 'flip none'
                        }
                    },
                    show: {
                        solo: true,
                        delay: 500
                    },
                    hide: {
                        fixed: true,
                        delay: 300
                        //,event: 'click'
                    },
                    style: {
                        classes: 'zee-carousel-tooltip',
                        tip: {
                            width: 15,
                            height: 6,
                            border: 1
                        }
                    },
                    events: {
                        show: function () {

                            $(this).find('.item-details').shorten({
                                showChars: '100',
                                moreText: '...'
                            });
                        }
                    }
                });

            });
        };

        // show tooltip for channels
        var $carouselLive = $('.carousel-live-action');
        if ($carouselLive.length) {
            $carouselLive.each(function () {

                var tsQtip = $(this);

                var liveJsonobj = {
                    channelName: tsQtip.data('assetname'),
                    HtmlContent: tsQtip.data('desc'),
                    Language: tsQtip.data('language'),
                    Genre: tsQtip.data('genre'),
                    url: tsQtip.data('url'),
                    live: tsQtip.data('live'),
                    now: tsQtip.data('now'),
                    next: tsQtip.data('next'),
                    catchUpUrl: tsQtip.data('url-catchup')
                };

                var livepopUpTemplate = _.template("<div class='zee-carousel-tooltip-data'><div class='item-name'><h3><%= item.channelName %></h3></div>" +
                    "<div class='item-genre'><span><%=item.Genre %></span></div><ul class='item-info-list'><li>" +
                    "<span class='item-language'><%=item.Language %></span></li></ul><div class='item-details'><p><%= item.HtmlContent %>" +
                    "</p></div><div class='item-upnext'><ul><li><span><a class='catch-up-link' href='epg-guide'>CATCH UP</a></span><b class='catch-up'></b><div class='loading'><div class='loading-bar'></div><div class='loading-bar'></div><div class='loading-bar'></div><div class='loading-bar'></div><div class='loading-bar'></div></div></li><li><span>" +
                    "<a class='a-up-next' href='#'>UP NEXT</a></span><b class='up-next'></b><div class='loading'><div class='loading-bar'></div><div class='loading-bar'></div><div class='loading-bar'></div><div class='loading-bar'></div><div class='loading-bar'></div></div></li><li><span> <a href='<%= item.url %>'>ON NOW</a></span>" +
                    "<b class='on-now'></b><div class='loading'><div class='loading-bar'></div><div class='loading-bar'></div><div class='loading-bar'></div><div class='loading-bar'></div><div class='loading-bar'></div></div></li>" +
                    "</ul></div></div>");

                tsQtip.qtip({
                    id: false,
                    content: {
                        text: livepopUpTemplate({ item: liveJsonobj }),
                        title: {
                            text: false,
                            button: false
                        }
                    },
                    position: {
                        my: 'right center',
                        at: 'left center',
                        viewport: $(window),
                        adjust: {
                            method: 'flip none'
                        }
                    },
                    show: {
                        solo: true,
                        delay: 500
                    },
                    hide: {
                        fixed: true,
                        delay: 300
                        //,event: 'click'
                    },
                    style: {
                        classes: 'zee-carousel-tooltip',
                        tip: {
                            width: 15,
                            height: 6,
                            border: 1
                        }
                    },
                    events: {
                        show: function () {
                            var that = $(this);
                            var scope = angular.element($('#channelTray')).scope();
                            scope.getChannelInfo(null, tsQtip.data('assetid')).then(function (data) {
                                that.find('.loading').hide();
                                that.find('.up-next').text(data.next.Title);
                                that.find('.on-now').text(data.current.Title);
                                that.find('.catch-up').text(data.catchUp.Title);
                                that.find('.catch-up-link').attr('href', liveJsonobj.catchUpUrl.replace("{0}", data.catchUp.EpgItemId));
                            });
                            $(this).find('.item-details').shorten({
                                showChars: '100',
                                moreText: '...'
                            });
                        }
                    }
                });

            });
        };

        // show tooltip for shows
        var $showThumb = $('.show-grid-action');
        if ($showThumb.length) {
            $showThumb.each(function () {

                var tsQtip = $(this);

                var jsonobj = {
                    showName: tsQtip.data('assetname'),
                    HtmlContent: tsQtip.data('desc'),
                    Actors: tsQtip.data('actors'),
                    Language: tsQtip.data('language'),
                    EpisodeCount: tsQtip.data('runningtime'),
                    url: tsQtip.data('url'),
                    favourite_txt: (tsQtip.data('favourite') === '1' ? 'in watchlist' : 'add to watchlist'),
                    favourite_class: (tsQtip.data('favourite') === '1' ? ' added' : '')
                };

                var popUpTemplate = _.template("<div class='zee-carousel-tooltip-data'><div class='item-name'><h3><%= item.showName %></h3></div><ul class='item-info-list'><li><span class='item-language'><%=item.Language %></span></li><li><span class='item-length'><%= item.EpisodeCount %><sup>Episodes</sup></span></li></ul><div class='item-cast'><span>cast :</span><%= item.Actors %>..</div><div class='item-details'><p><%= item.HtmlContent %></p></div><ul class='item-watch-now'><li><a href='<%= item.url %>' class='item-watch-link'>Watch Now</a></li></ul></div>");

                tsQtip.qtip({
                    id: false,
                    content: {
                        text: popUpTemplate({ item: jsonobj }),
                        title: {
                            text: false,
                            button: false
                        }
                    },
                    position: {
                        my: 'right center',
                        at: 'left center',
                        viewport: $(window),
                        adjust: {
                            method: 'flip none'
                        }
                    },
                    show: {
                        solo: true,
                        delay: 500
                    },
                    hide: {
                        fixed: true,
                        delay: 300
                        //,event: 'click'
                    },
                    style: {
                        classes: 'zee-carousel-tooltip',
                        tip: {
                            width: 15,
                            height: 6,
                            border: 0
                        }
                    },
                    events: {
                        show: function () {
                            $(this).find('.item-details').shorten({
                                showChars: '100',
                                moreText: '...'
                            });
                        }
                    }
                });

            });
        };

        // footer animated email link
        $('.zee-writeus').on('hover', function () {
            $(this).find('span.icon').addClass('swing');
        });
        $('.zee-writeus').on('mouseleave', function () {
            $(this).find('span.icon').removeClass('swing');
        });


        // supported device carousel
        $('.zee-devices-carousel').owlCarousel({
            margin: 10,
            nav: false,
            dots: true,
            loop: false,
            baseClass: 'supported-devices',
            navText: ['&nbsp;', '&nbsp;'],
            responsiveClass: true,
            mouseDrag: true,
            //autoWidth : true,
            responsive: {
                0: {
                    items: 2
                },
                479: {
                    items: 3
                },
                768: {
                    items: 3
                },
                992: {
                    items: 3
                },
                1200: {
                    items: 5
                }
            }
        });

        // fixed footer
        /*
        if (!md.mobile()) {

            if ($('.zee-footer').data('auto-show') === 1) {

                $(window).on('scroll', $.debounce(200, function () {

                    if ($(window).scrollTop() + $(window).height() > $(document).height() - 100) {
                        $('.zee-footer').addClass('show-footer');
                    }
                    else {
                        $('.zee-footer').removeClass('show-footer');
                    }
                }));

            };
        };
        */

        $('.zee-footer .arrow-up').on('click', function () {
            $('.zee-footer').addClass('show-footer');
        });
        $('.zee-footer').on('mouseleave', function () {
            $(this).removeClass('show-footer');
        });

        // launch carousel thumbnail info on mobiles
        $('.carousel-mobile-info').each(function () {

            var infoThis = $(this),
				infoDataSrc = infoThis.parents('.carousel-helper-wrapper').find('.carousel-thumb-action');

            var infoJsonobj = {
                movieName: infoDataSrc.data('assetname'),
                RunningTime: infoDataSrc.data('runningtime'),
                HtmlContent: infoDataSrc.data('desc'),
                Actors: infoDataSrc.data('actors'),
                YearRelease: infoDataSrc.data('year'),
                Language: infoDataSrc.data('language'),
                Genre: infoDataSrc.data('genre'),
                url: infoDataSrc.data('url'),
                favourite_txt: (infoDataSrc.data('favourite') === '1' ? 'in favourites' : 'add to favourite'),
                favourite_class: (infoDataSrc.data('favourite') === '1' ? ' added' : ''),
                thumbnail: infoThis.data('thumbnail')
            };


            var infopopUpTemplate = _.template("<div class='carousel-info-popup container'><div class='zee-carousel-tooltip-data row'><div class='item-thumbnail col-md-4 col-sm-3 col-xs-12'><img src='<%= item.thumbnail %>'></div><div class='item-text-wrapper col-md-8 col-sm-9 col-xs-12'><div class='item-name'><h3><%= item.movieName %></h3><span>(<%= item.YearRelease %>)</span></div><div class='item-genre'><span><%=item.Genre %></span></div><ul class='item-info-list'><li><span class='item-language'><%=item.Language %></span></li><li><span class='item-length'><%= item.RunningTime %><sup>min</sup></span></li></ul><div class='item-cast'><span>cast :</span><%= item.Actors %>..</div><div class='item-details'><p><%= item.HtmlContent %></p></div><ul class='item-watch-now'><li><a href='<%= item.url %>' class='item-watch-link'>Watch Now</a></li></ul></div></div></div>");

            infoThis.on('click', function (event) {

                event.preventDefault();

                $.magnificPopup.open({
                    items: {
                        src: infopopUpTemplate({ item: infoJsonobj }),
                        type: 'inline'
                    }
                });
            });
        });

        // launch carousel channel info on mobiles
        $('.carousel-mobile-channel-info').each(function () {

            var liveThis = $(this),
				infoLiveSrc = liveThis.parents('.carousel-helper-wrapper').find('.carousel-live-action');

            var infoJsonobj = {
                channelName: infoLiveSrc.data('assetname'),
                HtmlContent: infoLiveSrc.data('desc'),
                Language: infoLiveSrc.data('language'),
                Genre: infoLiveSrc.data('genre'),
                url: infoLiveSrc.data('url'),
                live: infoLiveSrc.data('live'),
                now: infoLiveSrc.data('now'),
                next: infoLiveSrc.data('next'),
                channel_logo: liveThis.data('channel-logo'),
                catchUpUrl: infoLiveSrc.data('url-catchup')
            };


            var livepopUpTemplate = _.template("<div class='carousel-info-popup container'><div class='zee-carousel-tooltip-data row'>" +
                "<div class='item-thumbnail col-md-4 col-sm-3 col-xs-12'><img src='<%= item.channel_logo %>'>" +
                "</div><div class='item-text-wrapper col-md-8 col-sm-9 col-xs-12'><div class='item-name'>" +
                "<h3><%= item.channelName %></h3></span></div><div class='item-genre'><span><%=item.Genre %>" +
                "</span></div><ul class='item-info-list'><li><span class='item-language'><%=item.Language %></span></li>" +
                "</ul><div class='item-details'><p><%= item.HtmlContent %></p></div><div class='item-upnext'>" +
                "<ul><li><a class='catch-up-link'><span>CATCH UP</span></a><b class='catch-up'></b><div class='loading'><div class='loading-bar'></div><div class='loading-bar'></div><div class='loading-bar'></div><div class='loading-bar'></div><div class='loading-bar'></div></div></li>" +
                "<li><span>UP NEXT</span><b class='up-next'></b><div class='loading'><div class='loading-bar'></div><div class='loading-bar'></div><div class='loading-bar'></div><div class='loading-bar'></div><div class='loading-bar'></div></div>" +
                "</li><li><a href='<%= item.url %>'><span>ON NOW</span></a><b class='on-now'></b><div class='loading'><div class='loading-bar'></div><div class='loading-bar'></div><div class='loading-bar'></div><div class='loading-bar'></div><div class='loading-bar'></div></div></li>" +
                "</ul></div></div></div></div>");

            liveThis.on('click', function (event) {

                event.preventDefault();

                $.magnificPopup.open({
                    items: {
                        src: livepopUpTemplate({ item: infoJsonobj }),
                        type: 'inline'
                    }, callbacks: {
                        open: function () {
                            $(".item-upnext").find('.up-next').text('');
                            $(".item-upnext").find('.on-now').text('');
                            $(".item-upnext").find('.catch-up').text('');
                            $(".item-upnext").find('.catch-up-link').attr('href', "#");
                            $(".item-upnext").find('.loading').show();
                            var scope = angular.element($('#channelTray')).scope();
                            scope.getChannelInfo(null, infoLiveSrc.data('assetid')).then(function (data) {
                                $(".item-upnext").find('.loading').hide();
                                $(".item-upnext").find('.up-next').text(data.next.Title);
                                $(".item-upnext").find('.on-now').text(data.current.Title);
                                $(".item-upnext").find('.catch-up').text(data.catchUp.Title);
                                $(".item-upnext").find('.catch-up-link').attr('href', infoJsonobj.catchUpUrl.replace("{0}", data.catchUp.EpgItemId));

                            });

                        }
                    }
                });
            });
        });

        // launch show info on mobiles
        $('.show-mobile-info').each(function () {

            var infoThis = $(this),
				infoDataSrc = infoThis.parents('.carousel-helper-wrapper').find('.show-grid-action');

            var infoJsonobj = {
                showName: infoDataSrc.data('assetname'),
                HtmlContent: infoDataSrc.data('desc'),
                Actors: infoDataSrc.data('actors'),
                Language: infoDataSrc.data('language'),
                EpisodeCount: infoDataSrc.data('runningtime'),
                url: infoDataSrc.data('url'),
                favourite_txt: (infoDataSrc.data('favourite') === '1' ? 'in favourites' : 'add to favourite'),
                favourite_class: (infoDataSrc.data('favourite') === '1' ? ' added' : ''),
                thumbnail: infoThis.data('thumbnail')
            };


            var infopopUpTemplate = _.template("<div class='carousel-info-popup container'><div class='zee-carousel-tooltip-data row'><div class='item-thumbnail col-md-4 col-sm-3 col-xs-12'><img src='<%= item.thumbnail %>'></div><div class='item-text-wrapper col-md-8 col-sm-9 col-xs-12'><div class='item-name'><h3><%= item.showName %></h3></div><ul class='item-info-list'><li><span class='item-language'><%=item.Language %></span></li><li><span class='item-length'><%= item.EpisodeCount %><sup>Episodes</sup></span></li></ul><div class='item-cast'><span>cast :</span><%= item.Actors %>..</div><div class='item-details'><p><%= item.HtmlContent %></p></div><ul class='item-watch-now'><li><a href='<%= item.url %>' class='item-watch-link'>Watch Now</a></li></ul></div></div></div>");

            infoThis.on('click', function (event) {

                event.preventDefault();

                $.magnificPopup.open({
                    items: {
                        src: infopopUpTemplate({ item: infoJsonobj }),
                        type: 'inline'
                    }
                });
            });
        });

        // launch contact form popup
        $('.zee-writeus > a').magnificPopup({
            modal: true,
            items: {
                src: '#zee_contact_form',
                type: 'inline'
            },
            removalDelay: 300,
            mainClass: 'mfp-fade'
        });

        // close contact form
        $('#zee_close_contact_form').on('click', function () {
            $.magnificPopup.close();
        });



        // package channel info
        $('.package-view-channels-btn').magnificPopup({
            modal: true,
            type: 'inline',
            removalDelay: 300,
            mainClass: 'mfp-fade'
        });

        // close contact form
        $('#zee_close_package_win, #zee_close_package_info').on('click', function (e) {
            e.preventDefault();
            $.magnificPopup.close();
        });

        // show/hide goto top button
        if (!md.mobile()) {
            $('body').waypoint(function (direction) {
                if (direction === 'down') {
                    $('.gototop').fadeIn('slow');
                } else {
                    $('.gototop').fadeOut('slow');
                }
            }, {
                offset: -300
            });
        };

        $('.gototop > a').on('click', function (e) {
            e.preventDefault();
            var body = $('html, body');
            body.stop().animate({ scrollTop: 0 }, '500');
        });





        // movies sorting menu
        //  $('#zee_movies_sorting ul').tinyNav();

        // movies filter custom selector

        //if (!md.mobile()) {
        //    $('.zee-movies-filters select').selectric();
        //    $('.zee-myaccount-wrapper select').selectric();
        //    $('.zee-checkout-container select').selectric();
        //    $('.selectric-field').selectric();
        //};

        $('.zee-movies-alpha-sorting li a').on('click', function () {
            $('.zee-movies-alpha-sorting li a').removeClass('active');
            $(this).addClass('active');
        });

        $('#zee_myaccount_mobile_menu_trigger').on('click', function (e) {

            e.preventDefault();
            $(this).toggleClass('menu-open');
            $('#zee_myaccount_mobile_menu').slideToggle();

        });

        $('#checkout_cvv_helper').magnificPopup({
            mainClass: 'mfp-fade',
            type: 'inline'
        });

        // package info popup
        $('.package-info-data').each(function () {

            var packageThis = $(this);

            var packageJsonobj = {
                packageName: packageThis.data('package'),
                packagePrice: packageThis.data('price'),
                HtmlContent: packageThis.data('desc'),
                channels: packageThis.data("channels")
            };


            var packagePopUpTemplate = _.template("<div class='package-info-popup'><h3><%= item.packageName %></h3><span style='font-size: 18px;'>Price : <%= item.packagePrice %></span><ul><% _.each(item.channels, function(channel) { %><li><img src='<%= channel.ImageUrl %>'></li><% }); %></ul><p><%= item.HtmlContent %></p></div>");

            packageThis.on('click', function (event) {

                event.preventDefault();

                $.magnificPopup.open({
                    items: {
                        src: packagePopUpTemplate({ item: packageJsonobj }),
                        type: 'inline'
                    }
                });
            });
        });


        // package checkout table
        //$('#zee_package_checkout_summary').footable();
        //$('#zee_receipt_summary').footable();


        var showInfo = $('.show-episode-info');

        if (showInfo.length) {

            showInfo.each(function () {

                var showThis = $(this);

                var packageJsonobj = {
                    showName: showThis.data('show-title'),
                    ShowEpisode: showThis.data('show-episode'),
                    showText: showThis.data('show-info')
                };


                var showPopUpTemplate = _.template("<div class='package-info-popup'><h3><%= item.showName %></h3><span>[<%= item.ShowEpisode %>]</span><div class='clearfix' style='height:20px'></div><p><%= item.showText %></p></div>");

                showThis.on('click', function (event) {

                    event.preventDefault();

                    $.magnificPopup.open({
                        items: {
                            src: showPopUpTemplate({ item: packageJsonobj }),
                            type: 'inline'
                        }
                    });
                });
            });

        };

        //$('.owl-item:eq(-2) > div', live_carousel).addClass('no-border');

        /*
		$('#zee_live_carousel_programs .owl-item:eq(-2) > div').addClass('no-border');
		console.log($('#zee_live_carousel_channels .owl-item:eq(-4) > div').html());
		$('#zee_live_carousel_channels .owl-item:eq(-2) > div').addClass('no-border');
		*/

        // update on resize
        /* for future
		var screen_size_resize = $.debounce( 50, function(){
			
		});
		$(window).on('resize', screen_size_resize);
		*/
        initSearch('#zeeSearch');


    }); // document.ready

})(jQuery);