
function convertMS(ms) {
    var m, s;
    s = Math.floor(ms / 1000);
    m = Math.floor(s / 60);

    return m;
};

if (!Array.prototype.last) {
    Array.prototype.last = function () {
        return this[this.length - 1];
    };
};

/*
 * jQuery throttle / debounce - v1.1 - 3/7/2010
 * http://benalman.com/projects/jquery-throttle-debounce-plugin/
 * 
 * Copyright (c) 2010 "Cowboy" Ben Alman
 * Dual licensed under the MIT and GPL licenses.
 * http://benalman.com/about/license/
 */
(function (b, c) { var $ = b.jQuery || b.Cowboy || (b.Cowboy = {}), a; $.throttle = a = function (e, f, j, i) { var h, d = 0; if (typeof f !== "boolean") { i = j; j = f; f = c } function g() { var o = this, m = +new Date() - d, n = arguments; function l() { d = +new Date(); j.apply(o, n) } function k() { h = c } if (i && !h) { l() } h && clearTimeout(h); if (i === c && m > e) { l() } else { if (f !== true) { h = setTimeout(i ? k : l, i === c ? e - m : e) } } } if ($.guid) { g.guid = j.guid = j.guid || $.guid++ } return g }; $.debounce = function (d, e, f) { return f === c ? a(d, e, false) : a(d, f, e !== false) } })(this);
/*Spin JS*/
//fgnass.github.com/spin.js#v2.0.1
!function (a, b) { "object" == typeof exports ? module.exports = b() : "function" == typeof define && define.amd ? define(b) : a.Spinner = b() }(this, function () { "use strict"; function a(a, b) { var c, d = document.createElement(a || "div"); for (c in b) d[c] = b[c]; return d } function b(a) { for (var b = 1, c = arguments.length; c > b; b++) a.appendChild(arguments[b]); return a } function c(a, b, c, d) { var e = ["opacity", b, ~~(100 * a), c, d].join("-"), f = .01 + c / d * 100, g = Math.max(1 - (1 - a) / b * (100 - f), a), h = j.substring(0, j.indexOf("Animation")).toLowerCase(), i = h && "-" + h + "-" || ""; return l[e] || (m.insertRule("@" + i + "keyframes " + e + "{0%{opacity:" + g + "}" + f + "%{opacity:" + a + "}" + (f + .01) + "%{opacity:1}" + (f + b) % 100 + "%{opacity:" + a + "}100%{opacity:" + g + "}}", m.cssRules.length), l[e] = 1), e } function d(a, b) { var c, d, e = a.style; for (b = b.charAt(0).toUpperCase() + b.slice(1), d = 0; d < k.length; d++) if (c = k[d] + b, void 0 !== e[c]) return c; return void 0 !== e[b] ? b : void 0 } function e(a, b) { for (var c in b) a.style[d(a, c) || c] = b[c]; return a } function f(a) { for (var b = 1; b < arguments.length; b++) { var c = arguments[b]; for (var d in c) void 0 === a[d] && (a[d] = c[d]) } return a } function g(a, b) { return "string" == typeof a ? a : a[b % a.length] } function h(a) { this.opts = f(a || {}, h.defaults, n) } function i() { function c(b, c) { return a("<" + b + ' xmlns="urn:schemas-microsoft.com:vml" class="spin-vml">', c) } m.addRule(".spin-vml", "behavior:url(#default#VML)"), h.prototype.lines = function (a, d) { function f() { return e(c("group", { coordsize: k + " " + k, coordorigin: -j + " " + -j }), { width: k, height: k }) } function h(a, h, i) { b(m, b(e(f(), { rotation: 360 / d.lines * a + "deg", left: ~~h }), b(e(c("roundrect", { arcsize: d.corners }), { width: j, height: d.width, left: d.radius, top: -d.width >> 1, filter: i }), c("fill", { color: g(d.color, a), opacity: d.opacity }), c("stroke", { opacity: 0 })))) } var i, j = d.length + d.width, k = 2 * j, l = 2 * -(d.width + d.length) + "px", m = e(f(), { position: "absolute", top: l, left: l }); if (d.shadow) for (i = 1; i <= d.lines; i++) h(i, -2, "progid:DXImageTransform.Microsoft.Blur(pixelradius=2,makeshadow=1,shadowopacity=.3)"); for (i = 1; i <= d.lines; i++) h(i); return b(a, m) }, h.prototype.opacity = function (a, b, c, d) { var e = a.firstChild; d = d.shadow && d.lines || 0, e && b + d < e.childNodes.length && (e = e.childNodes[b + d], e = e && e.firstChild, e = e && e.firstChild, e && (e.opacity = c)) } } var j, k = ["webkit", "Moz", "ms", "O"], l = {}, m = function () { var c = a("style", { type: "text/css" }); return b(document.getElementsByTagName("head")[0], c), c.sheet || c.styleSheet }(), n = { lines: 12, length: 7, width: 5, radius: 10, rotate: 0, corners: 1, color: "#000", direction: 1, speed: 1, trail: 100, opacity: .25, fps: 20, zIndex: 2e9, className: "spinner", top: "50%", left: "50%", position: "absolute" }; h.defaults = {}, f(h.prototype, { spin: function (b) { this.stop(); { var c = this, d = c.opts, f = c.el = e(a(0, { className: d.className }), { position: d.position, width: 0, zIndex: d.zIndex }); d.radius + d.length + d.width } if (e(f, { left: d.left, top: d.top }), b && b.insertBefore(f, b.firstChild || null), f.setAttribute("role", "progressbar"), c.lines(f, c.opts), !j) { var g, h = 0, i = (d.lines - 1) * (1 - d.direction) / 2, k = d.fps, l = k / d.speed, m = (1 - d.opacity) / (l * d.trail / 100), n = l / d.lines; !function o() { h++; for (var a = 0; a < d.lines; a++) g = Math.max(1 - (h + (d.lines - a) * n) % l * m, d.opacity), c.opacity(f, a * d.direction + i, g, d); c.timeout = c.el && setTimeout(o, ~~(1e3 / k)) }() } return c }, stop: function () { var a = this.el; return a && (clearTimeout(this.timeout), a.parentNode && a.parentNode.removeChild(a), this.el = void 0), this }, lines: function (d, f) { function h(b, c) { return e(a(), { position: "absolute", width: f.length + f.width + "px", height: f.width + "px", background: b, boxShadow: c, transformOrigin: "left", transform: "rotate(" + ~~(360 / f.lines * k + f.rotate) + "deg) translate(" + f.radius + "px,0)", borderRadius: (f.corners * f.width >> 1) + "px" }) } for (var i, k = 0, l = (f.lines - 1) * (1 - f.direction) / 2; k < f.lines; k++) i = e(a(), { position: "absolute", top: 1 + ~(f.width / 2) + "px", transform: f.hwaccel ? "translate3d(0,0,0)" : "", opacity: f.opacity, animation: j && c(f.opacity, f.trail, l + k * f.direction, f.lines) + " " + 1 / f.speed + "s linear infinite" }), f.shadow && b(i, e(h("#000", "0 0 4px #000"), { top: "2px" })), b(d, b(i, h(g(f.color, k), "0 0 1px rgba(0,0,0,.1)"))); return d }, opacity: function (a, b, c) { b < a.childNodes.length && (a.childNodes[b].style.opacity = c) } }); var o = e(a("group"), { behavior: "url(#default#VML)" }); return !d(o, "transform") && o.adj ? i() : j = d(o, "animation"), h });



Date.prototype.getMonthName = function (lang) {
    lang = lang && (lang in Date.locale) ? lang : 'en';
    return Date.locale[lang].month_names[this.getMonth()];
};

Date.prototype.getMonthNameShort = function (lang) {
    lang = lang && (lang in Date.locale) ? lang : 'en';
    return Date.locale[lang].month_names_short[this.getMonth()];
};

Date.prototype.getDayNameShort = function (lang) {
    lang = lang && (lang in Date.locale) ? lang : 'en';
    return Date.locale[lang].day_names_short[this.getDay()];
};

Date.locale = {
    en: {
        month_names: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
        month_names_short: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
        day_names_short: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"]
    }
};


var app = angular.module('main', []);

angular.module('angular-jwplayer', []).directive('jwplayer', ['$compile', function ($compile) {
    return {
        restrict: 'EC',
        scope: {
            playerId: '@',
            setupVars: '=setup'

        },
        link: function (scope, element) {
            var id = scope.playerId || 'random_player_' + Math.floor((Math.random() * 999999999) + 1),
                getTemplate = function (playerId) {
                    return '<div id="' + playerId + '"></div>';
                };

            element.html(getTemplate(id));
            $compile(element.contents())(scope);
            jwplayer(id).setup(scope.setupVars);
        }
    };
}]);

app.service('zeeEpgService', ['$http', '$q', function ($http, $q) {
    return {
        getEpg: function (url, request, token) {

            var deferred = $q.defer();
            $http(
                { method: 'GET', data: request, url: '/json/EpgItemByChannel.js', cache: false, headers: { 'RequestVerificationToken': token } }
                ).success(function (data) {
                    deferred.resolve(data);
                }).error(function (error) {
                    deferred.reject(error);
                });
            return deferred.promise;
        }
    };
}
]);


/*Controller Code*/
app.controller('EpgGuide', ['$scope', '$http', '$timeout', 'zeeEpgService', function ($scope, $http, $timeout, zeeEpgService) {

    var opts = {
        lines: 13, // The number of lines to draw
        length: 20, // The length of each line
        width: 10, // The line thickness
        radius: 75, // The radius of the inner circle
        corners: 1, // Corner roundness (0..1)
        rotate: 0, // The rotation offset
        direction: 1, // 1: clockwise, -1: counterclockwise
        color: '#0db7ed', // #rgb or #rrggbb or array of colors
        speed: 1, // Rounds per second
        trail: 60, // Afterglow percentage
        shadow: false, // Whether to render a shadow
        hwaccel: true, // Whether to use hardware acceleration
        className: 'spinner', // The CSS class to assign to the spinner
        zIndex: 2e9, // The z-index (defaults to 2000000000)
        top: '60%', // Top position relative to parent
        left: '50%' // Left position relative to parent
    };

    $scope.msInDay = 86400000;

    $scope.now = new Date();

    $scope.todayBoD = new Date($scope.now.getFullYear(), $scope.now.getMonth(), $scope.now.getDate());
    $scope.todayBoD.setTime($scope.todayBoD.getTime() + 1000);
    $scope.todayBoD = (new Date($scope.todayBoD));

    $scope.pageSize = 128;
    $scope.daysWithEpgItems = [];


    $scope.getEoD = function (date) {
        var result = new Date(date);
        result.setTime(result.getTime() + $scope.msInDay - 2000);
        return new Date(result);
    };



    var target = document.getElementById('spinner-1');
    var spinner = new Spinner(opts).spin(target);
    //  usSpinnerService.spin('spinner-1');
    //
    $("#epg-grid").hide();
    $("#guide-list-wrapper").hide();
    var baseUrl = $("#guide-list-wrapper").data("baseurl");

    $scope.dates = [];
    $scope.channels = window.serverChannel;
    $scope.todays = [];
    $scope.todaysDate = null;
    $scope.heightcount = 0;

    $scope.ShowSpinner = function () {
        $("#guide-list-wrapper").hide();
        spinner.spin(target);
    }

    $scope.HideSpinner = function () {
        spinner.stop();
        $("#guide-list-wrapper").css('visibility', 'visible').show().fadeOut('slow', 1);
    }
    $scope.itemStyle = function (item) {
        return { width: item * 8 + 'px' };
    };


    $scope.onNow = function () {
        $scope.ShowSpinner();
        $scope.todaysDate = $scope.dates[0];
        $scope.epgInfo.ChangeDay($scope.todayBoD);
    }

    function scrollGrid(distance) {
        if ($('html,body').queue().length > 0) return false;
        var left = $(window).scrollLeft();
        $('html,body').animate({ scrollLeft: left + distance }, 1000, 'swing');
        return false;
    };

    $(document).ready(function () {
        $scope.scrollNext = function (e) {
            if (e === 0) scrollGrid(60);
            scrollGrid(480);
        }

        $scope.scrollPrev = function (e) {
            if (e === 0) scrollGrid(-60);
            scrollGrid(-480);
        }
    });

    function moveToCurrentTimeFrame() {

        $(window).scrollLeft(((new Date().getHours() * 60 + new Date().getMinutes()) * 8) - 720);

    }

    function calculateHeightWidth() {

        $(window).scrollTop(0);

        function calculate() {
            var height = parseInt($(window).height() + $(window).scrollTop() - $("#guide-channels").offset().top, 10);

            $("#guide-channels").css({
                'height': height + 'px'
            });
            /*
            $("#zee-next").css({
                'height': height + 'px'
            });

            $("#zee-previous").css({
                'height': height + 'px'
            });
            */

            moveToCurrentTimeFrame();
        }

        $timeout(calculate, 100);
    };

    $(window).resize(function () {

        calculateHeightWidth();
    });

    function getDates() {

        for (var i = 0; i <= 30; i++) {
            var dt = new Date((new Date($scope.todayBoD)).setTime($scope.todayBoD.getTime() - ($scope.msInDay * i)));
            var day = {
                date: dt,
                day: dt.getDate(),
                monthint: dt.getMonth(),
                weekday: dt.getDayNameShort(),
                month: dt.getMonthNameShort(),
                active: false,
                isData: true,
                year: dt.getYear(),
                seq: 30 - i
            };
            $scope.dates.push(day);

        }

        var lastItem = $scope.dates[0];

        lastItem.active = true;

        $scope.dates = $scope.dates.reverse();

        $scope.channelHeight = 0;

        var countUp = function () {

            // guide schedule scroll
            var queryResult = Enumerable.from($scope.dates)
             .where(function (x) { return x.active === true; })
                        .toArray();
            console.log(queryResult);
            $("#guide-schedule-items").owlCarousel({
                margin: 1,
                nav: true,
                dots: false,
                loop: false,
                baseClass: 'zee-carousel',
                themeClass: 'zee-carousel-theme',
                itemClass: 'zee-carousel-item',
                navText: ['<i class="icon icon-left-open-big"></i>', '<i class="icon icon-right-open-big"></i>'],
                mouseDrag: false,
                startPosition: queryResult[0].seq,
                responsive: {
                    0: {
                        items: 4,
                        slideBy: 3
                    },
                    1024: {
                        items: 6,
                        slideBy: 5
                    },
                    1140: {
                        items: 7,
                        slideBy: 6
                    },
                    1520: {
                        items: 8,
                        slideBy: 7
                    },
                    1710: {
                        items: 9,
                        slideBy: 8
                    },
                    1900: {
                        items: 11,
                        slideBy: 10
                    }
                }
            });

        }

        $timeout(countUp, 10);
    };

    getDates();


    var date = $scope.todayBoD;

    date = new Date(date);


    calculateHeightWidth();

    $(window).add('#guide-channels').scrollsync({ targetSelector: $(window), axis: 'y' });
    $(window).add('#epg-time').scrollsync({ targetSelector: $(window), axis: 'x' });
    $(window).dragscrollable({ dragSelector: '#guide-schedule-outer', acceptPropagatedEvent: true, threshold: 3 });

    try {
        spinner.stop();
        $('#epg-grid').css('visibility', 'visible').show().fadeIn('slow');
        $("#guide-list-wrapper").css('visibility', 'visible').show().fadeOut('slow', 1);
    } catch (ex) {
        //console.log(ex);
    }


    $scope.isEpgItemOnNow = function (epgItem) {
        var start = Date.parse(epgItem.StartDate);
        var end = Date.parse(epgItem.EndDate);
        var result = (start <= $scope.now) && ($scope.now <= end);
        epgItem.IsPlayingNow = result;
        epgItem.IsCatchUp = $scope.isPastEpgItem(epgItem);

        return result;
    }

    $scope.isPastEpgItem = function (epgItem) {
        var end = new Date(epgItem.EndDate);
        return (end <= $scope.now);
    }

    $scope.epgItemProgress = function (epgItem) {
        var result = 0;
        if ($scope.isEpgItemOnNow(epgItem)) {
            var start = Date.parse(epgItem.StartDate);
            var end = Date.parse(epgItem.EndDate);
            result = (($scope.now - start) / (end - start));
        }
        return result;
    }

    $scope.getEoD = function (date) {
        var result = new Date(date);
        result.setTime(result.getTime() + $scope.msInDay - 2000);
        return new Date(result);
    };

    $scope.epgInfo = {};

    function attachedEvents() {
        $timeout(function () {
            window.serverChannel.forEach(function (sc) {
                var el = $("#" + sc.Id);
                // ReSharper disable once UnusedLocals
                var waypoint = new Waypoint({
                    element: el,
                    handler: _.once(function () {
                        $scope.getChannelData(sc.Id);
                    }),
                    offset: '90%'
                });



            });
        }, 500);
    }

    $scope.epgInfo.ChangeDay = function (day) {
        //console.log(day);
        $scope.ShowSpinner();

        _.each($scope.dates, function (d) {
            if (d.active === true)
                d.active = false;
        });

        date = day.date; //new Date(day.year, day.monthint - 1, day.day);

        $scope.channels.forEach(function (sc) {
            sc.EpgItems.length = 0;
        });


        $scope.channels = window.serverChannel;

        attachedEvents();

        day.active = true;

        $timeout(function () {
            $scope.HideSpinner();
        }, 500);


    }



    var url = baseUrl + "EpgItemByChannel";




    $scope.getChannelData = function (channelId) {
        var request = {
            "TimeStart": date.toISOString(),
            "TimeEnd": $scope.getEoD(date).toISOString(),
            "ChannelIDs": channelId
        };



        zeeEpgService.getEpg(url, request, $('#antiForgeryToken').val())
            .then(function (data) {


                if (data.length === 0) return;

                var firstObj = data[0];
                var firstStartDate = new Date(firstObj.StartDate);
                if (firstStartDate < date) {

                    firstObj.DurationInMinutes = firstObj.DurationInMinutes - convertMS(date - firstStartDate);

                    //console.log('First Date - ' + convertMS(date - firstStartDate));
                    // console.log(firstObj);
                }

                var lastObject = data.last();
                var lastEndDate = new Date(lastObject.EndDate);
                if (lastEndDate > $scope.getEoD(date)) {

                    lastObject.DurationInMinutes = lastObject.DurationInMinutes - convertMS(lastEndDate - $scope.getEoD(date));

                    // console.log('Last Date - ' + convertMS(lastEndDate - $scope.getEoD(date)));
                    // console.log(lastObject);
                }

                var indexes = $.map($scope.channels, function (obj, index) {
                    if (obj.Id === channelId) {
                        return index;
                    }
                    // ReSharper disable once NotAllPathsReturnValue
                });

                $scope.channels[indexes].EpgItems = data;
                $scope.channels[indexes].IsLoading = false;


            }
        );

    }
    attachedEvents();

    function play(url) {
        window.location.href = url;
    }

    $scope.playChannel = function (channel) {
        play(channel.Url);
    }

    $scope.catchUpPlay = function (epg, channel) {
        var url = epg.IsPlayingNow ? channel.Url : channel.CatchUpUrl.replace("{0}", epg.EpgItemId);
        play(url);
    }



}]);




