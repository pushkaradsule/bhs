﻿$(document).ready(function () {

    $('#CardNumber').val('');
    $('#NameOnCard').val('');
    $('#CardCode').val('');
    var key = $("#payment-container").data("payment");
    var braintree = window.Braintree.create(key);

    braintree.onSubmitEncryptForm('checkoutform');

    $('#CardNumber').creditCardType();
});

(function ($) {
    $.getCreditCardType = function (val) {
        if (!val || !val.length) return undefined;
        switch (val.charAt(0)) {
            case '4': return 'visa';
            case '5': return 'mastercard';
            case '3': return 'amex';
            case '6': return 'discover';
        };
        return undefined;
    };
    $.fn.creditCardType = function (options) {
        var settings = {
            target: '#credit-card-type'
        };
        if (options) {
            $.extend(settings, options);
        };
        var keyupHandler = function () {
            $("#credit-card-type li").removeClass("active");
            $("input[id=authorizenet_cc_type]").val('');
            $("#ccmessage").hide();
            switch ($.getCreditCardType($(this).val())) {
                case 'visa':
                    $('#credit-card-type .VI').addClass('active');
                    $("input[id=authorizenet_cc_type]").val('VI');
                    $("#ccmessage").hide();
                    break;
                case 'mastercard':
                    $('#credit-card-type .MC').addClass('active');
                    $("input[id=authorizenet_cc_type]").val('MC');
                    $("#ccmessage").hide();
                    break;
                case 'amex':

                    $("#ccmessage")
                 .addClass("form-alert text-danger")
                 .text("We are currently not accepting American Express. We apologize for the inconvenience.");
                    $("#ccmessage").show();
                    break;
                case 'discover':

                    $("#ccmessage")
                 .addClass("form-alert text-danger")
                 .text("We are currently not accepting Discover. We apologize for the inconvenience.");
                    $("#ccmessage").show();

                    break;
            };
        };
        return this.each(function () {
            $(this).bind('keyup', keyupHandler).trigger('keyup');
        });
    };
})(jQuery);