﻿"use strict";
angular.module("main", ['ui.router', 'ngProgress'])
.config(['$stateProvider', '$urlRouterProvider', 'ngProgressProvider', '$locationProvider',
    function ($stateProvider, $urlRouterProvider, ngProgressProvider, $locationProvider) {

        $locationProvider.html5Mode(true);

        $stateProvider
            .state('live', {
                resolve: {
                    channel: ['zeeEpgService', '$stateParams', 'playerData', 'ngProgress', function (zeeEpgService, $stateParams, playerData, ngProgress) {
                        ngProgress.start();
                        
                        var request = {
                            "ChannelId": $stateParams.channelId,
                            "UniqueVisitorId": playerData.s
                        };

                       
                        return zeeEpgService.getChannelInfo(baseUrl, request, $('#antiForgeryToken').val());
                    }]
                },
                url: '/:lang/Live/:channelName/:channelId',
                templateUrl: '',
                views: {
                    '': { template: '' },

                    'player@live': {
                        templateUrl: 'partials/liveplayer.html?v=1',
                        controller: "Player"
                    },
                    'channelControls@live': {
                        templateUrl: 'partials/channelControls.html',
                        controller: "channelControls"
                    },
                    'channelInfo@live': {
                        templateUrl: 'partials/channelInfo.html?v=1',
                        controller: "channelInfo"

                    },
                    'nowPlaying@live': {
                        templateUrl: 'partials/nowplaying.html',
                        controller: "nowPlayingLive"
                    }
                }
            })
            .state('catchup', {
                resolve: {
                    channel: ['zeeEpgService', '$stateParams', 'playerData', 'ngProgress', function (zeeEpgService, $stateParams, playerData, ngProgress) {
                        ngProgress.start();

                        var request = {
                            "EpgItemId": $stateParams.epgItemId,
                            "UniqueVisitorId": playerData.s
                        };
                        return zeeEpgService.getCatchUp(baseUrl, request, $('#antiForgeryToken').val());
                    }]
                },
                url: '/:lang/CatchUp/:channelName/:epgItemId',
                templateUrl: '',
                views: {
                    '': { template: '' },

                    'player@catchup': {
                        templateUrl: 'partials/liveplayer.html?v=1',
                        controller: "Player"
                    },
                    'channelControls@catchup': {
                        templateUrl: 'partials/channelControls.html',
                        controller: "channelControls"
                    },
                    'channelInfo@catchup': {
                        templateUrl: 'partials/channelInfo.html',
                        controller: "channelInfo"
                    },
                    'nowPlaying@catchup': {
                        templateUrl: 'partials/catchup-epgInfo.html?v=3',
                        controller: "nowPlayingCatchUp"
                    }
                }
            });

        ngProgressProvider.setColor('#fdcb0c');
        ngProgressProvider.setHeight('2px');


    }]);