<?php
include 'inc/head.php';
$page='checkout';
?>

<div class="zee-content-wrapper zee-myaccount-body">
    <div class="my-account-welcome">
        <div class="container">
            <div class="row">
                <h3>Pick the package that's right for you</h3>
            </div>
        </div>
    </div>

    <div class="container zee-myaccounter-container">

        <!-- register tab -->

        <div class="package-accordian">

            <div class="container-fluid">
                <div class="row">
                    <div class="package-accordian-body">

                        <div class="zee-members-login-outer">




                            <!-- error message -->
                            <div class="zee-myaccount-error-message">
                                <div class="zee-form-message error">
                                    <!--<i class="icon icon-ok-1"></i>-->
                                    <i class="icon icon-info"></i>
                                    <p>The email address or password you entered is incorrect. Passwords are case sensitive. Please try again.</p>
                                </div>
                            </div>

                            <!-- form header -->
                            <div class="heading">
                                Register
                                <hr class="seperator" style="border-color: transparent; margin: 10px 0;" />
                                <ul class="zee-members-login-social" id="sociallogos">
                                    <li>
                                        <div id="customBtn">
                                            <a href="javascript:void(0)" class="register-social-login register-social-gplus withripple">
                                                <i class="icon icon-gplus-1"></i>
                                                <span class="signup-btn-txt">Google</span>
                                            </a>
                                        </div>
                                    </li>
                                    <li>
                                        <div id="fb-root"></div>
                                        <a id="signup-with-fb fb-link" onclick="fb_login(); " href="javascript:void(0)" class="register-social-login register-social-facebook withripple">
                                            <i class="icon icon-facebook"></i>
                                            <span class="signup-btn-txt">facebook</span>
                                        </a>
                                    </li>
                                </ul>
                                <hr class="seperator" style="border-color: transparent; margin: 10px 0 0;" />
                                <span class="register-or-option-label">
                                    <i>OR</i>
                                </span>
                            </div>

                            <!--
                            <div id="socialshowfb" class="zee-register-social-alert">
                                <p><i class="icon icon-facebook"></i> Thank you for logging in through Facebook, we have used information from your profile to create your account. Please go ahead and create a secure password so that you can complete registration and start using ZEE Family.</p>
                            </div>
                            -->
                            <div class="clearfix"></div>
                            <div class="row">
                                <div class="col-md-3   zee-register-user-country">
                                    <img src="images/US.png" class="register-country-flag" />
                                </div>
                                <div class="col-md-6">

                                    <form action="/en-US/Register" autocomplete="off" method="post" returnurl="">
                                        <div class="form-group">
                                            <label>First Name</label>
                                            <input class="form-control" data-val="true" data-val-required="Please enter your full name." id="Name" name="Name" type="text" value="" />
                                        </div>

                                        <div class="form-group">
                                            <label>Last Name</label>
                                            <input class="form-control" data-val="true" data-val-required="Please enter your full name." id="Name" name="Name" type="text" value="" />
                                        </div>

                                        <div class="form-group">
                                            <label>Email</label>
                                            <input class="form-control" data-val="true" data-val-email="Please enter a valid email." data-val-required="Please enter a valid email." id="Email" name="Email" type="email" value="" />
                                        </div>


                                        <div class="form-group">
                                            <label>Password</label>
                                            <input class="form-control" data-val="true" data-val-length="The password must be at least 6 characters long." data-val-length-max="100" data-val-length-min="6" data-val-required="This field is required." id="Password" name="Password" type="password" />
                                        </div>

                                        <div class="form-group">
                                            <label>Confirm Password</label>
                                            <input class="form-control" data-val="true" data-val-equalto="The confirm password does not match. Please try again." data-val-equalto-other="*.Password" data-val-required="This field is required." id="ConfirmPassword" name="ConfirmPassword" type="password" />
                                            <input id="AuthProvider" name="AuthProvider" type="hidden" value="" />
                                            <input id="Authkey" name="Authkey" type="hidden" value="" />
                                            <input id="AuthResponse" name="AuthResponse" type="hidden" value="" />
                                        </div>

                                        <div class="form-group">
                                            <label>
                                                <strong>Do you have?</strong>
                                            </label>
                                            <ul class="checkout-payment-options">
                                                <li>
                                                    <div class="radio radio-primary">
                                                        <label class="radio-inline">
                                                            <input type="radio" name="offeroptions" value="promocode" data-offer-form="register_offer_option_coupon" />
                                                            Promo Code?
                                                            <a class="offerhelp" data-help="Donec pharetra condimentum nisl, a scelerisque orci. Nullam quis tristique dolor. Duis id pretium enim. Nunc at elementum neque. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Pellentesque habitant morbi tristique.">
                                                                <i class="icon  icon-info-circled-1"></i>
                                                            </a>
                                                        </label>
                                                    </div>
                                                </li>
                                                <li>
                                                    <div class="radio radio-primary">
                                                        <label class="radio-inline">
                                                            <input type="radio" name="offeroptions" value="scratchcard" data-offer-form="register_offer_option_card" />
                                                            Scratch Card?
                                                            <a class="offerhelp" data-help="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed ultrices scelerisque neque sed suscipit. Aliquam sit amet dignissim nisi. Aliquam a enim mollis, efficitur sapien sed, tempus metus">
                                                                <i class="icon icon-info-circled-1"></i>
                                                            </a>
                                                        </label>
                                                    </div>
                                                </li>
                                            </ul>
                                        </div>

                                        <div class="form-horizontal register-offer-forms" id="register_offer_option_coupon">
                                            <div class="form-group">
                                                <label class="col-sm-3 control-label">Coupon Code:</label>
                                                <div class="col-sm-6">
                                                    <input type="text" />
                                                </div>
                                            </div>
                                        </div>

                                        <div class="form-horizontal register-offer-forms" id="register_offer_option_card">
                                            <div class="form-group">
                                                <label class="col-sm-4 control-label">Scratch Card Number:</label>
                                                <div class="col-sm-6">
                                                    <input type="text" />
                                                </div>
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <button class="btn btn-material-grey" type="reset">CLEAR</button>
                                            <button class="btn btn-primary">Register</button>
                                        </div>

                                    </form>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>


    </div>


</div>

<?php include 'inc/footer.php'; ?>

<script>
    (function ($) {

        "use strict";

        $(document).ready(function () {

            
            $('input[data-offer-form]').each(function () {
                var ts_offer = $(this),
                    ts_offer_id = '#' + ts_offer.data('offer-form'),
                    ts_offer_obj = $(ts_offer_id);



                if (ts_offer.is(':checked')) {
                    $('.register-offer-forms').hide();
                    ts_offer_obj.fadeIn('slow');
                }

                ts_offer.on('change', function () {
                    if (ts_offer.is(':checked')) {
                        $('.register-offer-forms').hide();
                        ts_offer_obj.fadeIn('slow');
                    }
                });


            });

        });
    })(jQuery);
</script>