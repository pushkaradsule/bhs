<?php include 'inc/head.php'; ?>



<div class="zee-content-wrapper no-banner">
    <div class="container">
        
        <div class="zee-members-login-outer">

            <div class="zee-members-login-wrapper">

                <div class="zee-members-login-tabs">
                    <ul class="zee-forgot-pass-tab">
                        <li class="zee-login-back-tab">
                            <a href="/" style="float: left">
                                <img src="/icons/png/arrow-left.png">
                            </a>
                        </li>
                        <li class="zee-login-tab-heading-tab"><span>Link Samsung TV</span></li>
                    </ul>
                </div>

                <div class="zee-members-login-panels">

                    <div class="zee-members-login-panels-box">

                        <div class="zee-link-tv-logo">
                            <img src="/images/samsung-tv.png">
                        </div>

<form action="/samsung" method="post" novalidate="novalidate"><input name="__RequestVerificationToken" type="hidden" value="tlYEITFQUJIs2BqoJoc41lVXHhkBZuq41mWfHtbyH-Yv-5Swe1yiNPcVdznflrabCZcKTpoVltUtAFud9WGZXBcg1Hw79BUbNipInvlC82_n0wBZ6F-JO4thmuC_dMX00">                            <div class="form-group">
                                <label>PIN</label>

                                <input class="form-control" data-val="true" data-val-required="The DeviceCode field is required." id="DeviceCode" name="DeviceCode" type="text" value="">

                            </div>
                            <div class="form-group">
                                <button class="zee-button zee-primary-btn">
                                    <span class="icon">
                                        <img src="/icons/png/link.png" style="float: left; height: 18px; margin: 3px 0 0; width: 18px;">
                                    </span>
                                    <span class="text">Link Samsung TV</span>
                                </button>
                            </div>
</form>

                    </div>

                </div>

            </div>

        </div>

    </div>
</div>

<?php include 'inc/footer.php'; ?>