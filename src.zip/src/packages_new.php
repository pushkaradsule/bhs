<?php
$compact_topbar = '1';
$footer_auto = '0';
$bodyclass = 'package-page';
include 'inc/head.php';
$page='packages_new';
?>
<input id="antiForgeryToken" type="hidden" value='Xte4ARRA-I47GWQegL7ehqnzUGVBRVgaFrGcHQtL_VyCg9XWfzYOMLetqaGyliGt3XVvD3u3QzkBp65zD4zHBW6nKQOJZHwD8Oe_azsVAlg1:d2fNuosbXT9KG8uQ4hlqLf1OXvgIe2y86fCZZfBfiUi-QhDmAu-ct05sk0sBvYQbQL3r5Oi9TIRskLAHpqqArdbM81Z9ZoYDfARykGkx28k1' />
<div class="zee-content-wrapper">
    <div class="container-fluid package-container-fluid">
        <div class="packages-items-wrapper">

            <div class="packages-heading">
                <div class="row">
                    <div class="col-lg-6 col-md-6">
                        <h3>Select Package</h3>
                    </div>
                    <div class="col-lg-6 col-md-6">
                        <div class="package-tenure-wrapper">
                            <label>Select A Plan</label>
                            <div class="package-tenure-label">

                                <select class="form-control">
                                    <option selected>Monthly</option>
                                    <option>Yearly</option>
                                </select>

                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div style="display: none;">
                <div class="package-channels-window" id="package_channels_win">
                    <div class="package-channels-window-header">
                        <h3>ZEE Marathi Package</h3>
                        <a href="#" id="zee_close_package_win"><i class="icon icon-cancel"></i></a>
                    </div>
                    <div class="package-channels-window-body">
                        <ul>
                            <?php for ($x = 0; $x <= 12; $x++) { ?>
                            <li>
                                <img src="images/channel-logos/ZeeCinema.png" />
                                <label>ZEE Cinema</label>
                            </li>
                            <?php } ?>
                        </ul>
                    </div>
                </div>
            </div>


            <div class="packages-items-container">
                <ul class="packages-list-container">
                    <?php for ($i = 0; $i <= 15; $i++) { ?>
                    <li class="packages-list-item<?php echo ($i == '0' || $i == '1' ? ' package-double-item' : '') ?><?php echo ($i == '2' ? ' package-single-item package-selected' : '') ?>">
                        <div class="packages-list-item-inner">
                            <h3 class="package-title">ZEE Family Marathi Pack</h3>
                            <?php if($i == '1'){ ?>
                            <div class="package-cost"><img src="images/coupon-available.png" class="package-offer-available" title="Coupon Code Applied" /> <span>$</span><sup class="package-old-price">789.10</sup> <span class="package-new-price">700.99</span> /month</div>
                            <?php } else{ ?>
                            <div class="package-cost"><span>$</span>000.00 /month</div>
                            <?php } ?>
                            <ul>
                                <li>
                                    <i class="icon icon-th"></i>
                                    <span>10 Live Chanels</span>
                                    <a href="#package_channels_win" class="package-view-channels-btn">View Channels</a>
                                </li>

                                <?php if($i != '3') : ?>
                                <li>
                                    <i class="icon icon-videoplayer20"></i>
                                    <span>Access to more then 3000 movies</span>
                                </li>
                                <?php endif; ?>


                                <?php if($i != '3') : ?>
                                <li>
                                    <i class="icon icon-reload11"></i>
                                    <span>30 Days Live Catch-up</span>
                                </li>
                                <?php endif; ?>

                            </ul>
                            <button class="package-add<?php echo ($i == '2' ? ' package-added' : '') ?>"<?php echo ($i == '3' ? ' disabled="disabled"' : '') ?>><?php echo ($i == '3' ? 'Package Added' : 'Subscribe') ?></button>
                            <p class="Package-summary">It is thriller film and based on the story by Sudhir Mishra's brother Sudhanshu Mishra who died in 1995. The entire plot of the film takes place through a single night.<?php echo ($i == '2' ? ' brother Sudhanshu Mishra who died in 1995. The entire plot of the film brother Sudhanshu Mishra who died in 1995. The entire plot of the film' : '') ?></p>
                        </div>
                    </li>
                    <?php } ?>
                </ul>
            </div>
        </div>



        <div class="package-summary-xsmall" id="package_tray_trigger_xsmall">
            <div class="package-summary-content-xsmall">
                <span><i class="icon icon-credit-card"></i>Proceed to Checkout</span>
            </div>
        </div>

        <div class="package-selected-container">


            <div class="packages-selected-tray" id="slected_package_tray">


                <div class="packages-selected-table-wrapper overview">

                    <ul class="packages-selected-table-listwrapper">
                        <li>
                            <div class="package-tray-close" id="package_tray_close_xsmall">
                                <i class="icon icon-down-open-3"></i>
                            </div>
                            <table class="packages-selected-table table">
                                <thead>
                                    <tr>
                                        <th>Package Name</th>
                                        <th>Price</th>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>Zee Family Marathi Pack</td>
                                        <td>$ 299.00</td>
                                        <td>
                                            <button class="package-remove-selected"><i class="icon icon-trash"></i></button>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Zee Family Marathi Pack</td>
                                        <td>$ 299.00</td>
                                        <td>
                                            <button class="package-remove-selected"><i class="icon icon-trash"></i></button>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td colspan="3" class="package-select-warning">
                                            <div><i class="icon icon-block"></i>No Package Selected</div>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                            <div class="package-selected-total">
                                <h3>Total <span>$ 299.99<sup>*</sup> /month</span></h3>
                            </div>
                            <div class="package-selected-terms">
                                <p><sup>*</sup> You will be charged only after your free trial ends</p>
                            </div>
                            <div class="package-selected-checkout">
                                <button>
                                    <i class="icon icon-credit-card"></i>Checkout
                                </button>
                            </div>
                            <div class="package-selected-disclaimer">
                                <h3 class="package-disclaimer-titile">ALL PLAN INCLUDES</h3>
                                <ul class="package-disclaimer-items">
                                    <li>Sync Movies, Shows across Devices.</li>
                                    <li>No commitments, cancel anytime.</li>
                                    <li>Single account for all Devices</li>
                                </ul>
                                <ul class="package-disclaimer-logos">
                                    <li>
                                        <img src="images/packages-logos-desktop.png">
                                    </li>
                                    <li>
                                        <img src="images/packages-logos-ios.png">
                                    </li>
                                    <li>
                                        <img src="images/packages-logos-smarttv.png">
                                    </li>
                                    <li>
                                        <img src="images/packages-logos-android.png">
                                    </li>
                                    <li>
                                        <img src="images/packages-logos-kindlefire.png">
                                    </li>
                                    <li>
                                        <img src="images/packages-logos-amazontv.png">
                                    </li>
                                    <li>
                                        <img src="images/packages-logos-roku.png">
                                    </li>
                                </ul>
                                <p class="package-disclaimer-text">All plans offer unlimited TV shows and movies, on as many devices as you want. High Definition (HD) and Ultra High Definition (Ultra HD) availability subject to your Internet service and device capabilities. Not all content available in HD or Ultra HD.</p>
                            </div>

                        </li>
                    </ul>

                </div>



            </div>

        </div>
    </div>
</div>
<?php $hide_footer = '1'; include 'inc/footer.php'; ?>