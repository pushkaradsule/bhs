<?php
$page='show';
//$footer_auto = '0';
include 'inc/head.php';
?>

<input id="antiForgeryToken" type="hidden" value='rOGsvRoI0YviasqYV8_gW4QN6NJlc1af8JTL34S2uz60BtzRXH3_gEBLwzJbUs4s-mSVv2ljQ0wGmOn1TqTPLCvJr1iPqhIZHgt9UP1fmf41:2y7NcwkMtVd6pgUCWYMkHLinhyfp-JjxWku1O3pxIA-EEavrEpLqhAMMwHZEUjiaZ72EYzX1huLmgbF-GoktpnZUK0SfK6oZmyy6DY3-Mjc1' />
<div class="zee-content-wrapper">

    <div class="zee-browse-header">
        <div class="zee-browse-header-wrapper">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-xs-12">
                        <h3>Browse Shows</h3>
                        <form class="form-inline zee-movies-filters" role="form">
                            <div class="row">
                                <div class="form-group">
                                    <div class="col-lg-2 col-md-3 col-sm-6 zee-movies-filter-1">
                                        <select class="form-control" id="categories">
                                            <option value="">Categories</option>
                                            <option value="">All Movies</option>
                                            <option value="PL-LATEST">New Releases</option>
                                            <option value="PL-ALL TIME FAVOURITES">All Time Favorites</option>
                                            <option value="ACTION">Action</option>
                                            <option value="ADVENTURE">Adventure</option>
                                            <option value="ANIMATION">Animation</option>
                                            <option value="BIOGRAPHY">Biography</option>
                                            <option value="COMEDY">Comedy</option>
                                            <option value="CRIME">Crime</option>
                                            <option value="DOCUMENTARY">Documentary</option>
                                            <option value="DRAMA">Drama</option>
                                            <option value="FAMILY">Family</option>
                                            <option value="FANTASY">Fantasy</option>
                                            <option value="FILM-NOIR">Film-Noir</option>
                                            <option value="HISTORY">History</option>
                                            <option value="HORROW">Horror</option>
                                            <option value="MUSIC">Music</option>
                                            <option value="MYSTERY">Mystery</option>
                                            <option value="ROMANCE">Romance</option>
                                            <option value="SCI-F">Sci-FI</option>
                                            <option value="SHORT">Short</option>
                                            <option value="SPORT">Sport</option>
                                            <option value="THRILLER">Thriller</option>
                                            <option value="SUSPENSE">Suspense</option>
                                            <option value="MYTHOLOGY">Mythology</option>
                                            <option value="ENTERTAINMENT">Entertainment</option>
                                            <option value="SPECIAL EVENTS">Special Events</option>
                                        </select>
                                    </div>
                                    <div class="col-lg-2 col-md-3 col-sm-6 zee-movies-filter-2">
                                        <select class="form-control" id="language">
                                            <option value="">Language</option>
                                            <option value="hin">Hindi</option>
                                            <option value="mar">Marathi</option>
                                            <option value="ben">Bangla</option>
                                            <option value="tel">Telugu</option>
                                            <option value="tam">Tamil</option>
                                            <option value="kan">Kannada</option>

                                        </select>
                                    </div>
                                    <div class="col-lg-2 col-md-3 col-sm-6 zee-movies-filter-3">
                                        <input type="text" class="form-control" placeholder="search keywords" ng-model="movieList.searchText" />
                                    </div>
                                    <div class="col-lg-2 col-md-3 col-sm-6 zee-movies-filter-4">
                                        <a href="javascript:void(0);" class="zee-filter-button" ng-click="filterByAttribute()"><i class="icon icon-ok-1"></i> Filter</a>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="zee-browse-atoz">
        <div class="container-fluid grid-container">
            <div class="row">
                <div class="col-xs-12">
                    <div class="" ng-controller="ShowController" ng-app="shows">

                        <!-- a to z sorting -->
                        <div class="zee-movies-sorting">
                            <div id="zee_movies_sorting" class="zee-movies-alpha-sorting">
                                <ul>
                                    <li><a href="javascript:void(0);" ng-click="filterByAlphabet('A')" class="withripple active">ALL</a></li>
                                    <li><a href="javascript:void(0);" ng-click="filterByAlphabet('A')" class="withripple">0 - 9</a></li>
                                    <li><a href="javascript:void(0);" ng-click="filterByAlphabet('A')" class="withripple">A</a></li>
                                    <li><a href="javascript:void(0);" ng-click="filterByAlphabet('B')" class="withripple">B</a></li>
                                    <li><a href="javascript:void(0);" ng-click="filterByAlphabet('C')" class="withripple">C</a></li>
                                    <li><a href="javascript:void(0);" ng-click="filterByAlphabet('D')" class="withripple">D</a></li>
                                    <li><a href="javascript:void(0);" ng-click="filterByAlphabet('E')" class="withripple">E</a></li>
                                    <li><a href="javascript:void(0);" ng-click="filterByAlphabet('F')" class="withripple">F</a></li>
                                    <li><a href="javascript:void(0);" ng-click="filterByAlphabet('G')" class="withripple">G</a></li>
                                    <li><a href="javascript:void(0);" ng-click="filterByAlphabet('H')" class="withripple">H</a></li>
                                    <li><a href="javascript:void(0);" ng-click="filterByAlphabet('I')" class="withripple">I</a></li>
                                    <li><a href="javascript:void(0);" ng-click="filterByAlphabet('J')" class="withripple">J</a></li>
                                    <li><a href="javascript:void(0);" ng-click="filterByAlphabet('K')" class="withripple">K</a></li>
                                    <li><a href="javascript:void(0);" ng-click="filterByAlphabet('L')" class="withripple">L</a></li>
                                    <li><a href="javascript:void(0);" ng-click="filterByAlphabet('M')" class="withripple">M</a></li>
                                    <li><a href="javascript:void(0);" ng-click="filterByAlphabet('N')" class="withripple">N</a></li>
                                    <li><a href="javascript:void(0);" ng-click="filterByAlphabet('O')" class="withripple">O</a></li>
                                    <li><a href="javascript:void(0);" ng-click="filterByAlphabet('P')" class="withripple">P</a></li>
                                    <li><a href="javascript:void(0);" ng-click="filterByAlphabet('Q')" class="withripple">Q</a></li>
                                    <li><a href="javascript:void(0);" ng-click="filterByAlphabet('R')" class="withripple">R</a></li>
                                    <li><a href="javascript:void(0);" ng-click="filterByAlphabet('S')" class="withripple">S</a></li>
                                    <li><a href="javascript:void(0);" ng-click="filterByAlphabet('T')" class="withripple">T</a></li>
                                    <li><a href="javascript:void(0);" ng-click="filterByAlphabet('U')" class="withripple">U</a></li>
                                    <li><a href="javascript:void(0);" ng-click="filterByAlphabet('V')" class="withripple">V</a></li>
                                    <li><a href="javascript:void(0);" ng-click="filterByAlphabet('W')" class="withripple">W</a></li>
                                    <li><a href="javascript:void(0);" ng-click="filterByAlphabet('X')" class="withripple">X</a></li>
                                    <li><a href="javascript:void(0);" ng-click="filterByAlphabet('Y')" class="withripple">Y</a></li>
                                    <li><a href="javascript:void(0);" ng-click="filterByAlphabet('Z')" class="withripple">Z</a></li>
                                </ul>
                            </div>
                        </div>


                        <!-- shows and movies grid -->
                        <div class="portrait-grid-container">

                            <?php for ($i = 0; $i <= 30; $i++) { ?>
                            <div class="grid-item">
                                <div class="grid-item-content"><img class="grid-thumb" src="https://placeholdit.imgix.net/~text?txtsize=45&txt=178%C3%97250&w=178&h=250" /></div>
                            </div>
                            <?php } ?>

                        </div>


                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php include 'inc/footer.php'; ?>