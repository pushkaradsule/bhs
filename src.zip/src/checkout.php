<?php $footer_auto = '0'; include 'inc/head.php'; $page='checkout'; ?>
<div class="zee-content-wrapper no-banner zee-myaccount-body" data-payment="MIIBCgKCAQEAtqwxoY/wYXtN1pSoD8qSdhTLZDwHPzEpQ6Ucrr0JUAAPsMooSGimssgqaxgPJBc+BMJZjFaq0dcnfNSW8JwFap3/rbqVZD5BFyKHi62tE0T0XrabHk8hyoLwHEH4a7zUZmHA6nb7CejOV8Xkuq9BKB2yYK5QyTPjR54OlpkE3+h4H1KSXYtmgYK/kJNRDZm7ets9NNiQfCTfMo7MonVbrSV/lw9JS544hVCpUrc7+W20s3lFF7kG6GDIYBMQboI9eHOp+w7XCANS2MgF9ZZTMYth/Ynwqqp6R4d3WbI0HduKus0dOZETSFHBHk+jwIJ7tMxrFFDtmJZiKVTglnKybwIDAQAB" id="payment-container">
    <div class="my-account-welcome">
        <div class="container">
            <div class="row">
                <h3>Order Summary</h3>
            </div>
        </div>
    </div>
    <div class="container zee-myaccounter-container zee-checkout-container">
        <?php
        /*
        <div class="zee-myaccount-error-message">
        <div class="zee-form-message error"><span class="icon animated infinite flash">
        <img src="/images/icon-error.png"></span>
        <p>The email address or password you entered is incorrect. Passwords are case sensitive. Please try again.</p>
        </div>
        <div class="clearfix" style="height: 20px;"></div>
        </div>
         */
        ?>

        <table class="table table-myaccounts tablesaw tablesaw-stack" data-tablesaw-mode="stack" id="zee_package_checkout_summary">
            <thead>
                <tr>
                    <th>Package</th>
                    <th class="table-cell-right">Plan</th>
                    <th class="table-cell-right">Price</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td><span class="footable-toggle"></span>ZEE Family Pack</td>
                    <td class="table-cell-right">Year</td>
                    <td class="table-cell-right">$ 2,988.00</td>
                </tr>
                <tr>
                    <td><span class="footable-toggle"></span>ZEE Family Marathi Pack</td>
                    <td class="table-cell-right">Year</td>
                    <td class="table-cell-right">$ 1,188.00</td>
                </tr>

            </tbody>
        </table>
        <div class="clearfix" style="height: 20px;"></div>
        
        <div class="row">
            <div class="col-md-6">
                <form class="form-inline">
                    <!-- status message -->
                    <div class="zee-myaccount-error-message">
                        <div class="zee-form-message success">
                            <i class="icon icon-ok-1"></i>
                            <!--<i class="icon icon-info"></i>-->
                            <p>Coupon code applied successfuly!</p>
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Have a coupon code?</label>
                        <input class="form-control" type="text" placeholder="coupon code" />
                        <button class="btn btn-primary">Apply</button>
                    </div>

                </form>
            </div>
            <div class="col-sm-6">

                <div class="checkout-grand-total">
                    <h4 class="checkout-free-trial-lbl">After free 30 day trial</h4>
                    <div class="clearfix"></div>
                    <h3 class="checkout-total-amnt"><span>Total </span>INR  $ 4,176.00</h3>
                </div>
            </div>
        </div>
        <div class="clearfix" style="height: 20px;"></div>
        <div class="row">
           <div class="col-sm-6">
                <div class="form-group">
                    <a href="/selectpackage" class="btn btn-primary">Add / Remove Packages</a>
                </div>
            </div> 
        </div>

        

        <div class="row">

            <form action="/Checkout" autocomplete="off" id="checkoutform" method="post" novalidate="novalidate">
                <input name="__RequestVerificationToken" type="hidden" value="HmO-jXwLFfO-fQGIw2by1MrmwvVX9Hv7XCb4d-yuyf6OKaIV-mUQBZTNUWyEowREoHTVmNEJuYakzNMm5bzMGX1zaoEKY3tOZUTICp4x8EOG9cN72zpHO0kx9WnXml_80">
                <div class="col-md-6">

                    <h4 class="zee-myaccount-subheading">Billing Address</h4>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <input class="form-control floating-label" data-val="true" data-val-required="This field is required." id="FirstName" name="FirstName" placeholder="First Name" type="text" value="">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <input class="form-control floating-label" data-val="true" data-val-required="This field is required." id="LastName" name="LastName" placeholder="Last Name" type="text" value="">
                            </div>
                        </div>


                    </div>
                    <div class="form-group">
                        <input class="form-control floating-label" data-val="true" data-val-required="This field is required." id="BillingAddressLine1" name="BillingAddressLine1" placeholder="Address" type="text" value="">
                    </div>
                    <div class="form-group">
                        <input class="form-control floating-label" id="BillingAddressLine2" name="BillingAddressLine2" placeholder="Address 2 (optional)" type="text" value="">
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <input class="form-control floating-label" data-val="true" data-val-maxlength="You must enter a valid zip/postal code." data-val-maxlength-max="20" data-val-required="This field is required." id="BillingAddressPostCode" name="BillingAddressPostCode" placeholder="Zip Code" type="text" value="">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <input class="form-control floating-label" data-val="true" data-val-required="This field is required." id="BillingAddressCity" name="BillingAddressCity" placeholder="City" type="text" value="">
                            </div>
                        </div>


                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <input class="form-control floating-label" data-val="true" data-val-required="This field is required." id="BillingAddressState" name="BillingAddressState" placeholder="State/Province" type="text" value="">
                            </div>
                        </div>

                    </div>
                    <div class="row">

                        <div class="col-md-3">
                            <div class="form-group">

                                <input class="form-control floating-label" id="PrimaryPhoneCode" name="PrimaryPhoneCode" placeholder="Area Code" type="text" value="">
                            </div>
                        </div>

                        <div class="col-md-9">
                            <div class="form-group">
                                <input class="form-control floating-label" data-val="true" data-val-required="This field is required." id="PrimaryPhone" name="PrimaryPhone" placeholder="Primary Phone" type="text" value="">
                            </div>
                        </div>

                    </div>
                    <div class="form-group">
                        <input class="form-control floating-label" data-val="true" data-val-email="The Email ID is not valid." data-val-required="This field is required." id="SecondaryEmailAddress" name="SecondaryEmailAddress" placeholder="Email" type="text">
                    </div>
                </div>
                <div class="col-md-6">

                    <h4 class="zee-myaccount-subheading">Payment Information</h4>

                    <div class="form-group">
                        <label>Select a payment method</label>
                        <ul class="checkout-payment-options">
                            <li>
                                <div class="radio radio-primary">
                                    <label class="radio-inline">
                                        <input type="radio" name="rd-payment-method" checked="checked" />
                                        Credit Card
                                    </label>
                                </div>
                            </li>
                            <li>
                                <div class="radio radio-primary">
                                    <label class="radio-inline">
                                        <input type="radio" name="rd-payment-method" />
                                        <img src="images/paypal-payment-method.png" class="paypal-lbl-img" />
                                    </label>
                                </div>
                            </li>
                        </ul>
                    </div>

                    <div id="checkout_payment_card_type" style="display: block;">
                        <div class="form-group">
                            <input class="form-control floating-label" data-val="true" data-val-required="This field is required." id="NameOnCard" name="NameOnCard" placeholder="Name on Card" type="text" value="">
                        </div>
                        <div class="form-group">
                            <div class="row">
                                <div class="col-lg-7 col-md-6 checkout-card-number-field">
                                    <input class="form-control floating-label" data-encrypted-name="CardNumber" data-val="true" data-val-required="This field is required." id="CardNumber" name="CardNumber" placeholder="Credit Card Number" type="text" value="">
                                    <p id="ccmessage" class="clearfix checkout-card-provider-validation" style="display: none;"></p>
                                    <ul class="zee-checkout-cards" id="credit-card-type">
                                        <li class="VI">Visa</li>
                                        <li class="MC">Mastercard</li>
                                    </ul>
                                </div>
                                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-8">
                                    <input class="form-control floating-label" data-encrypted-name="CardCode" data-val="true" data-val-required="This field is required." id="CardCode" name="CardCode" placeholder="CVV" type="text" value="">
                                </div>
                                <div class="col-lg-1 col-md-2 col-sm-2 col-xs-2 div-cvv-helper">
                                    <a href="#checkout_cvv_infobox" id="checkout_cvv_helper">
                                        <img src="/images/help-icon.png" class="image-cvv-helper" />
                                    </a>
                                </div>
                            </div>
                        </div>


                        <div class="form-group">
                            <div class="row">
                                <div class="col-md-12">
                                    <label>Expiry date </label>
                                </div>
                                <div class="col-md-12">
                                    <ul class="checkout-card-date">
                                        <li>
                                            <select class="form-control" data-encrypted-name="ExpMonth" data-val="true" data-val-required="This field is required." id="ExpMonth" name="ExpMonth">
                                                <option value="">Month</option>
                                                <option value="01">Jan (1)</option>
                                                <option value="02">Feb (2)</option>
                                                <option value="03">Mar (3)</option>
                                                <option value="04">Apr (4)</option>
                                                <option value="05">May (5)</option>
                                                <option value="06">Jun (6)</option>
                                                <option value="07">Jul (7)</option>
                                                <option value="08">Aug (8)</option>
                                                <option value="09">Sep (9)</option>
                                                <option value="10">Oct (10)</option>
                                                <option value="11">Nov (11)</option>
                                                <option value="12">Dec (12)</option>
                                            </select></li>
                                        <li>
                                            <select class="form-control" data-encrypted-name="ExpYear" data-val="true" data-val-required="This field is required." id="ExpYear" name="ExpYear">
                                                <option value="">Year</option>
                                                <option value="2015">2015</option>
                                                <option value="2016">2016</option>
                                                <option value="2017">2017</option>
                                                <option value="2018">2018</option>
                                                <option value="2019">2019</option>
                                                <option value="2020">2020</option>
                                                <option value="2021">2021</option>
                                                <option value="2022">2022</option>
                                                <option value="2023">2023</option>
                                                <option value="2024">2024</option>
                                                <option value="2025">2025</option>
                                                <option value="2026">2026</option>
                                            </select></li>
                                    </ul>
                                </div>
                            </div>
                        </div>

                    </div>

                    <div id="checkout_payment_payment_type" style="display: block;">
                        <div class="form-group">
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean sit amet mattis mi. Duis vestibulum magna sed libero vestibulum gravida.</p>
                        </div>
                    </div>

                    <div class="form-group">
                        <div class="checkbox checkbox-primary">
                            <label>
                                <input data-val="true" data-val-mandatory="The field Terms &amp; Condition is invalid." data-val-required="The Terms &amp; Condition field is required." id="TermsChecked" name="TermsChecked" type="checkbox" value="true"><input name="TermsChecked" type="hidden" value="false">
                                <span class="checkbox-lbl-txt">You must agree to the <a href="/terms-of-use" target="_blank">Terms of Use </a>and <a href="/privacy-policy" target="_blank">Privacy Policy </a>in order to proceed.</span>
                            </label>
                        </div>
                    </div>

                    <div class="form-group">
                        <button class="btn btn-material-grey" type="reset">CLEAR</button>
                        <button class="btn btn-primary" type="submit">SUBMIT</button>
                    </div>


                </div>
            </form>
        </div>
    </div>
</div>

<div style="display: none">
    <div id="checkout_cvv_infobox">
        <div class="package-info-popup">
            <h3>What is CVV Number?</h3>
            <p>Enjoy it ALL with this comprehensive Hindi package. Watch your favorite dramas, comedies, and reality shows. Stay on top of all things Bollywood, including new films and hit songs, fashion, celebrity interviews and gossip! You will be up-to-date with everything that is going on in the world, from politics to business and sports. Plus, you will have access to India's first 24-hour cooking channel.</p>
            <button class="mfp-close" type="button" title="Close (Esc)">x</button>
        </div>
    </div>
</div>
<?php include 'inc/footer.php'; ?>