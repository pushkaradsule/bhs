<?php include 'inc/head.php'; ?>




<div>
    <div class="zee-header-wrapper">
        <div class="zee-main-banner min-height">
            <ul class="pgwSlider zee-banner-slider" id="zee_main_banner" data-duration="10000">
                <li><a href="show_player.php">
                    <img src="http://res.cloudinary.com/idiso/image/upload/v1408133223/usnwaaqkddjtquzjlsrb.jpg">
                </a></li>

            </ul>
        </div>


    </div>

    <div class="zee-content-wrapper">

        <div class="container"
            data-showname="avantika"
            data-showid="4" id="show-detail-container">
            <div id="show-div" st-table="rowCollection">
                <div class="zee-movies-player-info zee-show-data">
                    <div class="zee-live-channel-data">
                        <h3>Avantika</h3>
                        <ul class="channel-icons show-info-icons">
                            <li class="icon-genre"><span>Drama</span></li>
                            <li class="icon-langugage"><span>Marathi</span></li>
                            <li class="icon-episodes"><span>All Episodes 737</span></li>
                        </ul>
                        <p class="zee-movies-cast"><span>Cast</span>Sandeep Kulkarni,Subodh Bhave,Sulekha Talwalkar,Sunil Barve,Mrinal Kulkarni,Deepa Shreeram,Sharvani Pillai,Shreyas Talpade,Ravindra Mankani,Smita Talwalkar,Purnima Bhave,Shrikant Moghe,Aadesh Bandekar,Sucheta Bandekar,Dr. Girish Oak</p>
                        <p class="zee-movies-synopsis visible-md-inline-block visible-lg-inline-block">
                            <span>Synopsis</span> <span id="zee_show_synopsis_txt">This serial is the story of Avantika (Mrinal Kulkarni), a very intelligent and emotional girl, a true follower of her principles and beliefs. This serial showcases the way Avantika deals with all the trials and tribulations of her life with grit and a strong determination. She is hurt by many but never wavers and her confidence never lets her cower before the difficulties faced by her.
                            </span>
                        </p>
                    </div>
                </div>

                <div class="clearfix" style="height: 20px"></div>

                <div class="zee-show-search row">
                    <div class="show-search-box col-sm-4">
                        <div class="form-group has-feedback">
                            <input type="search" class="form-control" placeholder="Search Episodes" st-search="">
                            <span class="form-control-feedback show-search-icon" aria-hidden="true"></span>
                        </div>
                    </div>
                </div>

                <div class="clearfix" style="height: 20px"></div>

                <div class="row">
                    <h3 class="show-season-heading">Season 1</h3>
                </div>

                <div class="clearfix" style="height: 20px"></div>

                <div class="row">
                    <?php for ($i = 0; $i <= 14; $i++) { ?>
                    <div class="show-episode-grid col-sm-4 col-md-3 col-lg-2 ng-scope">
                        <a class="episode-play" href="show_player.php">
                            <h3 class="ng-binding">Episode <?php echo $i+1 ?></h3>
                            <div class="show-episode-play">
                                <span class="episode-play-icon"></span>
                            </div>
                        </a>
                        <a data-show-info="Avantika (Mrinal Kulkarni) is an intelligent and straight forward girl. She is the daughter of a college professor, Arvind Dixit (Dr. Girish Oak). Sanika (Sharvani Pillai) is her elder sister and Salil (Subodh Bhave) is her brother. Avantika is sure of her goals in life. She is also helpful. Ashwini (Sulekha Talwalkar) is her best friend. Avantika and Ashwini pass their architecture exams. Arvind and Sulbha are worried about Sanika�s marriage. A prospective groom comes to see Sanika but the family is very greedy. Avantika insults them and sends them away. Arvind is proud of her." data-show-episode="Episode 1" data-show-title="Avantika" class="show-episode-info" href="javascript:void(0);">
                            <span class="show-info-icon">
                                <span class="sr-only">show info</span>
                            </span>
                        </a>
                    </div>
                    <?php } ?>
                </div>

                <div class="clearfix" style="height: 20px"></div>

                <div class="show-paging-wrapper row ng-scope">
                    <ul>
                        <?php for ($i = 0; $i <= 14; $i++) { ?>
                        <li class="ng-scope<?php echo ($i == '0' ? ' active' : '') ?>"><a href="#" class="ng-binding"><?php echo $i+1 ?></a></li>
                        <?php } ?>
                    </ul>
                </div>
            </div>


        </div>
    </div>
</div>


<?php include 'inc/footer.php'; ?>