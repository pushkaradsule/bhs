<?php
$page='movies';
$bodyclass = 'search-results-page';
include 'inc/head.php';
?>
<input id="antiForgeryToken" type="hidden" value='Xte4ARRA-I47GWQegL7ehqnzUGVBRVgaFrGcHQtL_VyCg9XWfzYOMLetqaGyliGt3XVvD3u3QzkBp65zD4zHBW6nKQOJZHwD8Oe_azsVAlg1:d2fNuosbXT9KG8uQ4hlqLf1OXvgIe2y86fCZZfBfiUi-QhDmAu-ct05sk0sBvYQbQL3r5Oi9TIRskLAHpqqArdbM81Z9ZoYDfARykGkx28k1' />

<div class="zee-content-wrapper" ng-app="movies">

    <div class="zee-browse-header">
        <div class="zee-browse-header-wrapper">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-xs-12">
                        <h3 class="search-result-heading">
                            Search Results for
                            <span class="search-keyword">@ViewBag.SearchText</span>
                        </h3>
                        <ul class="zee-browse-header-utility">
                            <li>
                                <a href="javascript:void(0)" class="active withripple" data-tab="search_result_movies">Movies</a>
                            </li>
                            <li class="zee-browse-laguage-list-item">
                                <a href="javascript:void(0)" class="withripple" data-tab="search_result_shows">Shows</a>
                            </li>
                            <li class="zee-browse-laguage-list-item">
                                <a href="javascript:void(0)" class="withripple" data-tab="search_result_livetv">Live TV</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="container-fluid search-result-tab grid-container" id="search_result_movies" style="display: block;">
        <div ng-controller="MovieController">
            <div class="clearfix"></div>
            <div class="poster-grid-container portrait-grid-container" infinite-scroll='movieList.nextPage()' infinite-scroll-disabled='movieList.busy || movieList.complete' infinite-scroll-distance='1'>
                <div class="grid-item" ng-repeat="a in movieList.items">
                    <div class="grid-item-content item">
                        <div class="carousel-helper-wrapper">
                            <a href="{{a.Url}}" class="carousel-thumb-action" qtip-assetname="{{a.AssetName}}" qtip-thumbnail="{{a.ImageUrl}}"
                                qtip-genre="{{a.Genre}}"
                                qtip-runningtime="{{a.ShowTime}}"
                                qtip-desc="{{a.HtmlContent}}"
                                qtip-actors="{{a.Actors}}"
                                qtip-year="{{a.YearRelease}}"
                                qtip-language="{{a.Language}}"
                                qtip-location="AsiaTv"
                                qtip-url="{{a.Url}}" qtip=""></a>
                            <span class="carousel-helper carousel-helper-play">
                                <a ng-href="{{a.Url}}">
                                    <i class="icon icon-play-1"></i>
                                </a>
                            </span>
                            <span class="carousel-helper carousel-helper-info">
                                <a href="javascript:void(0);" ng-click="showMobileInfo(a)" class="carousel-mobile-info">
                                    <i class="icon icon-info-1"></i>
                                </a>
                            </span>
                        </div>
                        <img class="grid-thumb" ng-src="{{a.ImageUrl}}" />
                    </div>
                </div>
                <div ng-show='movieList.busy' style="clear: both; margin: 0 auto;">
                    <div class='loading' style='margin-left: 45%;'>
                        <div class='loading-bar big'></div>
                        <div class='loading-bar big'></div>
                        <div class='loading-bar big'></div>
                        <div class='loading-bar big'></div>
                        <div class='loading-bar big'></div>
                        <div class='loading-bar big'></div>
                        <div class='loading-bar big'></div>
                        <div class='loading-bar big'></div>
                        <div class='loading-bar big'></div>
                        <div class='loading-bar big'></div>
                    </div>
                </div>
                <div ng-show='movieList.noResult' style="display: none;">
                    <div class="search-no-result">
                        <i class="icon icon-info-circled-1"></i>
                        Sorry! your search did not match any result
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="container-fluid search-result-tab" id="search_result_shows">
        <div class="poster-grid-container landscape-grid-container">

            <?php for ($i = 0; $i <= 20; $i++) { ?>
            <div class="grid-item">
                <div class="grid-item-content item">
                    <img class="grid-thumb" src="https://placeholdit.imgix.net/~text?txtsize=40&txt=390%C3%97250&w=390&h=250" />
                </div>
            </div>
            <?php } ?>

        </div>
    </div>

    <div class="container-fluid search-result-tab" id="search_result_livetv">
        <div ng-controller="epgSearchController">
            <ul class="search-results-grid">
                <li class="search-grid-items ng-cloak" ng-repeat="epg in EpgItems">
                    <div class="result">

                        <div class="search-live-logo">
                            <img ng-src="{{epg.ChannelLogo}}" class="search-result-channel" alt="{{epg.Title}}" />
                        </div>
                        <div class="search-live-showdetails">
                            <h3>
                                {{epg.Title}}
                                <span class="search-result-onnow" ng-if="isEpgItemOnNow(epg)">ON NOW</span>
                            </h3>
                            <ul class="search-result-info">
                                <li class="search-result-play" ng-show="epg.IsCatchUp">
                                    <a ng-click="catchUpPlay(epg)" href="javascript:void(0);">
                                        <i class="icon icon-play"></i>
                                    </a>
                                </li>
                                <li class="search-result-time">
                                    {{epg.StartDate |  date:'EEE' }} {{epg.StartDate |  date:'dd' }}, {{epg.StartDate |  date:'MMM' }}
                                    <i class="icon icon-clock-alt"></i>
                                    {{epg.StartDate | date:'HH:mm' }}
                                </li>
                            </ul>
                        </div>
                    </div>
                </li>
            </ul>
        </div>
    </div>

</div>


<?php include 'inc/footer.php'; ?>



