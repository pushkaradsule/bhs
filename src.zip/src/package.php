<?php $footer_auto = '0'; include 'inc/head.php'; $page='package'; ?>
<input id="antiForgeryToken" type="hidden" value='Xte4ARRA-I47GWQegL7ehqnzUGVBRVgaFrGcHQtL_VyCg9XWfzYOMLetqaGyliGt3XVvD3u3QzkBp65zD4zHBW6nKQOJZHwD8Oe_azsVAlg1:d2fNuosbXT9KG8uQ4hlqLf1OXvgIe2y86fCZZfBfiUi-QhDmAu-ct05sk0sBvYQbQL3r5Oi9TIRskLAHpqqArdbM81Z9ZoYDfARykGkx28k1' />
<script src="/js/Intl.complete.js?v=14042015" type="text/javascript"></script>

<div class="zee-content-wrapper no-banner zee-myaccount-body">
    <div class="my-account-welcome">
        <div class="container">
            <div class="row">
                <h3>BUILD PACKAGE &amp; PLAN</h3>
            </div>
        </div>
    </div>
    <div class="container zee-myaccounter-container">

        <form action="/en-IN/selectpackage" id="addpackageform" method="post">
            <input name="__RequestVerificationToken" type="hidden" value="1JXoKinj5gr5OopdlSbgsO8Ow1i3S7Y-zYKXU1Tg-1b0TP5lN9kSeBxpqsvkNBejm9OFi_TVoWobb9G0TPw4SkKDtJmEBFUw4-WqNtkOWiU1">
            <h3 class="package-estimate-cost" id="header-cost-monthly">Your total monthly package price: Rs.99.00</h3>
            <div class="package-steps">
                <span class="package-steps-heading">step 1</span>
                <span class="package-steps-description">YOU CAN SELECT MULTIPLE PACKAGES</span>
            </div>
            <ul class="packages-container" data-default-package="0">
                <li class="col-sm-6 col-md-3 col-lg-3">
                    <label for="package_ZEE_Family_Gold" data-cost="08.56">
                        <div class="zee-package-list-title">
                            <h3>ZEE Family Gold</h3>
                            <span class="zee-package-list-cost">$ 08.56/month</span>
                            <div class="zee-package-list-checkbox">
                                <input type="checkbox" class="zee-package-checkbox" id="package_ZEE_Family_Gold">
                            </div>
                        </div>
                    </label>
                    <i class="zee-package-list-info package-info-data"
                        data-package="ZEE Family Gold"
                        data-price="12.00"
                        data-desc="Enjoy it ALL with this comprehensive Hindi package. Watch your favorite dramas, comedies, and reality shows. Stay on top of all things Bollywood, including new films and hit songs, fashion, celebrity interviews and gossip! You will be up-to-date with everything that is going on in the world, from politics to business and sports. Plus, you will have access to India's first 24-hour cooking channel."><span class="sr-only">info</span></i>
                </li>
                <li class="col-sm-6 col-md-3 col-lg-3">
                    <label for="package_ZEE_Family_BollyPack" data-cost="12.00">
                        <div class="zee-package-list-title">
                            <h3>ZEE Family BollyPack</h3>
                            <span class="zee-package-list-cost">$ 12.00/month</span>
                            <div class="zee-package-list-checkbox">
                                <input type="checkbox" class="zee-package-checkbox" id="package_ZEE_Family_BollyPack">
                            </div>
                        </div>
                    </label>
                    <i class="zee-package-list-info package-info-data"
                        data-package="ZEE Family Gold"
                        data-price="12.00"
                        data-desc="Enjoy it ALL with this comprehensive Hindi package. Watch your favorite dramas, comedies, and reality shows. Stay on top of all things Bollywood, including new films and hit songs, fashion, celebrity interviews and gossip! You will be up-to-date with everything that is going on in the world, from politics to business and sports. Plus, you will have access to India's first 24-hour cooking channel."><span class="sr-only">info</span></i>
                </li>
                <li class="col-sm-6 col-md-3 col-lg-3">
                    <label for="package_ZEE_Family_Silver" data-cost="09.23">
                        <div class="zee-package-list-title">
                            <h3>ZEE Family Silver</h3>
                            <span class="zee-package-list-cost">$ 09.23/month</span>
                            <div class="zee-package-list-checkbox">
                                <input type="checkbox" class="zee-package-checkbox" id="package_ZEE_Family_Silver">
                            </div>
                        </div>
                    </label>
                    <i class="zee-package-list-info package-info-data"
                        data-package="ZEE Family Gold"
                        data-price="12.00"
                        data-desc="Enjoy it ALL with this comprehensive Hindi package. Watch your favorite dramas, comedies, and reality shows. Stay on top of all things Bollywood, including new films and hit songs, fashion, celebrity interviews and gossip! You will be up-to-date with everything that is going on in the world, from politics to business and sports. Plus, you will have access to India's first 24-hour cooking channel."><span class="sr-only">info</span></i>
                </li>
                <li class="col-sm-6 col-md-3 col-lg-3">
                    <label for="package_ZEE_Family_NewsPack" data-cost="15.00">
                        <div class="zee-package-list-title">
                            <h3>ZEE Family NewsPack</h3>
                            <span class="zee-package-list-cost">$ 15.00/month</span>
                            <div class="zee-package-list-checkbox">
                                <input type="checkbox" class="zee-package-checkbox" id="package_ZEE_Family_NewsPack">
                            </div>
                        </div>
                    </label>
                    <i class="zee-package-list-info package-info-data"
                        data-package="ZEE Family Gold"
                        data-price="12.00"
                        data-desc="Enjoy it ALL with this comprehensive Hindi package. Watch your favorite dramas, comedies, and reality shows. Stay on top of all things Bollywood, including new films and hit songs, fashion, celebrity interviews and gossip! You will be up-to-date with everything that is going on in the world, from politics to business and sports. Plus, you will have access to India's first 24-hour cooking channel."><span class="sr-only">info</span></i>
                </li>
                <li class="col-sm-6 col-md-3 col-lg-3">
                    <label for="package_ZEE_Family_Preferred_Marathi" data-cost="03.12">
                        <div class="zee-package-list-title">
                            <h3>ZEE Family Preferred - Marathi</h3>
                            <span class="zee-package-list-cost">$ 03.12/month</span>
                            <div class="zee-package-list-checkbox">
                                <input type="checkbox" class="zee-package-checkbox" id="package_ZEE_Family_Preferred_Marathi">
                            </div>
                        </div>
                    </label>
                    <i class="zee-package-list-info package-info-data"
                        data-package="ZEE Family Gold"
                        data-price="12.00"
                        data-desc="Enjoy it ALL with this comprehensive Hindi package. Watch your favorite dramas, comedies, and reality shows. Stay on top of all things Bollywood, including new films and hit songs, fashion, celebrity interviews and gossip! You will be up-to-date with everything that is going on in the world, from politics to business and sports. Plus, you will have access to India's first 24-hour cooking channel."><span class="sr-only">info</span></i>
                </li>
                <li class="col-sm-6 col-md-3 col-lg-3">
                    <label for="package_ZEE_Family_Preferred_Bangla" data-cost="03.00">
                        <div class="zee-package-list-title">
                            <h3>ZEE Family Preferred - Bangla</h3>
                            <span class="zee-package-list-cost">$ 03.00/month</span>
                            <div class="zee-package-list-checkbox">
                                <input type="checkbox" class="zee-package-checkbox" id="package_ZEE_Family_Preferred_Bangla">
                            </div>
                        </div>
                    </label>
                    <i class="zee-package-list-info package-info-data"
                        data-package="ZEE Family Gold"
                        data-price="12.00"
                        data-desc="Enjoy it ALL with this comprehensive Hindi package. Watch your favorite dramas, comedies, and reality shows. Stay on top of all things Bollywood, including new films and hit songs, fashion, celebrity interviews and gossip! You will be up-to-date with everything that is going on in the world, from politics to business and sports. Plus, you will have access to India's first 24-hour cooking channel."><span class="sr-only">info</span></i>
                </li>
                <li class="col-sm-6 col-md-3 col-lg-3">
                    <label for="package_ZEE_Family_Preferred_Punjabi" data-cost="05.13">
                        <div class="zee-package-list-title">
                            <h3>ZEE Family Preferred - Punjabi</h3>
                            <span class="zee-package-list-cost">$ 05.13/month</span>
                            <div class="zee-package-list-checkbox">
                                <input type="checkbox" class="zee-package-checkbox" id="package_ZEE_Family_Preferred_Punjabi">
                            </div>
                        </div>
                    </label>
                    <i class="zee-package-list-info package-info-data"
                        data-package="ZEE Family Gold"
                        data-price="12.00"
                        data-desc="Enjoy it ALL with this comprehensive Hindi package. Watch your favorite dramas, comedies, and reality shows. Stay on top of all things Bollywood, including new films and hit songs, fashion, celebrity interviews and gossip! You will be up-to-date with everything that is going on in the world, from politics to business and sports. Plus, you will have access to India's first 24-hour cooking channel."><span class="sr-only">info</span></i>
                </li>
                <li class="col-sm-6 col-md-3 col-lg-3">
                    <label for="package_ZEE_VOD_PACKAGE" data-cost="02.00">
                        <div class="zee-package-list-title">
                            <h3>ZEE VOD PACKAGE</h3>
                            <span class="zee-package-list-cost">$ 02.00/month</span>
                            <div class="zee-package-list-checkbox">
                                <input type="checkbox" class="zee-package-checkbox" id="package_ZEE_VOD_PACKAGE">
                            </div>
                        </div>
                    </label>
                    <i class="zee-package-list-info package-info-data"
                        data-package="ZEE Family Gold"
                        data-price="12.00"
                        data-desc="Enjoy it ALL with this comprehensive Hindi package. Watch your favorite dramas, comedies, and reality shows. Stay on top of all things Bollywood, including new films and hit songs, fashion, celebrity interviews and gossip! You will be up-to-date with everything that is going on in the world, from politics to business and sports. Plus, you will have access to India's first 24-hour cooking channel."><span class="sr-only">info</span></i>
                </li>
                <li class="col-sm-6 col-md-3 col-lg-3">
                    <label for="package_ZEE_Kannada" data-cost="18.56">
                        <div class="zee-package-list-title">
                            <h3>ZEE Kannada</h3>
                            <span class="zee-package-list-cost">$ 18.56/month</span>
                            <div class="zee-package-list-checkbox">
                                <input type="checkbox" class="zee-package-checkbox" id="package_ZEE_Kannada">
                            </div>
                        </div>
                    </label>
                    <i class="zee-package-list-info package-info-data"
                        data-package="ZEE Family Gold"
                        data-price="12.00"
                        data-desc="Enjoy it ALL with this comprehensive Hindi package. Watch your favorite dramas, comedies, and reality shows. Stay on top of all things Bollywood, including new films and hit songs, fashion, celebrity interviews and gossip! You will be up-to-date with everything that is going on in the world, from politics to business and sports. Plus, you will have access to India's first 24-hour cooking channel."><span class="sr-only">info</span></i>
                </li>
                <li class="col-sm-6 col-md-3 col-lg-3">
                    <label for="package_ZEE_Jagran" data-cost="08.56">
                        <div class="zee-package-list-title">
                            <h3>ZEE Jagran</h3>
                            <span class="zee-package-list-cost">$ 08.56/month</span>
                            <div class="zee-package-list-checkbox">
                                <input type="checkbox" class="zee-package-checkbox" id="package_ZEE_Jagran">
                            </div>
                        </div>
                    </label>
                    <i class="zee-package-list-info package-info-data"
                        data-package="ZEE Family Gold"
                        data-price="12.00"
                        data-desc="Enjoy it ALL with this comprehensive Hindi package. Watch your favorite dramas, comedies, and reality shows. Stay on top of all things Bollywood, including new films and hit songs, fashion, celebrity interviews and gossip! You will be up-to-date with everything that is going on in the world, from politics to business and sports. Plus, you will have access to India's first 24-hour cooking channel."><span class="sr-only">info</span></i>
                </li>
                <li class="col-sm-6 col-md-3 col-lg-3">
                    <label for="package_ZEE_Salaam" data-cost="15.00">
                        <div class="zee-package-list-title">
                            <h3>ZEE Salaam</h3>
                            <span class="zee-package-list-cost">$ 15.00/month</span>
                            <div class="zee-package-list-checkbox">
                                <input type="checkbox" class="zee-package-checkbox" id="package_ZEE_Salaam">
                            </div>
                        </div>
                    </label>
                    <i class="zee-package-list-info package-info-data"
                        data-package="ZEE Family Gold"
                        data-price="12.00"
                        data-desc="Enjoy it ALL with this comprehensive Hindi package. Watch your favorite dramas, comedies, and reality shows. Stay on top of all things Bollywood, including new films and hit songs, fashion, celebrity interviews and gossip! You will be up-to-date with everything that is going on in the world, from politics to business and sports. Plus, you will have access to India's first 24-hour cooking channel."><span class="sr-only">info</span></i>
                </li>
                <li class="col-sm-6 col-md-3 col-lg-3">
                    <label for="package_ZEE_Telugu" data-cost="00.99">
                        <div class="zee-package-list-title">
                            <h3>ZEE Telugu</h3>
                            <span class="zee-package-list-cost">$ 00.99/month</span>
                            <div class="zee-package-list-checkbox">
                                <input type="checkbox" class="zee-package-checkbox" id="package_ZEE_Telugu">
                            </div>
                        </div>
                    </label>
                    <i class="zee-package-list-info package-info-data"
                        data-package="ZEE Family Gold"
                        data-price="12.00"
                        data-desc="Enjoy it ALL with this comprehensive Hindi package. Watch your favorite dramas, comedies, and reality shows. Stay on top of all things Bollywood, including new films and hit songs, fashion, celebrity interviews and gossip! You will be up-to-date with everything that is going on in the world, from politics to business and sports. Plus, you will have access to India's first 24-hour cooking channel."><span class="sr-only">info</span></i>
                </li>
                <li class="col-sm-6 col-md-3 col-lg-3">
                    <label for="package_ZEE_Bollywood" data-cost="12.15">
                        <div class="zee-package-list-title">
                            <h3>ZEE Bollywood</h3>
                            <span class="zee-package-list-cost">$ 12.15/month</span>
                            <div class="zee-package-list-checkbox">
                                <input type="checkbox" class="zee-package-checkbox" id="package_ZEE_Bollywood">
                            </div>
                        </div>
                    </label>
                    <i class="zee-package-list-info package-info-data"
                        data-package="ZEE Family Gold"
                        data-price="12.00"
                        data-desc="Enjoy it ALL with this comprehensive Hindi package. Watch your favorite dramas, comedies, and reality shows. Stay on top of all things Bollywood, including new films and hit songs, fashion, celebrity interviews and gossip! You will be up-to-date with everything that is going on in the world, from politics to business and sports. Plus, you will have access to India's first 24-hour cooking channel."><span class="sr-only">info</span></i>
                </li>
                <li class="col-sm-6 col-md-3 col-lg-3">
                    <label for="package_ZEE_Lamhe" data-cost="13.15">
                        <div class="zee-package-list-title">
                            <h3>ZEE Lamhe</h3>
                            <span class="zee-package-list-cost">$ 13.15/month</span>
                            <div class="zee-package-list-checkbox">
                                <input type="checkbox" class="zee-package-checkbox" id="package_ZEE_Lamhe">
                            </div>
                        </div>
                    </label>
                    <i class="zee-package-list-info package-info-data"
                        data-package="ZEE Family Gold"
                        data-price="12.00"
                        data-desc="Enjoy it ALL with this comprehensive Hindi package. Watch your favorite dramas, comedies, and reality shows. Stay on top of all things Bollywood, including new films and hit songs, fashion, celebrity interviews and gossip! You will be up-to-date with everything that is going on in the world, from politics to business and sports. Plus, you will have access to India's first 24-hour cooking channel."><span class="sr-only">info</span></i>
                </li>
                <li class="col-sm-6 col-md-3 col-lg-3">
                    <label for="package_ZEE_Tamil" data-cost="03.33">
                        <div class="zee-package-list-title">
                            <h3>ZEE Tamil</h3>
                            <span class="zee-package-list-cost">$ 03.33/month</span>
                            <div class="zee-package-list-checkbox">
                                <input type="checkbox" class="zee-package-checkbox" id="package_ZEE_Tamil">
                            </div>
                        </div>
                    </label>
                    <i class="zee-package-list-info package-info-data"
                        data-package="ZEE Family Gold"
                        data-price="12.00"
                        data-desc="Enjoy it ALL with this comprehensive Hindi package. Watch your favorite dramas, comedies, and reality shows. Stay on top of all things Bollywood, including new films and hit songs, fashion, celebrity interviews and gossip! You will be up-to-date with everything that is going on in the world, from politics to business and sports. Plus, you will have access to India's first 24-hour cooking channel."><span class="sr-only">info</span></i>
                </li>
                <li class="col-sm-6 col-md-3 col-lg-3">
                    <label for="package_ZEE_Cinema" data-cost="09.99">
                        <div class="zee-package-list-title">
                            <h3>ZEE Cinema</h3>
                            <span class="zee-package-list-cost">$ 09.99/month</span>
                            <div class="zee-package-list-checkbox">
                                <input type="checkbox" class="zee-package-checkbox" id="package_ZEE_Cinema">
                            </div>
                        </div>
                    </label>
                    <i class="zee-package-list-info package-info-data"
                        data-package="ZEE Family Gold"
                        data-price="12.00"
                        data-desc="Enjoy it ALL with this comprehensive Hindi package. Watch your favorite dramas, comedies, and reality shows. Stay on top of all things Bollywood, including new films and hit songs, fashion, celebrity interviews and gossip! You will be up-to-date with everything that is going on in the world, from politics to business and sports. Plus, you will have access to India's first 24-hour cooking channel."><span class="sr-only">info</span></i>
                </li>
                <li class="col-sm-6 col-md-3 col-lg-3">
                    <label for="package_ZEE TV HD" data-cost="15.00">
                        <div class="zee-package-list-title">
                            <h3>ZEE TV HD</h3>
                            <span class="zee-package-list-cost">$ 15.00/month</span>
                            <div class="zee-package-list-checkbox">
                                <input type="checkbox" class="zee-package-checkbox" id="package_ZEE TV HD">
                            </div>
                        </div>
                    </label>
                    <i class="zee-package-list-info package-info-data"
                        data-package="ZEE Family Gold"
                        data-price="12.00"
                        data-desc="Enjoy it ALL with this comprehensive Hindi package. Watch your favorite dramas, comedies, and reality shows. Stay on top of all things Bollywood, including new films and hit songs, fashion, celebrity interviews and gossip! You will be up-to-date with everything that is going on in the world, from politics to business and sports. Plus, you will have access to India's first 24-hour cooking channel."><span class="sr-only">info</span></i>
                </li>
            </ul>

            
            <div class="clearfix" style="height: 40px;" id="package_pricing_seperator"></div>
            <div class="package-steps">
                <span class="package-steps-heading">step 2</span>
                <span class="package-steps-description">select a payment plan</span>
            </div>
            <div class="clearfix" style="height: 40px;"></div>
            <div class="zee-package-pricing-row clearfix">

                <div class="col-sm-3 zee-package-pricing-table" id="M2M">
                    <button type="button" name="Term" value="M2M">
                        <div class="zee-package-pricing-table-data">
                            <h3>1 Month</h3>
                            <div class="zee-package-pricing-cost" id="monthly">Rs.99.00</div>
                            <div class="zee-package-pricing-savings"></div>
                            <div class="zee-package-pricing-activate">Select</div>

                        </div>
                    </button>
                </div>
                <div class="col-sm-3 zee-package-pricing-table" id="QUARTER">
                    <button type="button" name="Term" value="QUARTER">
                        <div class="zee-package-pricing-table-data">
                            <h3>3 Months</h3>
                            <div class="zee-package-pricing-cost" id="threemonth">Rs.297.00</div>
                            <div class="zee-package-pricing-savings"></div>
                            <div class="zee-package-pricing-activate">Select</div>

                        </div>
                    </button>
                </div>
                <div class="col-sm-3 zee-package-pricing-table" id="HALF-YEAR">
                    <button type="button" name="Term" value="HALF-YEAR">
                        <div class="zee-package-pricing-table-data">
                            <h3>6 Months</h3>
                            <div class="zee-package-pricing-cost" id="sixmonth">Rs.594.00</div>
                            <div class="zee-package-pricing-savings"></div>
                            <div class="zee-package-pricing-activate">Select</div>

                        </div>
                    </button>
                </div>
                <div class="col-sm-3 zee-package-pricing-table zee-package-popular" id="YEAR">
                    <button type="button" name="Term" value="YEAR">
                        <div class="zee-package-pricing-table-data">
                            <h3>12 Months</h3>
                            <div class="zee-package-pricing-cost" id="yearly">Rs.1,188.00</div>
                            <div class="zee-package-pricing-savings"></div>
                            <div class="zee-package-pricing-activate">Select</div>

                        </div>
                    </button>
                </div>

            </div>
            <div class="clearfix" style="height: 50px;"></div>
            <div class="form-group text-right">
                <button class="btn btn-primary" type="button" id="btnNext">Next</button>
            </div>
            <input type="hidden" name="termRadio" id="selectTerm" value="YEAR">
        </form>

    </div>
</div>

<?php include 'inc/footer.php'; ?>
