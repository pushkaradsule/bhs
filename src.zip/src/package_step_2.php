<?php
include 'inc/head.php';
$page='checkout';
?>

<div class="zee-content-wrapper zee-myaccount-body">
    <div class="my-account-welcome">
        <div class="container">
            <div class="row">
                <h3>Pick the package that's right for you</h3>
            </div>
        </div>
    </div>

    <div class="container zee-myaccounter-container">

        <div class="zee-scratchcard-notice">
            <p>
                Do you have a scratch card?
                <a href="#">Redeem now!</a>
            </p>
        </div>

        <div class="package-accordian">

            <div class="container-fluid">
                <div class="row">
                    <div class="package-accordian-body">

                        <div class="heading">
                            Packages
                            <hr class="seperator" style="border-color: transparent; margin: 10px 0;" />
                        </div>

                        <div class="packages-platform-info">
                            <ul class="packages-platform-list">
                                <li>
                                    <p>Your subscription is available on all of these platforms!</p>
                                </li>
                                <li>
                                    <img src="images/packages-platform-desktop.png" />
                                </li>
                                <li>
                                    <img src="images/packages-platform-apple.png" />
                                </li>
                                <li>
                                    <img src="images/packages-platform-android.png" />
                                </li>
                                <li>
                                    <img src="images/packages-platform-kindlefire.png" />
                                </li>
                                <li>
                                    <img src="images/packages-platform-samsung.png" />
                                </li>
                                <li>
                                    <img src="images/packages-platform-kindletv.png" />
                                </li>
                            </ul>
                        </div>

                        <div class="packages-item-wrapper">
                            <ul class="packages-item-list">
                                <li>
                                    <div class="packages-grid-outer">
                                        <label class="packages-grid-label" for="package_all_in_one">
                                            <div class="packages-grid-header">
                                                <h4>All in One</h4>
                                                <input type="checkbox" id="package_all_in_one" class="packages-grid-checkbox" />
                                                <div class="packages-grid-tickmark">
                                                    <span></span>
                                                </div>
                                            </div>
                                            <div class="packages-grid-channels">
                                                <ul class="packages-grid-channels-list">
                                                    <li class="packages-grid-channels-icon">
                                                        <img src="images/packages-grid-channels-img.png" />
                                                    </li>
                                                    <li class="packages-grid-channels-count">
                                                        <span class="packages-grid-channels-count-number">25+</span>
                                                        <span class="packages-grid-channels-count-label">LIVE CHANNELS</span>
                                                    </li>
                                                    <li class="packages-grid-channels-view">
                                                        <a href="#package_channels_win" class="package-view-channels-btn">
                                                            <span class="packages-grid-channels-view-txt">VIEW</span>
                                                            <span class="packages-grid-channels-view-channel">CHANNELS</span>
                                                            <span class="packages-grid-channels-view-icon">
                                                                <i class="icon icon-down-open"></i>
                                                            </span>
                                                        </a>
                                                    </li>
                                                </ul>
                                            </div>
                                            <div class="packages-grid-channels-features">
                                                <ul class="packages-grid-channels-features-list">
                                                    <li>
                                                        <i class="iocn icon-arrows-cw"></i>
                                                        30 Day Catch-Up
                                                    </li>
                                                    <li>
                                                        <i class="iocn icon-videoplayer20"></i>
                                                        2000+ Movies
                                                    </li>
                                                    <li>
                                                        <i class="iocn icon-theatre"></i>
                                                        Full Show Library
                                                    </li>
                                                </ul>
                                            </div>
                                            <div class="packages-grid-channels-price">
                                                <span class="packages-grid-channels-price-old">$29.99/mo</span>
                                                <span class="packages-grid-channels-price-new">$24.99/mo</span>
                                            </div>
                                            <div class="packages-grid-channels-footer">
                                                <p>
                                                    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur egestas eget ante nec pellentesque. Aliquam quis sem iaculis, blandit lorem sed
                                                    <a href="#package_channel_infotxt" class="package-view-channels-btn">more</a>
                                                    ..
                                                </p>
                                            </div>
                                        </label>
                                    </div>
                                </li>
                                <li>
                                    <div class="packages-grid-outer">
                                        <label class="packages-grid-label" for="package_live_tv">
                                            <div class="packages-grid-header">
                                                <h4>Live TV</h4>
                                                <input type="checkbox" id="package_live_tv" class="packages-grid-checkbox" />
                                                <div class="packages-grid-tickmark">
                                                    <span></span>
                                                </div>
                                            </div>
                                            <div class="packages-grid-channels">
                                                <ul class="packages-grid-channels-list">
                                                    <li class="packages-grid-channels-icon">
                                                        <img src="images/packages-grid-channels-img.png" />
                                                    </li>
                                                    <li class="packages-grid-channels-count">
                                                        <span class="packages-grid-channels-count-number">25+</span>
                                                        <span class="packages-grid-channels-count-label">LIVE CHANNELS</span>
                                                    </li>
                                                    <li class="packages-grid-channels-view">
                                                        <a href="#package_channels_win" class="package-view-channels-btn">
                                                            <span class="packages-grid-channels-view-txt">VIEW</span>
                                                            <span class="packages-grid-channels-view-channel">CHANNELS</span>
                                                            <span class="packages-grid-channels-view-icon">
                                                                <i class="icon icon-down-open"></i>
                                                            </span>
                                                        </a>
                                                    </li>
                                                </ul>
                                            </div>
                                            <div class="packages-grid-channels-features">
                                                <ul class="packages-grid-channels-features-list">
                                                    <li>
                                                        <i class="iocn icon-arrows-cw"></i>
                                                        30 Day Catch-Up
                                                    </li>
                                                </ul>
                                            </div>
                                            <div class="packages-grid-channels-price">
                                                <span class="packages-grid-channels-price-old">$29.99/mo</span>
                                                <span class="packages-grid-channels-price-new">$19.99/mo</span>
                                            </div>
                                            <div class="packages-grid-channels-footer">
                                                <p>
                                                    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur egestas eget ante nec pellentesque. Aliquam quis sem iaculis, blandit lorem sed
                                                    <a href="#package_channel_infotxt" class="package-view-channels-btn">more</a>
                                                    ..
                                                </p>
                                            </div>
                                        </label>
                                    </div>
                                </li>
                                <li>
                                    <div class="packages-grid-outer">
                                        <label class="packages-grid-label" for="package_movies_shows">
                                            <div class="packages-grid-header">
                                                <h4>Movies & Shows</h4>
                                                <input type="checkbox" id="package_movies_shows" class="packages-grid-checkbox" />
                                                <div class="packages-grid-tickmark">
                                                    <span></span>
                                                </div>
                                            </div>
                                            <div class="packages-grid-channels">
                                                <ul class="packages-grid-channels-list">
                                                    <li class="packages-grid-channels-icon">
                                                        <img src="images/packages-grid-channels-img.png" />
                                                    </li>
                                                    <li class="packages-grid-channels-count">
                                                        <span class="packages-grid-channels-count-number">25+</span>
                                                        <span class="packages-grid-channels-count-label">LIVE CHANNELS</span>
                                                    </li>
                                                    <li class="packages-grid-channels-view">
                                                        <a href="#package_channels_win" class="package-view-channels-btn">
                                                            <span class="packages-grid-channels-view-txt">VIEW</span>
                                                            <span class="packages-grid-channels-view-channel">CHANNELS</span>
                                                            <span class="packages-grid-channels-view-icon">
                                                                <i class="icon icon-down-open"></i>
                                                            </span>
                                                        </a>
                                                    </li>
                                                </ul>
                                            </div>
                                            <div class="packages-grid-channels-features">
                                                <ul class="packages-grid-channels-features-list">
                                                    <li>
                                                        <i class="iocn icon-videoplayer20"></i>
                                                        2000+ Movies
                                                    </li>
                                                    <li>
                                                        <i class="iocn icon-theatre"></i>
                                                        Full Show Library
                                                    </li>
                                                </ul>
                                            </div>
                                            <div class="packages-grid-channels-price">
                                                <span class="packages-grid-channels-price-old">$7.99/mo</span>
                                                <span class="packages-grid-channels-price-new">$4.99/mo</span>
                                            </div>
                                            <div class="packages-grid-channels-footer">
                                                <p>
                                                    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur egestas eget ante nec pellentesque. Aliquam quis sem iaculis, blandit lorem sed
                                                    <a href="#package_channel_infotxt" class="package-view-channels-btn">more</a>
                                                    ..
                                                </p>
                                            </div>
                                        </label>
                                    </div>
                                </li>
                            </ul>
                        </div>

                        <hr class="seperator" style="border-color: transparent; margin: 10px 0" />

                        <h2 class="title-line">
                            <span>Subscription Plan</span>
                        </h2>

                        <hr class="seperator" style="border-color: transparent; margin: 10px 0 30px" />

                        <div class="package-subs-radio-wrapper">
                            <ul>
                                <li>
                                    <label for="subscription-monthly-radio" class="subscription-active">
                                        <input type="radio" id="subscription-monthly-radio" name="subscription-radio" />
                                        <span>Monthly</span>
                                    </label>
                                </li>
                                <li>
                                    <label for="subscription-quarterly-radio">
                                        <input type="radio" id="subscription-quarterly-radio" name="subscription-radio" />
                                        <span>Quarterly</span>
                                    </label>
                                </li>
                                <li>
                                    <label for="subscription-halfyearly-radio">
                                        <input type="radio" id="subscription-halfyearly-radio" name="subscription-radio" />
                                        <span>Half Yearly</span>
                                    </label>
                                </li>
                                <li>
                                    <label for="subscription-yearly-radio">
                                        <input type="radio" id="subscription-yearly-radio" name="subscription-radio" />
                                        <span>Yearly</span>
                                    </label>
                                </li>
                            </ul>
                        </div>

                        <hr class="seperator" style="border-color: transparent; margin: 40px 0 10px" />

                        <h2 class="title-line">
                            <span>Offers</span>
                        </h2>

                        <hr class="seperator" style="border-color: transparent; margin: 10px 0" />

                        <p class="packages-offer-notice">Pick the best offer for you</p>

                        <div class="packages-offer-wrapper">
                            <ul>
                                <li>
                                    <label for="package-offer-1">
                                        <input type="radio" id="package-offer-1" name="package-offer-radio" checked="checked" />
                                        <span>15% OFF on yearly subscription plan</span>
                                    </label>
                                </li>
                                <li>
                                    <label for="package-offer-2">
                                        <input type="radio" id="package-offer-2" name="package-offer-radio" />
                                        <span>10% OFF on half yearly subscription plan</span>
                                    </label>
                                </li>
                                <li>
                                    <label for="package-offer-3">
                                        <input type="radio" id="package-offer-3" name="package-offer-radio" />
                                        <span>5% OFF on quarterly subscription plan</span>
                                    </label>
                                </li>
                            </ul>
                        </div>

                        <hr class="seperator" style="border-color: transparent; margin: 10px 0 30px" />

                        <div class="container-fluid">
                        <div class="row package-amount-info">
                            <div class="col-md-6 has-coupon">
                                <span class="package-coupon-icon"></span>
                                <div id="package_coupon_code" class="package-coupon-code">
                                    Coupon code <strong>HAPPY25</strong>
                                    <br/><a href="javascript:void(0)" class="package-remove-coupon">Remove Coupon</a>
                                </div>
                                <div id="package_coupon_form" class="package-coupon-form" style="display:none">
                                    <form class="form-inline">
                                        <div class="form-group">
                                            <label>Coupon Code: </label>
                                            <input type="text" class="form-control">
                                        </div>
                                        <button type="button" class="btn btn-primary">Apply</button>
                                    </form>
                                </div>
                                </div>
                            <div class="col-md-6 package-amount-footer text-right">
                                <span class="package-total-notice">After FREE 30 Days Trial</span>
                                <span class="package-total-amount">Total <strong class="amount-cancel">INR 3,450</strong> <strong>INR 3,200</strong></span>
                            </div>
                        </div>
                        </div>

                        <hr class="seperator" style="border-color: transparent; margin: 10px 0;" />

                        <div class="row">
                            <div class="col-md-12">


                                <table class="table table-myaccounts tablesaw tablesaw-stack" data-tablesaw-mode="stack" id="zee_package_checkout_summary">
                                    <thead>
                                        <tr>
                                            <th>Package</th>
                                            <th class="table-cell-right">Plan</th>
                                            <th class="table-cell-right">Price</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>
                                                <span class="footable-toggle"></span>
                                                ZEE Family Pack
                                            </td>
                                            <td class="table-cell-right">Year</td>
                                            <td class="table-cell-right">$ 2,988.00</td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <span class="footable-toggle"></span>
                                                ZEE Family Marathi Pack
                                            </td>
                                            <td class="table-cell-right">Year</td>
                                            <td class="table-cell-right">$ 1,188.00</td>
                                        </tr>

                                    </tbody>
                                </table>
                                <hr class="seperator" style="border-color: transparent; margin: 10px 0;" />
                            </div>

                        </div>

                        <div class="row">
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <a href="javascript:void(0)" class="btn btn-primary">Add / Remove Packages</a>
                                </div>
                            </div>
                        </div>


                        <div class="row">
                            <div class="col-md-6">
                                <form action="/Checkout" autocomplete="off" id="checkoutform" method="post" novalidate="novalidate">
                                    <h4 class="zee-myaccount-subheading">Payment Information</h4>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="zee-myaccount-error-message">
                                                <div class="zee-form-message error">
                                                    <!--<i class="icon icon-ok-1"></i>-->
                                                    <i class="icon icon-info"></i>
                                                    <p>error message</p>
                                                </div>
                                            </div>
                                            <div class="clearfix" style="height: 15px"></div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label>Select a payment method</label>
                                        <ul class="checkout-payment-options">
                                            <li>
                                                <div class="radio radio-primary">
                                                    <label class="radio-inline">
                                                        <input type="radio" name="rd-payment-method" checked="checked" />
                                                        Credit Card
                                                    </label>
                                                </div>
                                            </li>
                                            <li>
                                                <div class="radio radio-primary">
                                                    <label class="radio-inline">
                                                        <input type="radio" name="rd-payment-method" />
                                                        <img src="images/paypal-payment-method.png" class="paypal-lbl-img" />
                                                    </label>
                                                </div>
                                            </li>
                                        </ul>
                                    </div>
                                    <div id="checkout_payment_card_type" style="display: block;">
                                        <div class="form-group">
                                            <label>Name on Card</label>
                                            <input class="form-control" data-val="true" data-val-required="This field is required." id="NameOnCard" name="NameOnCard" type="text" value="">
                                        </div>
                                        <div class="form-group">
                                            <div class="row">
                                                <div class="col-lg-7 col-md-6 checkout-card-number-field">
                                                    <label>Credit Card Number</label>
                                                    <input class="form-control" data-encrypted-name="CardNumber" data-val="true" data-val-required="This field is required." id="CardNumber" name="CardNumber" type="text" value="">
                                                    <p id="ccmessage" class="clearfix checkout-card-provider-validation" style="display: none;"></p>
                                                    <ul class="zee-checkout-cards" id="credit-card-type">
                                                        <li class="VI">Visa</li>
                                                        <li class="MC">Mastercard</li>
                                                    </ul>
                                                </div>
                                                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-8">
                                                    <label>CVV</label>
                                                    <input class="form-control" data-encrypted-name="CardCode" data-val="true" data-val-required="This field is required." id="CardCode" name="CardCode" type="text" value="">
                                                </div>
                                                <div class="col-lg-1 col-md-2 col-sm-2 col-xs-2 div-cvv-helper">
                                                    <a href="#checkout_cvv_infobox" id="checkout_cvv_helper">
                                                        <img src="/images/help-icon.png" class="image-cvv-helper" />
                                                    </a>
                                                </div>
                                            </div>
                                        </div>


                                        <div class="form-group">
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <label>Expiry date </label>
                                                </div>
                                                <div class="col-md-12">
                                                    <ul class="checkout-card-date">
                                                        <li>
                                                            <select class="form-control" data-encrypted-name="ExpMonth" data-val="true" data-val-required="This field is required." id="ExpMonth" name="ExpMonth">
                                                                <option value="">Month</option>
                                                                <option value="01">Jan (1)</option>
                                                                <option value="02">Feb (2)</option>
                                                                <option value="03">Mar (3)</option>
                                                                <option value="04">Apr (4)</option>
                                                                <option value="05">May (5)</option>
                                                                <option value="06">Jun (6)</option>
                                                                <option value="07">Jul (7)</option>
                                                                <option value="08">Aug (8)</option>
                                                                <option value="09">Sep (9)</option>
                                                                <option value="10">Oct (10)</option>
                                                                <option value="11">Nov (11)</option>
                                                                <option value="12">Dec (12)</option>
                                                            </select>
                                                        </li>
                                                        <li>
                                                            <select class="form-control" data-encrypted-name="ExpYear" data-val="true" data-val-required="This field is required." id="ExpYear" name="ExpYear">
                                                                <option value="">Year</option>
                                                                <option value="2015">2015</option>
                                                                <option value="2016">2016</option>
                                                                <option value="2017">2017</option>
                                                                <option value="2018">2018</option>
                                                                <option value="2019">2019</option>
                                                                <option value="2020">2020</option>
                                                                <option value="2021">2021</option>
                                                                <option value="2022">2022</option>
                                                                <option value="2023">2023</option>
                                                                <option value="2024">2024</option>
                                                                <option value="2025">2025</option>
                                                                <option value="2026">2026</option>
                                                            </select>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                    <div id="checkout_payment_payment_type" style="display: block;">
                                        <div class="form-group">
                                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean sit amet mattis mi. Duis vestibulum magna sed libero vestibulum gravida.</p>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <div class="checkbox checkbox-primary">
                                            <label>
                                                <input data-val="true" data-val-mandatory="The field Terms &amp; Condition is invalid." data-val-required="The Terms &amp; Condition field is required." id="TermsChecked" name="TermsChecked" type="checkbox" value="true"><input name="TermsChecked" type="hidden" value="false">
                                                <span class="checkbox-lbl-txt">You must agree to the <a href="/terms-of-use" target="_blank">Terms of Use </a>and <a href="/privacy-policy" target="_blank">Privacy Policy </a>in order to proceed.</span>
                                            </label>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <button class="btn btn-primary" type="submit">Checkout</button>
                                    </div>
                                </form>
                            </div>
                        </div>

                    </div>
                </div>
            </div>

        </div>


    </div>


</div>

<div style="display: none">
    <div id="checkout_cvv_infobox">
        <div class="package-info-popup">
            <h3>What is CVV Number?</h3>
            <p>Enjoy it ALL with this comprehensive Hindi package. Watch your favorite dramas, comedies, and reality shows. Stay on top of all things Bollywood, including new films and hit songs, fashion, celebrity interviews and gossip! You will be up-to-date with everything that is going on in the world, from politics to business and sports. Plus, you will have access to India's first 24-hour cooking channel.</p>
            <button class="mfp-close" type="button" title="Close (Esc)">x</button>
        </div>
    </div>
</div>
<div style="display: none;">
    <div class="package-channels-window" id="package_channels_win">
        <div class="package-channels-window-header">
            <h3>All in One</h3>
            <a href="#" id="zee_close_package_win">
                <i class="icon icon-cancel"></i>
            </a>
        </div>
        <div class="package-channels-window-body">
            <ul>
                <?php for ($x = 0; $x <= 12; $x++) { ?>
                <li>
                    <img src="images/channel-logos/ZeeCinema.png" />
                    <label>ZEE Cinema</label>
                </li>
                <?php } ?>
            </ul>
        </div>
    </div>
</div>
<div style="display: none;">
    <div class="package-channels-window" id="package_channel_infotxt">
        <div class="package-channels-window-header">
            <h3>All in One</h3>
            <a href="#" id="zee_close_package_info">
                <i class="icon icon-cancel"></i>
            </a>
        </div>
        <div class="package-channels-window-body">
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque sit amet arcu lorem. Curabitur ultrices ac odio sit amet vestibulum. Nullam nec arcu tempor, commodo turpis iaculis, condimentum ex. Nulla pulvinar odio a felis posuere, a luctus lorem varius. Quisque dignissim a elit sed lobortis. Maecenas eget sagittis lacus, non suscipit diam. Nam gravida enim tristique sem tristique pellentesque. Sed elementum semper mi vitae condimentum.</p>
        </div>
    </div>
</div>
<?php include 'inc/footer.php'; ?>

<script>
    (function ($) {

        "use strict";

        $(document).ready(function () {

            $('.packages-grid-checkbox').each(function () {
                var ts_ch = $(this),
                    ts_parent = ts_ch.parents('.packages-grid-outer');

                if (ts_ch.is(':checked')) {
                    ts_parent.addClass('checkbox-active');
                }
                else {
                    ts_parent.removeClass('checkbox-active');
                }

                ts_ch.on('change', function () {
                    if (ts_ch.is(':checked')) {
                        ts_parent.addClass('checkbox-active');
                    }
                    else {
                        ts_parent.removeClass('checkbox-active');
                    }
                });

            });

            $('input[name=subscription-radio]').each(function () {
                var ts_sc = $(this),
                    sc_parent = ts_sc.parents('label');

                if (ts_sc.is(':checked')) {
                    sc_parent.addClass('subscription-active');
                }

                ts_sc.on('change', function () {

                    $('input[name=subscription-radio]').parents('label').removeClass('subscription-active');
                    if (ts_sc.is(':checked')) {
                        sc_parent.addClass('subscription-active');
                    }
                });

            });

            $('.package-remove-coupon').on('click', function () {
                $('#package_coupon_code').fadeOut('slow', function () {
                    $('#package_coupon_form').fadeIn('fast');
                })
            });


        });
    })(jQuery);
</script>
