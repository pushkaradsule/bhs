<?php $page ='login'; include 'inc/head.php'; ?>



<div class="zee-content-wrapper zee-myaccount-body">
    <div class="my-account-welcome">
        <div class="container">
            <div class="row">
                <h3><small>Hello</small>Pushkar Adsule</h3>
            </div>
        </div>
    </div>
    <div class="container zee-myaccounter-container">



        <div class="zee-myaccount-nav-wrapper">
            <div class="visible-xs-inline-block myaccount-mobile-menu-trigger">
                <a href="#" id="zee_myaccount_mobile_menu_trigger">Menu</a>
            </div>
            <div id="zee_myaccount_mobile_menu">
                <?php $active_menu = 'profile'; include('inc/myaccount-menu.php'); ?>
                <?php
                /*
                 * <h4 class="zee-myaccount-linktv-header">Link your TV</h4>
                <ul class="zee-myaccount-linktv">
                <li>
                <a href="Samsung">
                <img src="/images/samsung-smart-tv.png">
                </a>
                </li>
                </ul>
                 */?>
            </div>
        </div>

        <div class="zee-myaccount-wrapper">
            <h3 class="zee-myaccount-section-heading my-profile-heading">Personal Information</h3>
            <div class="clearfix" style="height: 20px;"></div>


            <form action="/MyAccount" id="profileForm" method="post">
                <div class="row">

                    <div class="col-sm-6">
                        <div class="form-group">
                            <input class="form-control floating-label" placeholder="First Name" data-val="true" data-val-required="The First name field is required." id="FirstName" name="FirstName" type="text" value="Pushkar" />
                          
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="form-group">
                            <input class="form-control floating-label" placeholder="Last name" data-val="true" data-val-required="The Last name field is required." id="LastName" name="LastName" type="text" value="" />
                        </div>
                    </div>

                    <div class="col-sm-12">
                        <div class="form-group">
                            <input class="form-control floating-label" placeholder=" " disabled="disabled" id="EmailAddress" name="EmailAddress" type="text" value="pushkar.adsule@gmail.com" />
                        </div>
                    </div>


                    <div class="col-sm-12">
                        <h4 class="zee-myaccount-subheading">Contact Information</h4>
                    </div>

                    <div class="col-sm-12">
                        <div class="form-group">
                            <input class="form-control floating-label" placeholder="Address Line 1" data-val="true" data-val-required="The Street Address field is required." id="AddressLine1" name="AddressLine1" type="text" value="" />
                        </div>
                    </div>

                    <div class="col-sm-12">
                        <div class="form-group">
                            <input class="form-control floating-label" placeholder="Address Line 2" id="AddressLine2" name="AddressLine2" type="text" value="" />
                        </div>
                    </div>

                    <div class="col-sm-6">
                        <div class="form-group">
                            <input class="form-control floating-label" placeholder="City" data-val="true" data-val-required="The City field is required." id="AddressCity" name="AddressCity" type="text" value="" />
                        </div>
                    </div>

                    <div class="col-sm-6">
                        <div class="form-group">
                            <input class="form-control floating-label" placeholder="State/ Province" data-val="true" data-val-required="The State/Province field is required." id="AddressState" name="AddressState" type="text" value="" />
                        </div>
                    </div>



                    <div class="col-sm-12">
                        <h4 class="zee-myaccount-subheading">Primary Phone</h4>
                    </div>
                    <div class="col-md-4 col-sm-3">
                        <div class="form-group">
                            <input class="form-control floating-label" placeholder="(Area Code)" data-val="true" data-val-required="The Area Code field is required." id="PrimaryPhoneCode" name="PrimaryPhoneCode" type="text" value="" />
                        </div>
                    </div>

                    <div class="col-md-8 col-sm-6">
                        <div class="form-group">
                            <input class="form-control floating-label" placeholder="(Primary Phone)" data-val="true" data-val-required="The Primary Phone field is required." id="PrimaryPhone" name="PrimaryPhone" type="text" value="" />
                        </div>
                    </div>

                </div>
                <div class="clearfix" style="height: 30px;"></div>
                <div class="row">
                    <div class="col-sm-12">
                        <div class="form-group" style="float: right">
                            <button class="btn btn-material-grey" type="reset">CLEAR</button>
                            <button type="submit" class="btn btn-primary">Save Changes</button>
                        </div>
                    </div>
                </div>
            </form>
        </div>

    </div>
</div>

<?php include 'inc/footer.php'; ?>