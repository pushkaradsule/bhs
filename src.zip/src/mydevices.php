<?php $page ='device'; include 'inc/head.php'; ?>



<div class="zee-content-wrapper no-banner zee-myaccount-body">
    <div class="my-account-welcome">
        <div class="container">
            <div class="row">
                <h3>
                    <small>welcome</small>
                    Pushkar Adsule
                </h3>
            </div>
        </div>
    </div>
    <div class="container zee-myaccounter-container">



        <div class="zee-myaccount-nav-wrapper">
            <div class="visible-xs-inline-block myaccount-mobile-menu-trigger">
                <a href="#" id="zee_myaccount_mobile_menu_trigger">Menu</a>
            </div>
            <div id="zee_myaccount_mobile_menu">
                <?php $active_menu = 'devices'; include('inc/myaccount-menu.php'); ?>
                <?php
                /*
                 * <h4 class="zee-myaccount-linktv-header">Link your TV</h4>
                <ul class="zee-myaccount-linktv">
                <li>
                <a href="Samsung">
<img src="/images/samsung-smart-tv.png">
                </a>
                </li>
                </ul>
                 */?>
            </div>
        </div>

        <div class="zee-myaccount-wrapper">
            <h3 class="zee-myaccount-section-heading my-profile-heading">Manage My Devices</h3>
            <div class="clearfix" style="height: 20px;"></div>
            <div class="row zee-myaccount-grid-placeholder">

                <div class="col-sm-6 col-lg-3 col-md-4" id="device-0">
                    <div class="item-placeholder">
                        <div class="device-icon device-desktop"></div>
                        <div class="device-detail">
                            <h3>PC Browser</h3>
                            <p data-time="2015-09-23T17:59:35.0000000">Added : Last Wednesday at 11:29 PM</p>
                        </div>
                        <a href="javascript:void(0);" title="Remove" class="close remove-device withripple withripple" data-device="EAAAAIfYisw4DlJ7+Z3//tp4ziJvOQbj4O56GgF5PMg3ECbtfn6txHllRzrhL8s7W6y9zo2iGztHd/mMUDWbIa5jsl4=" data-devicetype="PC Browser" data-id="#device-0">
                            <i class="icon icon-trash-empty"></i>
                        </a>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-3 col-md-4" id="device-1">
                    <div class="item-placeholder">
                        <div class="device-icon device-desktop"></div>
                        <div class="device-detail">
                            <h3>PC Browser</h3>
                            <p data-time="2015-09-07T10:27:59.0000000">Added : 09/07/2015</p>
                        </div>
                        <a href="javascript:void(0);" title="Remove" class="close remove-device withripple" data-device="EAAAAKhRqh6OtwNngyoD+gV2hgWm0uq20Bd4ZiwZg8aQOpdquaXXDddlBy8piDYiOCMZzIIwVaBBeHbpF6jO4h39JO0=" data-devicetype="PC Browser" data-id="#device-1">
                            <i class="icon icon-trash-empty"></i>
                        </a>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-3 col-md-4" id="device-2">
                    <div class="item-placeholder">
                        <div class="device-icon device-desktop"></div>
                        <div class="device-detail">
                            <h3>PC Browser</h3>
                            <p data-time="2015-09-15T14:27:26.0000000">Added : 09/15/2015</p>
                        </div>
                        <a href="javascript:void(0);" title="Remove" class="close remove-device withripple" data-device="EAAAAJW7xdm53YonKz8SgTDjZHjxnF16lVrJjJ3czt1V/K7z/ajN+SriWEB2xTl9LKXBLTE1MUWkePa5MGG9pvpZL+g=" data-devicetype="PC Browser" data-id="#device-2">
                            <i class="icon icon-trash-empty"></i>
                        </a>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-3 col-md-4" id="device-3">
                    <div class="item-placeholder">
                        <div class="device-icon device-desktop"></div>
                        <div class="device-detail">
                            <h3>PC Browser</h3>
                            <p data-time="2015-09-20T07:40:45.0000000">Added : 09/20/2015</p>
                        </div>
                        <a href="javascript:void(0);" title="Remove" class="close remove-device withripple" data-device="EAAAAEd3HUz59JLv32vVMAwqfoAEpx9WST8skCb1mEKacxih+Fb4SqCff76murmjrcfXWr+kczMbpPrn3kb7FbXtsto=" data-devicetype="PC Browser" data-id="#device-3">
                            <i class="icon icon-trash-empty"></i>
                        </a>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-3 col-md-4" id="device-4">
                    <div class="item-placeholder">
                        <div class="device-icon device-desktop"></div>
                        <div class="device-detail">
                            <h3>PC Browser</h3>
                            <p data-time="2015-09-21T18:07:53.0000000">Added : 09/21/2015</p>
                        </div>
                        <a href="javascript:void(0);" title="Remove" class="close remove-device withripple" data-device="EAAAAG4zLphI45U9kbub63eaW8YNCfZKsJoOsaF6/3QSyWyR/g6uREPDj2SM6N5UEaBZyrFaRNk5VRRknLx8iokxwjI=" data-devicetype="PC Browser" data-id="#device-4">
                            <i class="icon icon-trash-empty"></i>
                        </a>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-3 col-md-4" id="device-5">
                    <div class="item-placeholder">
                        <div class="device-icon device-win"></div>
                        <div class="device-detail">
                            <h3>Chrome</h3>
                            <p data-time="2015-09-10T03:57:14.0000000">Added : 09/10/2015</p>
                        </div>
                        <a href="javascript:void(0);" title="Remove" class="close remove-device withripple" data-device="EAAAACR1DU1mgRxWQevE9yuawb6ZTzZmJo7sGiWnzJAINKx/8Rc22i2l7TOObqrCUHmepvURdt5PrgkEPdjk3tBHeO4=" data-devicetype="Chrome" data-id="#device-5">
                            <i class="icon icon-trash-empty"></i>
                        </a>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-3 col-md-4" id="device-6">
                    <div class="item-placeholder">
                        <div class="device-icon device-desktop"></div>
                        <div class="device-detail">
                            <h3>PC Browser</h3>
                            <p data-time="2015-09-10T03:47:44.0000000">Added : 09/10/2015</p>
                        </div>
                        <a href="javascript:void(0);" title="Remove" class="close remove-device withripple" data-device="EAAAAC43aqgzpQKRixdEsI3CTZ79s2tqI3hE3CMMCedH9RCBY2Lj4d6eWkq7gxMX7RufLTui//4XIC9czn6OoDvYUzQ=" data-devicetype="PC Browser" data-id="#device-6">
                            <i class="icon icon-trash-empty"></i>
                        </a>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-3 col-md-4" id="device-7">
                    <div class="item-placeholder">
                        <div class="device-icon device-win"></div>
                        <div class="device-detail">
                            <h3>Chrome</h3>
                            <p data-time="2015-09-23T18:15:11.0000000">Added : Last Wednesday at 11:45 PM</p>
                        </div>
                        <a href="javascript:void(0);" title="Remove" class="close remove-device withripple" data-device="EAAAAGwN1aOLgP++je1sVYjyFei+q2l7vd3iGeZafDSMxNupZd4TJsjKLtgoCDtUwPGzM5q9qFI0Umlx2AyxXwUetnk=" data-devicetype="Chrome" data-id="#device-7">
                            <i class="icon icon-trash-empty"></i>
                        </a>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-3 col-md-4" id="device-8">
                    <div class="item-placeholder">
                        <div class="device-icon device-desktop"></div>
                        <div class="device-detail">
                            <h3>PC Browser</h3>
                            <p data-time="2015-09-12T19:50:17.0000000">Added : 09/13/2015</p>
                        </div>
                        <a href="javascript:void(0);" title="Remove" class="close remove-device withripple" data-device="EAAAAL7UhCEvNqdbXsMn6iifykQ6nbGNtWYYsCO9qhA2VlyY1OUeNQY9Py3FhaDuMvbImN35BNkBUZdRFbcKkRWM6F4=" data-devicetype="PC Browser" data-id="#device-8">
                            <i class="icon icon-trash-empty"></i>
                        </a>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-3 col-md-4" id="device-9">
                    <div class="item-placeholder">
                        <div class="device-icon device-desktop"></div>
                        <div class="device-detail">
                            <h3>Mobile Safari</h3>
                            <p data-time="2015-09-23T19:41:55.0000000">Added : Last Thursday at 1:11 AM</p>
                        </div>
                        <a href="javascript:void(0);" class="close remove-device withripple" data-device="EAAAAG9moJOHvg4yGJX1TixsPCGiYUTHywJ2dmCPTVrtY9a72oAcVFnVAZIPT1eRXIka0ZzFQfZHIcQhhkLbqBx3Ebo=" data-devicetype="Mobile Safari" data-id="#device-9">
                            <i class="icon icon-trash-empty"></i>
                        </a>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-3 col-md-4" id="device-10">
                    <div class="item-placeholder">
                        <div class="device-icon device-win"></div>
                        <div class="device-detail">
                            <h3>Firefox</h3>
                            <p data-time="2015-09-23T08:57:24.0000000">Added : Last Wednesday at 2:27 PM</p>
                        </div>
                        <a href="javascript:void(0);" class="close remove-device withripple" data-device="EAAAAPuAjVeZ7fDVeiX8JlsZUQq8Rr2PYaTq3Q0nTFX31Gee//dRIfLkM93WGT8W1ym6eyUdMruwV40kzywiqncS2Ug=" data-devicetype="Firefox" data-id="#device-10">
                            <i class="icon icon-trash-empty"></i>
                        </a>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-3 col-md-4" id="device-11">
                    <div class="item-placeholder">
                        <div class="device-icon device-desktop"></div>
                        <div class="device-detail">
                            <h3>PC Browser</h3>
                            <p data-time="2015-09-10T16:51:28.0000000">Added : 09/10/2015</p>
                        </div>
                        <a href="javascript:void(0);" class="close remove-device withripple" data-device="EAAAACZ4zRM8F9dBQV121KuhP1m/2fDAPr4R3xiUvBEabqcAET4VKsrutFMvOecxcOwXPrNEK+Zu7Vyr+CjwfqMTqK0=" data-devicetype="PC Browser" data-id="#device-11">
                            <i class="icon icon-trash-empty"></i>
                        </a>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-3 col-md-4" id="device-12">
                    <div class="item-placeholder">
                        <div class="device-icon device-desktop"></div>
                        <div class="device-detail">
                            <h3>PC Browser</h3>
                            <p data-time="2015-09-17T03:10:17.0000000">Added : 09/17/2015</p>
                        </div>
                        <a href="javascript:void(0);" class="close remove-device withripple" data-device="EAAAAFaJWVhgYGLgrnrI9aWLw/x5o05pSJPmDoZMZ15M8utzGIDXA2pJ5tNSpAkaZWz1C7mHUqCk5yzB1GXXQwuf3k8=" data-devicetype="PC Browser" data-id="#device-12">
                            <i class="icon icon-trash-empty"></i>
                        </a>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-3 col-md-4" id="device-13">
                    <div class="item-placeholder">
                        <div class="device-icon device-desktop"></div>
                        <div class="device-detail">
                            <h3>PC Browser</h3>
                            <p data-time="2015-09-16T18:25:41.0000000">Added : 09/16/2015</p>
                        </div>
                        <a href="javascript:void(0);" class="close remove-device withripple" data-device="EAAAADgRtOEdxF0FXVTXtoEWPr77AbBXA+Zlb6wJENcsskm9ujf6xqp8UBkgbEMutgipGwOJaLjnQR9Gri42lAWXbs4=" data-devicetype="PC Browser" data-id="#device-13">
                            <i class="icon icon-trash-empty"></i>
                        </a>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-3 col-md-4" id="device-14">
                    <div class="item-placeholder">
                        <div class="device-icon device-desktop"></div>
                        <div class="device-detail">
                            <h3>PC Browser</h3>
                            <p data-time="2015-09-09T03:04:56.0000000">Added : 09/09/2015</p>
                        </div>
                        <a href="javascript:void(0);" class="close remove-device withripple" data-device="EAAAAPAaZesctquKZ8VWJIOZOVeWUuwWmrhsYWZN4c0FXQzzTavWzUmxykrs0izxt20u/gS1DM6xEkZX1Y7EUmTsx8A=" data-devicetype="PC Browser" data-id="#device-14">
                            <i class="icon icon-trash-empty"></i>
                        </a>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-3 col-md-4" id="device-15">
                    <div class="item-placeholder">
                        <div class="device-icon device-desktop"></div>
                        <div class="device-detail">
                            <h3>PC Browser</h3>
                            <p data-time="2015-09-12T12:20:10.0000000">Added : 09/12/2015</p>
                        </div>
                        <a href="javascript:void(0);" class="close remove-device withripple" data-device="EAAAAJJysbMNEqfYafCi9Qtj8LdMZJktHHL1i9wtlBCgdo8/uCgz9YyQeCSqOnaUWxyrdVjlbzjofZFsE6Hm0T6W7Fo=" data-devicetype="PC Browser" data-id="#device-15">
                            <i class="icon icon-trash-empty"></i>
                        </a>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-3 col-md-4" id="device-16">
                    <div class="item-placeholder">
                        <div class="device-icon device-desktop"></div>
                        <div class="device-detail">
                            <h3>PC Browser</h3>
                            <p data-time="2015-09-10T16:23:04.0000000">Added : 09/10/2015</p>
                        </div>
                        <a href="javascript:void(0);" class="close remove-device withripple" data-device="EAAAAFdBL46kjUmQEmEe10asHTR2bsNiL40dgkA91Q3HFq4RznTytGDMNUwtLGGqxFpF+zNY5gUQpUb1xImHIEGcuj4=" data-devicetype="PC Browser" data-id="#device-16">
                            <i class="icon icon-trash-empty"></i>
                        </a>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-3 col-md-4" id="device-17">
                    <div class="item-placeholder">
                        <div class="device-icon device-win"></div>
                        <div class="device-detail">
                            <h3>IE Mobile</h3>
                            <p data-time="2015-09-26T19:29:52.0000000">Added : Yesterday at 12:59 AM</p>
                        </div>
                        <a href="javascript:void(0);" class="close remove-device withripple" data-device="EAAAAH02/uyFYNsgQA8apc8ZJcxvA/BivADL4YP/Ewi+4+0bc9/dV65k0G1YzJlsXuTQ8esvaF/FtLfnMsm0GM66qH8=" data-devicetype="IE Mobile" data-id="#device-17">
                            <i class="icon icon-trash-empty"></i>
                        </a>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-3 col-md-4" id="device-18">
                    <div class="item-placeholder">
                        <div class="device-icon device-win"></div>
                        <div class="device-detail">
                            <h3>Firefox</h3>
                            <p data-time="2015-09-20T13:21:23.0000000">Added : 09/20/2015</p>
                        </div>
                        <a href="javascript:void(0);" class="close remove-device withripple" data-device="EAAAALNRbGyg8lcuFp8Tta7LMVmO3e2ZbhPMsVn3EDiTDeQNfi8RFWv2egoHB49XuRCh5fNjmT/UWGOnWU9tU5GC/Ks=" data-devicetype="Firefox" data-id="#device-18">
                            <i class="icon icon-trash-empty"></i>
                        </a>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-3 col-md-4" id="device-19">
                    <div class="item-placeholder">
                        <div class="device-icon device-mac"></div>
                        <div class="device-detail">
                            <h3>Chrome</h3>
                            <p data-time="2015-09-08T15:45:40.0000000">Added : 09/08/2015</p>
                        </div>
                        <a href="javascript:void(0);" class="close remove-device withripple" data-device="EAAAACKZUwzyIU/dS2UJfq+ajtrnjTgVJXgCvmoVNeex/bCij0sKbPLS1TWhni+1B59EJyX0NKmH8x2rTyKLC0DkQSU=" data-devicetype="Chrome" data-id="#device-19">
                            <i class="icon icon-trash-empty"></i>
                        </a>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-3 col-md-4" id="device-20">
                    <div class="item-placeholder">
                        <div class="device-icon device-desktop"></div>
                        <div class="device-detail">
                            <h3>PC Browser</h3>
                            <p data-time="2015-09-12T04:19:45.0000000">Added : 09/12/2015</p>
                        </div>
                        <a href="javascript:void(0);" class="close remove-device withripple" data-device="EAAAAL+xo4wutxGqY1TKHVRXt1xiQrTQP0vyJiNLSDVBSSyNyXRyNOkitfpSmrc2ScpnEonpK8HuxQU7l+mPn881niA=" data-devicetype="PC Browser" data-id="#device-20">
                            <i class="icon icon-trash-empty"></i>
                        </a>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-3 col-md-4" id="device-21">
                    <div class="item-placeholder">
                        <div class="device-icon device-desktop"></div>
                        <div class="device-detail">
                            <h3>PC Browser</h3>
                            <p data-time="2015-09-08T15:44:19.0000000">Added : 09/08/2015</p>
                        </div>
                        <a href="javascript:void(0);" class="close remove-device withripple" data-device="EAAAAIYo6im0aBWdmR2FWck/ITBfLFaPt0IUIwYe1C+sES3NKYpG+BxHHPw8VsMgh2k+ZVbFL0FQaOqV5h090WxoFfQ=" data-devicetype="PC Browser" data-id="#device-21">
                            <i class="icon icon-trash-empty"></i>
                        </a>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-3 col-md-4" id="device-22">
                    <div class="item-placeholder">
                        <div class="device-icon device-desktop"></div>
                        <div class="device-detail">
                            <h3>PC Browser</h3>
                            <p data-time="2015-09-07T10:25:24.0000000">Added : 09/07/2015</p>
                        </div>
                        <a href="javascript:void(0);" class="close remove-device withripple" data-device="EAAAAIrmmrV0lyQdgmArAABvouViuVnL3XNLxW4+BZX/oL60OxAwz0QVTfhSiKidwWNYOhaTvq2fxTKqYEKd7rNlM6U=" data-devicetype="PC Browser" data-id="#device-22">
                            <i class="icon icon-trash-empty"></i>
                        </a>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-3 col-md-4" id="device-23">
                    <div class="item-placeholder">
                        <div class="device-icon device-desktop"></div>
                        <div class="device-detail">
                            <h3>Mobile Safari</h3>
                            <p data-time="2015-09-11T04:38:33.0000000">Added : 09/11/2015</p>
                        </div>
                        <a href="javascript:void(0);" class="close remove-device withripple" data-device="EAAAAC+RhWPXpjuBJCaQOHmBiKjoJb3FFOxswnOUn7jl0Wxp8XrN3eTYq/c7tLJZAobl8qBoCFeFg96A7gJlrnk7hfY=" data-devicetype="Mobile Safari" data-id="#device-23">
                            <i class="icon icon-trash-empty"></i>
                        </a>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-3 col-md-4" id="device-24">
                    <div class="item-placeholder">
                        <div class="device-icon device-win"></div>
                        <div class="device-detail">
                            <h3>Chrome</h3>
                            <p data-time="2015-09-17T03:12:01.0000000">Added : 09/17/2015</p>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-3 col-md-4" id="device-25">
                    <div class="item-placeholder">
                        <div class="device-icon device-desktop"></div>
                        <div class="device-detail">
                            <h3>PC Browser</h3>
                            <p data-time="2015-09-13T05:59:50.0000000">Added : 09/13/2015</p>
                        </div>
                        <a href="javascript:void(0);" class="close remove-device withripple" data-device="EAAAAIG9OR24k83CJ+ww65N2ePO1H5fuVEZ5x9yV7CNwv23ieNbaOhH22KIPvowS5HLtBcUYD2UuRDRgNzeq7G6OgPM=" data-devicetype="PC Browser" data-id="#device-25">
                            <i class="icon icon-trash-empty"></i>
                        </a>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-3 col-md-4" id="device-26">
                    <div class="item-placeholder">
                        <div class="device-icon device-desktop"></div>
                        <div class="device-detail">
                            <h3>PC Browser</h3>
                            <p data-time="2015-09-12T19:05:25.0000000">Added : 09/13/2015</p>
                        </div>
                        <a href="javascript:void(0);" class="close remove-device withripple" data-device="EAAAAAO/0vgs3Kt+XBOO7KA9BxKPK1vRubSREM0V08ok2QJCZ9MdlTgvWvqRORcPJIH2oqhvBrOJK4sg0WsATj62+qA=" data-devicetype="PC Browser" data-id="#device-26">
                            <i class="icon icon-trash-empty"></i>
                        </a>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-3 col-md-4" id="device-27">
                    <div class="item-placeholder">
                        <div class="device-icon device-desktop"></div>
                        <div class="device-detail">
                            <h3>PC Browser</h3>
                            <p data-time="2015-09-09T03:13:03.0000000">Added : 09/09/2015</p>
                        </div>
                        <a href="javascript:void(0);" class="close remove-device withripple" data-device="EAAAADNsrj0Ss2yCqx5iuc2veYNWCPC5L93d00uyvm/w/2MPNElDlCF7Zj7Nf0U0z9Hh5y7NvAugDV2ObAf00Ghw3fU=" data-devicetype="PC Browser" data-id="#device-27">
                            <i class="icon icon-trash-empty"></i>
                        </a>
                    </div>
                </div>

            </div>


        </div>

    </div>
</div>

<?php include 'inc/footer.php'; ?>